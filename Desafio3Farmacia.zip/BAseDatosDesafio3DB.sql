﻿CREATE DATABASE FarmaciaKaiser


-- ==========================
-- Tabla de Usuarios
-- ==========================
CREATE TABLE Usuario (
    ID_Usuario INT IDENTITY(1,1) PRIMARY KEY,
    Nombre_Usuario VARCHAR(100) NOT NULL,
    Usuario_Login VARCHAR(50) UNIQUE NOT NULL,
    Contraseña VARCHAR(255) NOT NULL,
    Rol VARCHAR(20) NOT NULL CHECK (Rol IN ('Cliente', 'Administrador'))
);
GO

-- ==========================
-- Tabla de Clientes
-- ==========================
CREATE TABLE Cliente (
    ID_Cliente INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Apellido VARCHAR(100),
    DUI VARCHAR(15) UNIQUE NULL,
    Telefono VARCHAR(20),
    Direccion VARCHAR(200),
    Foto VARBINARY(MAX) NULL,  -- 👈 Aquí se guardará la imagen del cliente
    ID_Usuario INT NOT NULL,
    FOREIGN KEY (ID_Usuario) REFERENCES Usuario(ID_Usuario)
);
GO

-- ==========================
-- Tabla de Administradores
-- ==========================
CREATE TABLE Administrador (
    ID_Admin INT IDENTITY(1,1) PRIMARY KEY,
    Nombre_Admin VARCHAR(100) NOT NULL,
    Apellido_Admin VARCHAR(100),
    Cargo VARCHAR(100),
    Telefono VARCHAR(20),
    Correo VARCHAR(100),
    Foto VARBINARY(MAX) NULL,  -- 👈 Aquí se guardará la imagen del administrador
    ID_Usuario INT NOT NULL,
    FOREIGN KEY (ID_Usuario) REFERENCES Usuario(ID_Usuario)
);
GO

-- ==========================
-- Categorías de medicamentos
-- ==========================
CREATE TABLE Categoria (
    ID_Categoria INT IDENTITY(1,1) PRIMARY KEY,
    Nombre_Categoria VARCHAR(100) NOT NULL,
    Descripcion TEXT
);
GO

-- ==========================
-- Medicamentos
-- ==========================
CREATE TABLE Medicamento (
    ID_Medicamento INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Descripcion TEXT,
    ID_Categoria INT NOT NULL,
    Precio_Compra DECIMAL(10,2) NOT NULL,
    Precio_Venta DECIMAL(10,2) NOT NULL,
    Stock INT DEFAULT 0,
    Fecha_Registro DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (ID_Categoria) REFERENCES Categoria(ID_Categoria)
);
GO

-- ==========================
-- Ventas
-- ==========================
CREATE TABLE Venta (
    ID_Venta INT IDENTITY(1,1) PRIMARY KEY,
    ID_Cliente INT NOT NULL,
    Fecha_Venta DATETIME DEFAULT GETDATE(),
    Total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (ID_Cliente) REFERENCES Cliente(ID_Cliente)
);
GO

-- ==========================
-- Detalles de cada venta
-- ==========================
CREATE TABLE Detalle_Venta (
    ID_Detalle INT IDENTITY(1,1) PRIMARY KEY,
    ID_Venta INT NOT NULL,
    ID_Medicamento INT NOT NULL,
    Cantidad INT NOT NULL,
    Precio_Unitario DECIMAL(10,2) NOT NULL,
    Subtotal AS (Cantidad * Precio_Unitario) PERSISTED,
    FOREIGN KEY (ID_Venta) REFERENCES Venta(ID_Venta),
    FOREIGN KEY (ID_Medicamento) REFERENCES Medicamento(ID_Medicamento)
);
GO

-- ==========================
-- Proveedores
-- ==========================
CREATE TABLE Proveedor (
    ID_Proveedor INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Telefono VARCHAR(20),
    Direccion VARCHAR(200),
    Correo VARCHAR(100)
);
GO

-- ==========================
-- Compras a proveedores
-- ==========================
CREATE TABLE Compra (
    ID_Compra INT IDENTITY(1,1) PRIMARY KEY,
    ID_Proveedor INT NOT NULL,
    Fecha_Compra DATETIME DEFAULT GETDATE(),
    Total DECIMAL(10,2),
    FOREIGN KEY (ID_Proveedor) REFERENCES Proveedor(ID_Proveedor)
);
GO

CREATE TABLE Detalle_Compra (
    ID_Detalle_Compra INT IDENTITY(1,1) PRIMARY KEY,
    ID_Compra INT NOT NULL,
    ID_Medicamento INT NOT NULL,
    Cantidad INT NOT NULL,
    Precio_Compra DECIMAL(10,2) NOT NULL,
    Subtotal AS (Cantidad * Precio_Compra) PERSISTED,
    FOREIGN KEY (ID_Compra) REFERENCES Compra(ID_Compra),
    FOREIGN KEY (ID_Medicamento) REFERENCES Medicamento(ID_Medicamento)
);
GO
ALTER TABLE Medicamento
ADD Imagen VARBINARY(MAX) NULL;

ALTER TABLE Usuario
ADD CodigoAdmin VARCHAR(50) NULL;
GO

CREATE TRIGGER trg_VerificarAdmin
ON Usuario
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE Rol = 'Administrador' AND (CodigoAdmin IS NULL OR CodigoAdmin = '')
    )
    BEGIN
        RAISERROR('Debe proporcionar un Código de administrador al crear una cuenta de tipo Administrador.', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
GO

ALTER TABLE Medicamento
ADD ID_Proveedor INT NULL;
GO

ALTER TABLE Medicamento
ADD CONSTRAINT FK_Medicamento_Proveedor
FOREIGN KEY (ID_Proveedor)
REFERENCES Proveedor(ID_Proveedor);
GO

-- ==========================
-- Usuarios
-- ==========================
INSERT INTO Usuario (Nombre_Usuario, Usuario_Login, Contraseña, Rol, CodigoAdmin) VALUES
-- Clientes (CodigoAdmin = NULL)
('Juan Pérez', 'juanp', '1234', 'Cliente', NULL),
('Ana Gómez', 'anag', '1234', 'Cliente', NULL),
('Carlos López', 'carlosl', '1234', 'Cliente', NULL),
('Maria Torres', 'mariat', '1234', 'Cliente', NULL),
('Luis Fernández', 'luisf', '1234', 'Cliente', NULL),
('Pedro Martínez', 'pedrom', '1234', 'Cliente', NULL),
('Sofía Ramírez', 'sofiar', '1234', 'Cliente', NULL),
('Mario Santos', 'marios', '1234', 'Cliente', NULL),
('Lucía Vega', 'luciav', '1234', 'Cliente', NULL),
('Diego Castro', 'diegoc', '1234', 'Cliente', NULL),

-- Administradores (CodigoAdmin obligatorio)
('Admin1', 'admin1', 'admin123', 'Administrador', 'ADM001'),
('Admin2', 'admin2', 'admin123', 'Administrador', 'ADM002'),
('Admin3', 'admin3', 'admin123', 'Administrador', 'ADM003'),
('Admin4', 'admin4', 'admin123', 'Administrador', 'ADM004'),
('Admin5', 'admin5', 'admin123', 'Administrador', 'ADM005'),
('Admin6', 'admin6', 'admin123', 'Administrador', 'ADM006'),
('Admin7', 'admin7', 'admin123', 'Administrador', 'ADM007'),
('Admin8', 'admin8', 'admin123', 'Administrador', 'ADM008'),
('Admin9', 'admin9', 'admin123', 'Administrador', 'ADM009'),
('Admin10', 'admin10', 'admin123', 'Administrador', 'ADM010');
GO

INSERT INTO Cliente (Nombre, Apellido, DUI, Telefono, Direccion, Foto, ID_Usuario) VALUES
('Juan', 'Pérez', '01234567-8', '7777-1111', 'Av. Central 123', NULL, 1),
('Ana', 'Gómez', '02345678-9', '7777-2222', 'Calle Luna 45', NULL, 2),
('Carlos', 'López', '03456789-0', '7777-3333', 'Col. Sol 78', NULL, 3),
('Maria', 'Torres', '04567890-1', '7777-4444', 'Resid. Estrella 12', NULL, 4),
('Luis', 'Fernández', '05678901-2', '7777-5555', 'Av. La Paz 90', NULL, 5),
('Pedro', 'Martínez', '06789012-3', '7777-6666', 'Col. Jardín 5', NULL, 6),
('Sofía', 'Ramírez', '07890123-4', '7777-7777', 'Calle Primavera 18', NULL, 7),
('Mario', 'Santos', '08901234-5', '7777-8888', 'Av. Reforma 22', NULL, 8),
('Lucía', 'Vega', '09012345-6', '7777-9999', 'Col. Rivera 33', NULL, 9),
('Diego', 'Castro', '10123456-7', '7777-0000', 'Calle Olmo 7', NULL, 10);
GO
INSERT INTO Administrador (Nombre_Admin, Apellido_Admin, Cargo, Telefono, Correo, Foto, ID_Usuario) VALUES
('Admin1', 'Principal', 'Gerente', '7000-1111', 'admin1@farmacia.com', NULL, 11),
('Admin2', 'Secundario', 'Subgerente', '7000-2222', 'admin2@farmacia.com', NULL, 12),
('Admin3', 'Tercero', 'Supervisor', '7000-3333', 'admin3@farmacia.com', NULL, 13),
('Admin4', 'Cuarto', 'Contador', '7000-4444', 'admin4@farmacia.com', NULL, 14),
('Admin5', 'Quinto', 'Inventario', '7000-5555', 'admin5@farmacia.com', NULL, 15),
('Admin6', 'Sexto', 'Ventas', '7000-6666', 'admin6@farmacia.com', NULL, 16),
('Admin7', 'Séptimo', 'Compras', '7000-7777', 'admin7@farmacia.com', NULL, 17),
('Admin8', 'Octavo', 'Atención al Cliente', '7000-8888', 'admin8@farmacia.com', NULL, 18),
('Admin9', 'Noveno', 'Marketing', '7000-9999', 'admin9@farmacia.com', NULL, 19),
('Admin10', 'Décimo', 'Seguridad', '7000-0000', 'admin10@farmacia.com', NULL, 20);
GO

-- ==========================
-- NUEVAS CATEGORÍAS
-- ==========================
INSERT INTO Categoria (Nombre_Categoria, Descripcion) VALUES
('Aparato Respiratorio', 'Medicamentos para tratar tos, gripe, congestión y alergias respiratorias'),
('Funcionamiento GastroIntestinal', 'Medicamentos para el sistema digestivo y estomacal'),
('Analgesia', 'Medicamentos para aliviar el dolor y la fiebre'),
('Higiene, Curación y Diagnóstico', 'Productos para limpieza, primeros auxilios y diagnóstico básico'),
('Rehidratantes', 'Suplementos y soluciones para rehidratar el cuerpo'),
('Salud Sexual', 'Productos para la salud sexual y cuidado íntimo'),
('Diabetes', 'Medicamentos y productos para control de glucosa'),
('Medicamentos', 'Otros medicamentos de uso general');
GO


-- ==========================
-- MEDICAMENTOS (10 por categoría)
-- ==========================
INSERT INTO Medicamento (Nombre, Descripcion, ID_Categoria, Precio_Compra, Precio_Venta, Stock, Fecha_Registro, Imagen) VALUES
-- 1. Aparato Respiratorio
('Jarabe Bronquial 120ml', 'Alivia la tos y congestión', 1, 1.00, 2.00, 100, GETDATE(), NULL),
('Descongestionante Nasal Spray', 'Despeja las vías respiratorias', 1, 0.80, 1.60, 120, GETDATE(), NULL),
('Loratadina 10mg', 'Antihistamínico oral', 1, 0.15, 0.35, 150, GETDATE(), NULL),
('Ambroxol 15mg/5ml', 'Mucolítico para la tos', 1, 0.70, 1.50, 80, GETDATE(), NULL),
('Jarabe para Gripe 100ml', 'Para resfriados y fiebre', 1, 1.10, 2.20, 90, GETDATE(), NULL),
('Mentol Inhalador', 'Descongestionante nasal natural', 1, 0.50, 1.00, 200, GETDATE(), NULL),
('Pastillas para la Garganta', 'Alivian el dolor de garganta', 1, 0.40, 0.90, 180, GETDATE(), NULL),
('Salbutamol Inhalador', 'Broncodilatador para el asma', 1, 2.00, 4.00, 60, GETDATE(), NULL),
('Nebulizador Solución 5ml', 'Tratamiento respiratorio', 1, 1.50, 3.00, 70, GETDATE(), NULL),
('Antigripal Tabletas', 'Reduce fiebre y congestión', 1, 0.25, 0.70, 130, GETDATE(), NULL),

-- 2. Funcionamiento GastroIntestinal
('Omeprazol 20mg', 'Reduce acidez estomacal', 2, 0.20, 0.50, 200, GETDATE(), NULL),
('Loperamida 2mg', 'Controla la diarrea', 2, 0.15, 0.40, 180, GETDATE(), NULL),
('Sales de Rehidratación Oral', 'Restaura líquidos y electrolitos', 2, 0.25, 0.60, 160, GETDATE(), NULL),
('Simeticona 80mg', 'Alivia gases intestinales', 2, 0.20, 0.50, 150, GETDATE(), NULL),
('Bismuto Subsalicilato', 'Calma malestar estomacal', 2, 0.30, 0.70, 100, GETDATE(), NULL),
('Domperidona 10mg', 'Antiemético', 2, 0.25, 0.55, 120, GETDATE(), NULL),
('Lansoprazol 30mg', 'Tratamiento para gastritis', 2, 0.30, 0.70, 110, GETDATE(), NULL),
('Metoclopramida 10mg', 'Para náuseas y vómitos', 2, 0.18, 0.45, 140, GETDATE(), NULL),
('Ranitidina 150mg', 'Alivia acidez estomacal', 2, 0.25, 0.60, 130, GETDATE(), NULL),
('Carbón Activado Cápsulas', 'Desintoxica el sistema digestivo', 2, 0.10, 0.30, 170, GETDATE(), NULL),

-- 3. Analgesia
('Paracetamol 500mg', 'Alivia el dolor y la fiebre', 3, 0.10, 0.25, 300, GETDATE(), NULL),
('Ibuprofeno 400mg', 'Antiinflamatorio oral', 3, 0.15, 0.35, 250, GETDATE(), NULL),
('Naproxeno 500mg', 'Calma dolores musculares', 3, 0.20, 0.45, 180, GETDATE(), NULL),
('Diclofenaco 50mg', 'Antiinflamatorio y analgésico', 3, 0.25, 0.50, 200, GETDATE(), NULL),
('Aspirina 100mg', 'Analgésico leve', 3, 0.12, 0.30, 220, GETDATE(), NULL),
('Ketorolaco 10mg', 'Analgésico fuerte', 3, 0.35, 0.75, 150, GETDATE(), NULL),
('Metamizol Sódico 500mg', 'Analgésico y antipirético', 3, 0.25, 0.55, 160, GETDATE(), NULL),
('Cápsulas de Dolor Muscular', 'Para contracturas leves', 3, 0.30, 0.70, 100, GETDATE(), NULL),
('Pomada Analgésica 30g', 'Uso tópico', 3, 0.50, 1.20, 80, GETDATE(), NULL),
('Analgésico Infantil Jarabe', 'Alivio de fiebre y dolor', 3, 0.40, 0.90, 120, GETDATE(), NULL),

-- 4. Higiene, Curación y Diagnóstico
('Agua Oxigenada 120ml', 'Desinfectante para heridas', 4, 0.25, 0.60, 100, GETDATE(), NULL),
('Alcohol Etílico 70%', 'Antiséptico y limpieza', 4, 0.30, 0.70, 150, GETDATE(), NULL),
('Algodón 100g', 'Curaciones y limpieza', 4, 0.40, 0.90, 120, GETDATE(), NULL),
('Vendas Elásticas', 'Soporte y compresión', 4, 0.50, 1.00, 80, GETDATE(), NULL),
('Termómetro Digital', 'Mide temperatura corporal', 4, 2.00, 4.00, 50, GETDATE(), NULL),
('Tiras Reactivas Glucosa', 'Monitoreo de glucosa', 4, 5.00, 8.00, 40, GETDATE(), NULL),
('Guantes Desechables Caja', 'Uso médico', 4, 3.00, 5.50, 60, GETDATE(), NULL),
('Mascarilla 3 Capas', 'Protección respiratoria', 4, 0.10, 0.25, 300, GETDATE(), NULL),
('Curitas Adhesivas', 'Pequeñas heridas', 4, 0.20, 0.50, 180, GETDATE(), NULL),
('Tensiómetro Digital', 'Medición de presión arterial', 4, 8.00, 12.00, 20, GETDATE(), NULL),

-- 5. Rehidratantes
('Suero Oral 500ml', 'Rehidratante oral', 5, 0.80, 1.60, 120, GETDATE(), NULL),
('Bebida Electrolítica 600ml', 'Rehidratante sabor limón', 5, 1.00, 2.00, 100, GETDATE(), NULL),
('Polvo Rehidratante', 'Para diluir en agua', 5, 0.50, 1.00, 130, GETDATE(), NULL),
('Gatorade 600ml', 'Bebida isotónica', 5, 1.10, 2.20, 90, GETDATE(), NULL),
('Pedialyte 500ml', 'Rehidratante infantil', 5, 1.50, 3.00, 70, GETDATE(), NULL),
('Vida Suero Oral 1L', 'Rehidratante oral básico', 5, 0.90, 1.80, 80, GETDATE(), NULL),
('Electrolit 625ml', 'Rehidratante con minerales', 5, 1.20, 2.40, 90, GETDATE(), NULL),
('Suero Natural Coco', 'Hidratación natural', 5, 1.50, 3.00, 60, GETDATE(), NULL),
('Bebida Isotónica Naranja', 'Recupera energías', 5, 1.10, 2.10, 70, GETDATE(), NULL),
('Suero en Polvo Fresa', 'Saborizado para niños', 5, 0.80, 1.60, 100, GETDATE(), NULL),

-- 6. Salud Sexual
('Condones Durex Clásico', 'Protección sexual básica', 6, 0.70, 1.50, 200, GETDATE(), NULL),
('Condones Trojan Ultra', 'Alta resistencia', 6, 0.80, 1.60, 180, GETDATE(), NULL),
('Condones Prudence Saborizados', 'Variedad de sabores', 6, 0.90, 1.80, 160, GETDATE(), NULL),
('Lubricante Base Agua 50ml', 'Lubricante íntimo', 6, 1.00, 2.00, 150, GETDATE(), NULL),
('Lubricante Base Silicona', 'Mayor duración', 6, 1.50, 3.00, 100, GETDATE(), NULL),
('Prueba de Embarazo', 'Detección rápida de embarazo', 6, 0.80, 1.70, 200, GETDATE(), NULL),
('Toallitas Íntimas', 'Higiene íntima femenina', 6, 0.50, 1.10, 180, GETDATE(), NULL),
('Gel Íntimo Neutro', 'Cuidado e hidratación íntima', 6, 1.20, 2.50, 120, GETDATE(), NULL),
('Píldoras Anticonceptivas', 'Prevención del embarazo', 6, 2.00, 4.00, 90, GETDATE(), NULL),
('Prueba de Ovulación', 'Detección de fertilidad', 6, 1.00, 2.20, 80, GETDATE(), NULL),

-- 7. Diabetes
('Metformina 850mg', 'Control de glucosa', 7, 0.20, 0.50, 200, GETDATE(), NULL),
('Insulina NPH 10ml', 'Tratamiento de diabetes', 7, 2.50, 5.00, 100, GETDATE(), NULL),
('Insulina Rápida 10ml', 'Control inmediato de glucosa', 7, 3.00, 6.00, 80, GETDATE(), NULL),
('Glucómetro Portátil', 'Medición de glucosa', 7, 8.00, 12.00, 40, GETDATE(), NULL),
('Tiras Reactivas 50u', 'Para glucómetro', 7, 5.00, 8.00, 70, GETDATE(), NULL),
('Lancetas 100u', 'Para punción de sangre', 7, 3.00, 5.00, 60, GETDATE(), NULL),
('Dieta Diabética Suplemento', 'Control nutricional', 7, 2.00, 4.00, 90, GETDATE(), NULL),
('Jarabe sin Azúcar', 'Apto para diabéticos', 7, 1.00, 2.00, 100, GETDATE(), NULL),
('Galletas sin Azúcar', 'Snack para diabéticos', 7, 0.70, 1.50, 120, GETDATE(), NULL),
('Vitamina B12 1000mcg', 'Apoyo al sistema nervioso', 7, 0.40, 0.90, 150, GETDATE(), NULL),

-- 8. Medicamentos (Generales)
('Amoxicilina 500mg', 'Antibiótico oral', 8, 0.25, 0.50, 200, GETDATE(), NULL),
('Ciprofloxacino 500mg', 'Antibiótico de amplio espectro', 8, 0.30, 0.70, 180, GETDATE(), NULL),
('Clotrimazol Crema 20g', 'Antifúngico tópico', 8, 0.40, 0.90, 160, GETDATE(), NULL),
('Prednisona 5mg', 'Corticosteroide oral', 8, 0.25, 0.60, 140, GETDATE(), NULL),
('Azitromicina 500mg', 'Antibiótico oral', 8, 0.35, 0.80, 130, GETDATE(), NULL),
('Penicilina Inyectable', 'Antibiótico inyectable', 8, 1.00, 2.00, 100, GETDATE(), NULL),
('Tetraciclina 250mg', 'Antibiótico de amplio uso', 8, 0.20, 0.50, 120, GETDATE(), NULL),
('Pomada Antibiótica 30g', 'Para infecciones cutáneas', 8, 0.60, 1.20, 90, GETDATE(), NULL),
('Jarabe Infantil Antibiótico', 'Tratamiento para niños', 8, 0.80, 1.60, 80, GETDATE(), NULL),
('Cefalexina 500mg', 'Antibiótico general', 8, 0.30, 0.70, 100, GETDATE(), NULL);
GO




INSERT INTO Proveedor (Nombre, Telefono, Direccion, Correo) VALUES
('Distribuidora Salud', '2222-1111', 'Av. Salud 123', 'contacto@salud.com'),
('Farmacos S.A.', '2222-2222', 'Calle Medic 45', 'ventas@farmacos.com'),
('Laboratorios Vida', '2222-3333', 'Col. Vida 78', 'info@vida.com'),
('Proveedor Médico', '2222-4444', 'Av. Medicina 12', 'contacto@medico.com'),
('Medicamentos Express', '2222-5555', 'Calle Rápida 90', 'ventas@express.com'),
('Insumos Farmacéuticos', '2222-6666', 'Col. Insumos 5', 'info@insumos.com'),
('Distribuciones ABC', '2222-7777', 'Av. Central 22', 'abc@distribuciones.com'),
('Laboratorio Saludable', '2222-8888', 'Calle Bienestar 18', 'saludable@lab.com'),
('Farmacia Total', '2222-9999', 'Av. Total 33', 'contacto@total.com'),
('MediProve', '2222-0000', 'Col. Proveedor 7', 'info@mediprove.com');
go
INSERT INTO Compra (ID_Proveedor, Fecha_Compra, Total) VALUES
(1, GETDATE(), 100.00),
(2, GETDATE(), 200.00),
(3, GETDATE(), 150.00),
(4, GETDATE(), 180.00),
(5, GETDATE(), 120.00),
(6, GETDATE(), 160.00),
(7, GETDATE(), 140.00),
(8, GETDATE(), 110.00),
(9, GETDATE(), 130.00),
(10, GETDATE(), 190.00);
go
INSERT INTO Detalle_Compra (ID_Compra, ID_Medicamento, Cantidad, Precio_Compra) VALUES
(1,1,50,0.25),(1,2,100,0.10),
(2,3,80,0.15),(2,4,60,0.20),
(3,5,40,0.50),(3,6,30,1.00),
(4,7,70,0.12),(4,8,50,0.30),
(5,9,60,0.25),(5,10,20,0.40);
go
INSERT INTO Venta (ID_Cliente, Fecha_Venta, Total) VALUES
(1, GETDATE(), 15.50),
(2, GETDATE(), 25.00),
(3, GETDATE(), 30.75),
(4, GETDATE(), 20.40),
(5, GETDATE(), 10.00),
(6, GETDATE(), 50.25),
(7, GETDATE(), 40.10),
(8, GETDATE(), 22.80),
(9, GETDATE(), 18.60),
(10, GETDATE(), 35.90);
go
INSERT INTO Detalle_Venta (ID_Venta, ID_Medicamento, Cantidad, Precio_Unitario) VALUES
(1,2,5,0.25),
(1,3,3,0.30),
(2,1,10,0.50),
(2,4,5,0.45),
(3,5,2,1.00),
(3,6,1,2.00),
(4,7,4,0.30),
(4,8,3,0.60),
(5,9,6,0.50),
(5,10,2,0.80),
(6,1,5,0.50),
(6,3,10,0.30),
(7,2,8,0.25),
(7,4,5,0.45),
(8,5,3,1.00),
(8,6,2,2.00),
(9,7,4,0.30),
(9,8,3,0.60),
(10,9,6,0.50),
(10,10,5,0.80);

SELECT * FROM Usuario;
SELECT * FROM Cliente;
SELECT * FROM Administrador;

SELECT * FROM Categoria;
SELECT * FROM Medicamento;

SELECT * FROM Proveedor;
SELECT * FROM Compra;
SELECT * FROM Detalle_Compra;

SELECT * FROM Venta;
SELECT * FROM Detalle_Venta;
GO