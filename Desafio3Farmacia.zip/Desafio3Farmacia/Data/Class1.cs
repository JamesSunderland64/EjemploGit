﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.Data
{
    public static class Conexion
    {
        private static string cadena =
            "Data Source=Andy\\SQLEXPRESS;Initial Catalog=FarmaciaKaiser;Integrated Security=True;";

        public static SqlConnection ObtenerConexion()
        {
            return new SqlConnection(cadena);
        }

    }
}
