﻿using Desafio3Farmacia.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.Data
{
    public static class FarmaciaDAO
    {
        public static List<Categoria> ObtenerCategorias()
        {
            var lista = new List<Categoria>();
            using (SqlConnection cn = Conexion.ObtenerConexion())
            {
                string query = "SELECT ID_Categoria, Nombre_Categoria, Descripcion FROM Categoria ORDER BY ID_Categoria";
                SqlCommand cmd = new SqlCommand(query, cn);
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new Categoria
                        {
                            ID_Categoria = Convert.ToInt32(dr["ID_Categoria"]),
                            Nombre_Categoria = dr["Nombre_Categoria"].ToString(),
                            Descripcion = dr["Descripcion"].ToString()
                        });
                    }
                }
            }
            return lista;
        }

        public static List<Medicamento> ObtenerTodos()
        {
            var lista = new List<Medicamento>();
            using (SqlConnection cn = Conexion.ObtenerConexion())
            {
                string sql = @"SELECT ID_Medicamento, Nombre, Descripcion, ID_Categoria, Precio_Compra, Precio_Venta, Stock, Fecha_Registro, Imagen, ID_Proveedor
                               FROM Medicamento ORDER BY Nombre";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new Medicamento
                        {
                            ID_Medicamento = Convert.ToInt32(dr["ID_Medicamento"]),
                            Nombre = dr["Nombre"].ToString(),
                            Descripcion = dr["Descripcion"].ToString(),
                            ID_Categoria = Convert.ToInt32(dr["ID_Categoria"]),
                            Precio_Compra = Convert.ToDecimal(dr["Precio_Compra"]),
                            Precio_Venta = Convert.ToDecimal(dr["Precio_Venta"]),
                            Stock = Convert.ToInt32(dr["Stock"]),
                            Fecha_Registro = Convert.ToDateTime(dr["Fecha_Registro"]),
                            Imagen = dr["Imagen"] != DBNull.Value ? (byte[])dr["Imagen"] : null,
                            ID_Proveedor = dr["ID_Proveedor"] != DBNull.Value ? (int?)Convert.ToInt32(dr["ID_Proveedor"]) : null
                        });
                    }
                }
            }
            return lista;
        }

        public static List<Medicamento> ObtenerMedicamentosPorCategoria(int idCategoria)
        {
            var lista = new List<Medicamento>();
            using (SqlConnection cn = Conexion.ObtenerConexion())
            {
                string sql = @"SELECT ID_Medicamento, Nombre, Descripcion, ID_Categoria, Precio_Compra, Precio_Venta, Stock, Fecha_Registro, Imagen, ID_Proveedor
                               FROM Medicamento
                               WHERE ID_Categoria = @idCat
                               ORDER BY Nombre";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@idCat", idCategoria);
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new Medicamento
                        {
                            ID_Medicamento = Convert.ToInt32(dr["ID_Medicamento"]),
                            Nombre = dr["Nombre"].ToString(),
                            Descripcion = dr["Descripcion"].ToString(),
                            ID_Categoria = Convert.ToInt32(dr["ID_Categoria"]),
                            Precio_Compra = Convert.ToDecimal(dr["Precio_Compra"]),
                            Precio_Venta = Convert.ToDecimal(dr["Precio_Venta"]),
                            Stock = Convert.ToInt32(dr["Stock"]),
                            Fecha_Registro = Convert.ToDateTime(dr["Fecha_Registro"]),
                            Imagen = dr["Imagen"] != DBNull.Value ? (byte[])dr["Imagen"] : null,
                            ID_Proveedor = dr["ID_Proveedor"] != DBNull.Value ? (int?)Convert.ToInt32(dr["ID_Proveedor"]) : null
                        });
                    }
                }
            }
            return lista;
        }


        public static int InsertarVenta(Venta venta, List<DetalleVenta> detalles)
        {
            int idVentaGenerada = 0;
            using (SqlConnection cn = Conexion.ObtenerConexion())
            {
                cn.Open();
                SqlTransaction tx = cn.BeginTransaction();
                try
                {
                    string sqlVenta = @"INSERT INTO Venta (ID_Cliente, Fecha_Venta, Total)
                                        VALUES (@cliente, @fecha, @total);
                                        SELECT SCOPE_IDENTITY();";
                    SqlCommand cmdVenta = new SqlCommand(sqlVenta, cn, tx);

                    cmdVenta.Parameters.AddWithValue("@cliente", venta.ID_Usuario);
                    cmdVenta.Parameters.AddWithValue("@fecha", venta.Fecha_Venta);
                    cmdVenta.Parameters.AddWithValue("@total", venta.Total);
                    idVentaGenerada = Convert.ToInt32(cmdVenta.ExecuteScalar());

                    foreach (var d in detalles)
                    {
                        string sqlDetalle = @"INSERT INTO Detalle_Venta (ID_Venta, ID_Medicamento, Cantidad, Precio_Unitario)
                                              VALUES (@venta, @med, @cant, @precio)";
                        SqlCommand cmdDetalle = new SqlCommand(sqlDetalle, cn, tx);
                        cmdDetalle.Parameters.AddWithValue("@venta", idVentaGenerada);
                        cmdDetalle.Parameters.AddWithValue("@med", d.ID_Medicamento);
                        cmdDetalle.Parameters.AddWithValue("@cant", d.Cantidad);
                        cmdDetalle.Parameters.AddWithValue("@precio", d.PrecioUnitario);
                        cmdDetalle.ExecuteNonQuery();


                        string sqlStock = @"UPDATE Medicamento
                                            SET Stock = Stock - @cant
                                            WHERE ID_Medicamento = @id";
                        SqlCommand cmdStock = new SqlCommand(sqlStock, cn, tx);
                        cmdStock.Parameters.AddWithValue("@cant", d.Cantidad);
                        cmdStock.Parameters.AddWithValue("@id", d.ID_Medicamento);
                        cmdStock.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
                catch
                {
                    tx.Rollback();
                    throw;
                }
            }
            return idVentaGenerada;
        }


        public static DataTable ObtenerHistorialVentas()
        {
            using (SqlConnection cn = Conexion.ObtenerConexion())
            {
                string sql = @"SELECT v.ID_Venta, u.Nombre_Usuario, v.Fecha_Venta, v.Total
                               FROM Venta v
                               INNER JOIN Usuario u ON u.ID_Usuario = v.ID_Cliente -- adapta si usas ID_Usuario
                               ORDER BY v.Fecha_Venta DESC";
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
    }
}
