﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Desafio3Farmacia.Data;

namespace Desafio3Farmacia.Data
{
    public class LoguinService
    {
        
        public string ValidarUsuario(string usuario, string contraseña, string codigoAdmin, bool esAdmin)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "SELECT ID_Usuario, Nombre_Usuario, Rol, CodigoAdmin FROM Usuario " +
                    "WHERE Usuario_Login = @usuario AND Contraseña = @contraseña", con);
                cmd.Parameters.AddWithValue("@usuario", usuario);
                cmd.Parameters.AddWithValue("@contraseña", contraseña);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    string rol = reader["Rol"].ToString();
                    string codigo = reader["CodigoAdmin"]?.ToString();

                  
                    Sesion.ID_Usuario = Convert.ToInt32(reader["ID_Usuario"]);
                    Sesion.NombreUsuario = reader["Nombre_Usuario"].ToString();
                    Sesion.Rol = rol;

                    reader.Close();

                    if (esAdmin)
                    {
                        if (rol != "Administrador")
                            return "ErrorRol"; 

                        if (codigo != codigoAdmin)
                            return "CodigoIncorrecto"; 
                    }
                    else
                    {
                        if (rol != "Cliente")
                            return "ErrorRol"; 
                    }

                    return rol; 
                }

                return null; 
            }
        }
    }
}
