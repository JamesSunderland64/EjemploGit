﻿using Desafio3Farmacia.Vistas;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Desafio3Farmacia.Models;

namespace Desafio3Farmacia.Data
{
    public class MedicamentoDAL
    {
        public static List<Medicamento> ObtenerMedicamentos()
        {
            var lista = new List<Medicamento>();

            using (SqlConnection cn = Conexion.ObtenerConexion())
            {
                cn.Open();
                string query = "SELECT ID_Medicamento, Nombre, Precio_Venta, Imagen FROM Medicamento";
                using (SqlCommand cmd = new SqlCommand(query, cn))
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new Medicamento
                        {
                            ID_Medicamento = dr.GetInt32(0),
                            Nombre = dr.GetString(1),
                            Precio_Venta = dr.GetDecimal(2),
                            Imagen = dr["Imagen"] == DBNull.Value ? null : (byte[])dr["Imagen"]
                        });
                    }
                }
            }
            return lista;
        }
    }
}
