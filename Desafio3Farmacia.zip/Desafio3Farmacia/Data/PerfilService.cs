﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.Data
{
    public class ClienteService
    {
        public DataTable ObtenerClientePorUsuario(int idUsuario)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string query = @"
                    SELECT c.ID_Cliente, c.Nombre, c.Apellido, c.DUI, c.Telefono, c.Direccion, c.Foto,
                           u.Nombre_Usuario, u.Usuario_Login, u.Contraseña
                    FROM Cliente c
                    INNER JOIN Usuario u ON c.ID_Usuario = u.ID_Usuario
                    WHERE c.ID_Usuario = @idUsuario";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@idUsuario", idUsuario);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }


        public int CrearCliente(int idUsuario, string nombre, string apellido, string dui, string telefono, string direccion, Image foto = null)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();
                string query = @"
                    INSERT INTO Cliente (Nombre, Apellido, DUI, Telefono, Direccion, Foto, ID_Usuario)
                    VALUES (@Nombre, @Apellido, @DUI, @Telefono, @Direccion, @Foto, @ID_Usuario);
                    SELECT SCOPE_IDENTITY();";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Nombre", nombre);
                cmd.Parameters.AddWithValue("@Apellido", string.IsNullOrEmpty(apellido) ? (object)DBNull.Value : apellido);
                cmd.Parameters.AddWithValue("@DUI", string.IsNullOrEmpty(dui) ? (object)DBNull.Value : dui);
                cmd.Parameters.AddWithValue("@Telefono", string.IsNullOrEmpty(telefono) ? (object)DBNull.Value : telefono);
                cmd.Parameters.AddWithValue("@Direccion", string.IsNullOrEmpty(direccion) ? (object)DBNull.Value : direccion);
                cmd.Parameters.AddWithValue("@ID_Usuario", idUsuario);

                if (foto != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        foto.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        cmd.Parameters.AddWithValue("@Foto", ms.ToArray());
                    }
                }
                else
                {
                    cmd.Parameters.AddWithValue("@Foto", DBNull.Value);
                }

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }


        public void ActualizarCliente(int idCliente, string nombre, string apellido, string dui, string telefono, string direccion, Image foto = null)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();
                string query = @"
                    UPDATE Cliente
                    SET Nombre = @Nombre,
                        Apellido = @Apellido,
                        DUI = @DUI,
                        Telefono = @Telefono,
                        Direccion = @Direccion,
                        Foto = @Foto
                    WHERE ID_Cliente = @ID_Cliente";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Nombre", nombre);
                cmd.Parameters.AddWithValue("@Apellido", string.IsNullOrEmpty(apellido) ? (object)DBNull.Value : apellido);
                cmd.Parameters.AddWithValue("@DUI", string.IsNullOrEmpty(dui) ? (object)DBNull.Value : dui);
                cmd.Parameters.AddWithValue("@Telefono", string.IsNullOrEmpty(telefono) ? (object)DBNull.Value : telefono);
                cmd.Parameters.AddWithValue("@Direccion", string.IsNullOrEmpty(direccion) ? (object)DBNull.Value : direccion);

                if (foto != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        foto.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        cmd.Parameters.AddWithValue("@Foto", ms.ToArray());
                    }
                }
                else
                {
                    cmd.Parameters.AddWithValue("@Foto", DBNull.Value);
                }

                cmd.Parameters.AddWithValue("@ID_Cliente", idCliente);
                cmd.ExecuteNonQuery();
            }
        }

 
        public void ActualizarUsuario(int idUsuario, string nombreUsuario, string login, string contrasena)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();
                string query = @"
                    UPDATE Usuario
                    SET Nombre_Usuario = @NombreUsuario,
                        Usuario_Login = @Login,
                        Contraseña = @Contrasena
                    WHERE ID_Usuario = @ID_Usuario";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                cmd.Parameters.AddWithValue("@Login", login);
                cmd.Parameters.AddWithValue("@Contrasena", contrasena);
                cmd.Parameters.AddWithValue("@ID_Usuario", idUsuario);
                cmd.ExecuteNonQuery();
            }
        }


        public Image ConvertirBytesAImagen(byte[] datos)
        {
            if (datos == null || datos.Length == 0)
                return null;

            using (MemoryStream ms = new MemoryStream(datos))
            {
                return Image.FromStream(ms);
            }
        }

    }
}
