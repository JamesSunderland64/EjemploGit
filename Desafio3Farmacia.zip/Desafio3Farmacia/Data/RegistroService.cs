﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.Data
{
    public class RegistroService
    {
        public bool CrearUsuario(string nombreUsuario, string login, string contrasena, bool esAdmin, string codigoAdmin = null)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Usuario (Nombre_Usuario, Usuario_Login, Contraseña, Rol, CodigoAdmin) " +
                    "VALUES (@nombre, @login, @contrasena, @rol, @codigo)", con);

                cmd.Parameters.AddWithValue("@nombre", nombreUsuario);
                cmd.Parameters.AddWithValue("@login", login);
                cmd.Parameters.AddWithValue("@contrasena", contrasena);
                cmd.Parameters.AddWithValue("@rol", esAdmin ? "Administrador" : "Cliente");

                if (esAdmin)
                    cmd.Parameters.AddWithValue("@codigo", codigoAdmin);
                else
                    cmd.Parameters.AddWithValue("@codigo", DBNull.Value);

                try
                {
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (SqlException ex)
                {
                    throw new Exception("Error al crear el usuario: " + ex.Message);
                }
            }
        }
    }
}
