﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.Data
{
    public static class Sesion
    {
        public static int ID_Usuario { get; set; }
        public static string NombreUsuario { get; set; }
        public static string Rol { get; set; }

    }
}
