﻿using Desafio3Farmacia.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafio3Farmacia.DataAdmin
{
    public class FarmaciaManager
    {
        private readonly Repositorio repo = new Repositorio();


        public DataTable ObtenerMedicamentos()
        {
            return repo.ObtenerTodos("Medicamento");
        }

        public DataTable BuscarMedicamentos(string columna, string valor)
        {
            return repo.Buscar("Medicamento", columna, valor);
        }

        public DataTable ObtenerCategorias()
        {
            return repo.ObtenerTodos("Categoria");
        }

        public DataTable BuscarCategorias(string columna, string valor)
        {
            return repo.Buscar("Categoria", columna, valor);
        }

        public bool ActualizarCategoria(int idCategoria, string nuevoNombre, string nuevaDescripcion)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string query = "UPDATE Categoria SET Nombre_Categoria=@nombre, Descripcion=@desc WHERE ID_Categoria=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nombre", nuevoNombre);
                cmd.Parameters.AddWithValue("@desc", nuevaDescripcion);
                cmd.Parameters.AddWithValue("@id", idCategoria);
                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool RegistrarCategoria(string nombre, string descripcion)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
               
                string check = "SELECT COUNT(*) FROM Categoria WHERE Nombre_Categoria = @nombre";
                SqlCommand cmdCheck = new SqlCommand(check, con);
                cmdCheck.Parameters.AddWithValue("@nombre", nombre);
                con.Open();
                int existe = (int)cmdCheck.ExecuteScalar();
                if (existe > 0)
                {
                    MessageBox.Show("⚠️ La categoría ya existe.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                con.Close();

    
                string insert = "INSERT INTO Categoria (Nombre_Categoria, Descripcion) VALUES (@nombre, @desc)";
                SqlCommand cmdInsert = new SqlCommand(insert, con);
                cmdInsert.Parameters.AddWithValue("@nombre", nombre);
                cmdInsert.Parameters.AddWithValue("@desc", descripcion);
                con.Open();
                return cmdInsert.ExecuteNonQuery() > 0;
            }
        }

      
        public void RegistrarCompra(int idMedicamento, int cantidad)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();

                try
                {
                   
                    string updateStock = "UPDATE Medicamento SET Stock = Stock + @cantidad WHERE ID_Medicamento = @id";
                    SqlCommand cmd1 = new SqlCommand(updateStock, con, trans);
                    cmd1.Parameters.AddWithValue("@cantidad", cantidad);
                    cmd1.Parameters.AddWithValue("@id", idMedicamento);
                    cmd1.ExecuteNonQuery();

                
                    string insertCompra = "INSERT INTO Compra (ID_Proveedor, Total) VALUES (1, 0)";
                    SqlCommand cmd2 = new SqlCommand(insertCompra, con, trans);
                    cmd2.ExecuteNonQuery();

                    trans.Commit();
                    MessageBox.Show("✅ Compra registrada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    MessageBox.Show("❌ Error al registrar la compra: " + ex.Message);
                }
            }
        }
    }
}
