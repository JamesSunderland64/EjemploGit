﻿using Desafio3Farmacia.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.DataAdmin
{
    public class InventarioService
    {
        public DataTable ObtenerMedicamentos()
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = @"SELECT ID_Medicamento, Nombre, Descripcion, ID_Categoria, Precio_Compra, Precio_Venta, Stock, Fecha_Registro, ID_Proveedor, Imagen
                             FROM Medicamento";
                DataTable dt = new DataTable();
                new SqlDataAdapter(q, con).Fill(dt);
                return dt;
            }
        }

      
        public DataTable BuscarMedicamentos(string columna, string valor)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = $"SELECT ID_Medicamento, Nombre, Descripcion, ID_Categoria, Precio_Compra, Precio_Venta, Stock, Fecha_Registro, ID_Proveedor, Imagen FROM Medicamento WHERE {columna} LIKE @v";
                SqlDataAdapter da = new SqlDataAdapter(q, con);
                da.SelectCommand.Parameters.AddWithValue("@v", "%" + valor + "%");
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

    
        public bool ExisteMedicamentoMismoProveedor(string nombre, int idProveedor)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = "SELECT COUNT(*) FROM Medicamento WHERE Nombre = @n AND ID_Proveedor = @p";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@p", idProveedor);
                con.Open();
                int c = (int)cmd.ExecuteScalar();
                return c > 0;
            }
        }


        public bool GuardarMedicamento(string nombre, string descripcion, int idCategoria,
            decimal precioCompra, decimal precioVenta, int stock, DateTime fechaRegistro, int idProveedor, byte[] imagen)
        {
          
            if (ExisteMedicamentoMismoProveedor(nombre, idProveedor))
                return false;

            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = @"INSERT INTO Medicamento
                             (Nombre, Descripcion, ID_Categoria, Precio_Compra, Precio_Venta, Stock, Fecha_Registro, ID_Proveedor, Imagen)
                             VALUES (@n,@d,@cat,@pc,@pv,@stock,@fr,@prov,@img)";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@d", (object)descripcion ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@cat", idCategoria);
                cmd.Parameters.AddWithValue("@pc", precioCompra);
                cmd.Parameters.AddWithValue("@pv", precioVenta);
                cmd.Parameters.AddWithValue("@stock", stock);
                cmd.Parameters.AddWithValue("@fr", fechaRegistro);
                cmd.Parameters.AddWithValue("@prov", idProveedor);
                cmd.Parameters.Add("@img", SqlDbType.VarBinary).Value = (object)imagen ?? DBNull.Value;

                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

       
        public bool ActualizarMedicamento(int idMedicamento, string nombre, string descripcion, int idCategoria,
            decimal precioCompra, decimal precioVenta, int stock, DateTime fechaRegistro, int idProveedor, byte[] imagen)
        {
        
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string check = "SELECT COUNT(*) FROM Medicamento WHERE Nombre=@n AND ID_Proveedor=@p AND ID_Medicamento<>@id";
                SqlCommand cmdCheck = new SqlCommand(check, con);
                cmdCheck.Parameters.AddWithValue("@n", nombre);
                cmdCheck.Parameters.AddWithValue("@p", idProveedor);
                cmdCheck.Parameters.AddWithValue("@id", idMedicamento);
                con.Open();
                int exist = (int)cmdCheck.ExecuteScalar();
                if (exist > 0) return false;
                con.Close();
            }

            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = @"UPDATE Medicamento SET Nombre=@n, Descripcion=@d, ID_Categoria=@cat, Precio_Compra=@pc,
                             Precio_Venta=@pv, Stock=@stock, Fecha_Registro=@fr, ID_Proveedor=@prov, Imagen=@img
                             WHERE ID_Medicamento=@id";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@d", (object)descripcion ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@cat", idCategoria);
                cmd.Parameters.AddWithValue("@pc", precioCompra);
                cmd.Parameters.AddWithValue("@pv", precioVenta);
                cmd.Parameters.AddWithValue("@stock", stock);
                cmd.Parameters.AddWithValue("@fr", fechaRegistro);
                cmd.Parameters.AddWithValue("@prov", idProveedor);
                cmd.Parameters.AddWithValue("@id", idMedicamento);
                cmd.Parameters.Add("@img", SqlDbType.VarBinary).Value = (object)imagen ?? DBNull.Value;

                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

    
        public bool EliminarMedicamentoCascade(int idMedicamento)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();
                SqlTransaction tr = con.BeginTransaction();
                try
                {
             
                    string d1 = "DELETE FROM Detalle_Venta WHERE ID_Medicamento = @id";
                    var cmd1 = new SqlCommand(d1, con, tr);
                    cmd1.Parameters.AddWithValue("@id", idMedicamento);
                    cmd1.ExecuteNonQuery();

                    string d2 = "DELETE FROM Detalle_Compra WHERE ID_Medicamento = @id";
                    var cmd2 = new SqlCommand(d2, con, tr);
                    cmd2.Parameters.AddWithValue("@id", idMedicamento);
                    cmd2.ExecuteNonQuery();

         
       
                    string d3 = "DELETE FROM Medicamento WHERE ID_Medicamento = @id";
                    var cmd3 = new SqlCommand(d3, con, tr);
                    cmd3.Parameters.AddWithValue("@id", idMedicamento);
                    int affected = cmd3.ExecuteNonQuery();

                    tr.Commit();
                    return affected > 0;
                }
                catch
                {
                    tr.Rollback();
                    throw;
                }
            }
        }

        public DataTable ObtenerProveedores()
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = "SELECT ID_Proveedor, Nombre, Telefono, Direccion, Correo FROM Proveedor";
                DataTable dt = new DataTable();
                new SqlDataAdapter(q, con).Fill(dt);
                return dt;
            }
        }

        public DataTable BuscarProveedores(string columna, string valor)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = $"SELECT ID_Proveedor, Nombre, Telefono, Direccion, Correo FROM Proveedor WHERE {columna} LIKE @v";
                SqlDataAdapter da = new SqlDataAdapter(q, con);
                da.SelectCommand.Parameters.AddWithValue("@v", "%" + valor + "%");
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public bool ExisteProveedorPorNombre(string nombre)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = "SELECT COUNT(*) FROM Proveedor WHERE Nombre = @n";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                con.Open();
                int c = (int)cmd.ExecuteScalar();
                return c > 0;
            }
        }

        public bool GuardarProveedor(string nombre, string telefono, string direccion, string correo)
        {
            if (ExisteProveedorPorNombre(nombre)) return false;

            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = "INSERT INTO Proveedor (Nombre, Telefono, Direccion, Correo) VALUES (@n,@t,@d,@c)";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@t", (object)telefono ?? DBNull.Value);
                
            }
       
            return true;
        }


        public bool GuardarProveedorCorrecto(string nombre, string telefono, string direccion, string correo)
        {
            if (ExisteProveedorPorNombre(nombre)) return false;
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = "INSERT INTO Proveedor (Nombre, Telefono, Direccion, Correo) VALUES (@n,@t,@d,@c)";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@t", (object)telefono ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@d", (object)direccion ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@c", (object)correo ?? DBNull.Value);
                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool ActualizarProveedor(int idProveedor, string nombre, string telefono, string direccion, string correo)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string q = @"UPDATE Proveedor SET Nombre=@n, Telefono=@t, Direccion=@d, Correo=@c WHERE ID_Proveedor=@id";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@t", (object)telefono ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@d", (object)direccion ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@c", (object)correo ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@id", idProveedor);
                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }


        public bool EliminarProveedorCascade(int idProveedor)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();
                SqlTransaction tr = con.BeginTransaction();
                try
                {

                    string qMed = "SELECT ID_Medicamento FROM Medicamento WHERE ID_Proveedor = @p";
                    var cmdMed = new SqlCommand(qMed, con, tr);
                    cmdMed.Parameters.AddWithValue("@p", idProveedor);
                    DataTable dtMed = new DataTable();
                    new SqlDataAdapter(cmdMed).Fill(dtMed);

                    foreach (DataRow r in dtMed.Rows)
                    {
                        int idMed = Convert.ToInt32(r["ID_Medicamento"]);
                        var delDventa = new SqlCommand("DELETE FROM Detalle_Venta WHERE ID_Medicamento = @id", con, tr);
                        delDventa.Parameters.AddWithValue("@id", idMed);
                        delDventa.ExecuteNonQuery();

                        var delDcompra = new SqlCommand("DELETE FROM Detalle_Compra WHERE ID_Medicamento = @id", con, tr);
                        delDcompra.Parameters.AddWithValue("@id", idMed);
                        delDcompra.ExecuteNonQuery();

                        var delMed = new SqlCommand("DELETE FROM Medicamento WHERE ID_Medicamento = @id", con, tr);
                        delMed.Parameters.AddWithValue("@id", idMed);
                        delMed.ExecuteNonQuery();
                    }

                    var delProv = new SqlCommand("DELETE FROM Proveedor WHERE ID_Proveedor = @p", con, tr);
                    delProv.Parameters.AddWithValue("@p", idProveedor);
                    int affected = delProv.ExecuteNonQuery();

                    tr.Commit();
                    return affected > 0;
                }
                catch
                {
                    tr.Rollback();
                    throw;
                }
            }
        }


        public byte[] ImagenABytes(Image img)
        {
            if (img == null) return null;
            using (MemoryStream ms = new MemoryStream())
            {
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        public Image BytesAImagen(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0) return null;
            using (MemoryStream ms = new MemoryStream(bytes))
                return Image.FromStream(ms);
        }
    }
}

