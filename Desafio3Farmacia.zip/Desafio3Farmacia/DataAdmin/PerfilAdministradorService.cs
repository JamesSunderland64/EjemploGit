﻿using Desafio3Farmacia.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.DataAdmin
{
    public class PerfilAdministradorService
    {

        public (DataRow admin, DataRow user) CargarPerfil(int idUsuario)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();

                DataTable dtAdmin = new DataTable();
                DataTable dtUser = new DataTable();


                using (SqlCommand cmdUser = new SqlCommand(
                    "SELECT * FROM Usuario WHERE ID_Usuario = @id", con))
                {
                    cmdUser.Parameters.AddWithValue("@id", idUsuario);
                    new SqlDataAdapter(cmdUser).Fill(dtUser);
                }


                using (SqlCommand cmdAdmin = new SqlCommand(
                    "SELECT * FROM Administrador WHERE ID_Usuario = @id", con))
                {
                    cmdAdmin.Parameters.AddWithValue("@id", idUsuario);
                    new SqlDataAdapter(cmdAdmin).Fill(dtAdmin);
                }

                return (dtAdmin.Rows.Count > 0 ? dtAdmin.Rows[0] : null,
                        dtUser.Rows.Count > 0 ? dtUser.Rows[0] : null);
            }
        }


        public void CrearAdministrador(string nombre, string apellido, string correo, string cargo, string telefono, byte[] foto, int idUsuario)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();

                string query = @"INSERT INTO Administrador (Nombre_Admin, Apellido_Admin, Correo, Cargo, Telefono, Foto, ID_Usuario)
                                 VALUES (@n, @a, @c, @ca, @t, @f, @id)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@a", apellido);
                cmd.Parameters.AddWithValue("@c", correo);
                cmd.Parameters.AddWithValue("@ca", cargo);
                cmd.Parameters.AddWithValue("@t", telefono);
                cmd.Parameters.AddWithValue("@id", idUsuario);
                cmd.Parameters.Add("@f", SqlDbType.VarBinary).Value = (object)foto ?? DBNull.Value;

                cmd.ExecuteNonQuery();
            }
        }

        public void ActualizarAdministrador(string nombre, string apellido, string correo, string cargo, string telefono, byte[] foto, int idUsuario)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();

                string query = @"UPDATE Administrador
                                 SET Nombre_Admin = @n, Apellido_Admin = @a, Correo = @c, Cargo = @ca,
                                     Telefono = @t, Foto = @f
                                 WHERE ID_Usuario = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@a", apellido);
                cmd.Parameters.AddWithValue("@c", correo);
                cmd.Parameters.AddWithValue("@ca", cargo);
                cmd.Parameters.AddWithValue("@t", telefono);
                cmd.Parameters.AddWithValue("@id", idUsuario);
                cmd.Parameters.Add("@f", SqlDbType.VarBinary).Value = (object)foto ?? DBNull.Value;

                cmd.ExecuteNonQuery();
            }
        }


        public void ActualizarUsuario(int idUsuario, string nombreUsuario, string usuarioLogin, string contraseña, string codigoAdmin)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                con.Open();

                string query = @"UPDATE Usuario
                                 SET Nombre_Usuario = @n, Usuario_Login = @u, Contraseña = @c, CodigoAdmin = @cod
                                 WHERE ID_Usuario = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@n", nombreUsuario);
                cmd.Parameters.AddWithValue("@u", usuarioLogin);
                cmd.Parameters.AddWithValue("@c", contraseña);
                cmd.Parameters.AddWithValue("@cod", (object)codigoAdmin ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@id", idUsuario);

                cmd.ExecuteNonQuery();
            }
        }


        public Image ConvertirImagen(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0) return null;
            using (MemoryStream ms = new MemoryStream(bytes))
                return Image.FromStream(ms);
        }


        public byte[] ImagenABytes(Image img)
        {
            if (img == null) return null;
            using (MemoryStream ms = new MemoryStream())
            {
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }
    }
}
