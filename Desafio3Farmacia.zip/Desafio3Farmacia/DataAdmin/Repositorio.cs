﻿using Desafio3Farmacia.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.DataAdmin
{
    public class Repositorio
    {
        public DataTable ObtenerTodos(string tabla)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string query = $"SELECT * FROM {tabla}";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public DataTable Buscar(string tabla, string columna, string valor)
        {
            using (SqlConnection con = Conexion.ObtenerConexion())
            {
                string query = $"SELECT * FROM {tabla} WHERE {columna} LIKE @valor";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@valor", "%" + valor + "%");
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
    }
}
