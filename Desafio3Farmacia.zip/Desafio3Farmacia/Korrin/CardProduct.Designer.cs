﻿namespace Desafio3Farmacia.Korrin
{
    partial class CardProduct
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Morphea1 = new System.Windows.Forms.Button();
            this.Rafina2 = new System.Windows.Forms.Label();
            this.Rafina1 = new System.Windows.Forms.Label();
            this.Helena1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).BeginInit();
            this.SuspendLayout();
            // 
            // Morphea1
            // 
            this.Morphea1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Morphea1.BackColor = System.Drawing.Color.DodgerBlue;
            this.Morphea1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Morphea1.ForeColor = System.Drawing.Color.White;
            this.Morphea1.Location = new System.Drawing.Point(28, 212);
            this.Morphea1.Name = "Morphea1";
            this.Morphea1.Size = new System.Drawing.Size(126, 25);
            this.Morphea1.TabIndex = 7;
            this.Morphea1.Text = "Comprar ahora";
            this.Morphea1.UseVisualStyleBackColor = false;
            this.Morphea1.Click += new System.EventHandler(this.Morphea1_Click_1);
            // 
            // Rafina2
            // 
            this.Rafina2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Rafina2.AutoSize = true;
            this.Rafina2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rafina2.Location = new System.Drawing.Point(73, 189);
            this.Rafina2.Name = "Rafina2";
            this.Rafina2.Size = new System.Drawing.Size(50, 16);
            this.Rafina2.TabIndex = 6;
            this.Rafina2.Text = "label2";
            this.Rafina2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Rafina1
            // 
            this.Rafina1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Rafina1.AutoSize = true;
            this.Rafina1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rafina1.Location = new System.Drawing.Point(42, 155);
            this.Rafina1.Name = "Rafina1";
            this.Rafina1.Size = new System.Drawing.Size(47, 15);
            this.Rafina1.TabIndex = 5;
            this.Rafina1.Text = "label1";
            this.Rafina1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Helena1
            // 
            this.Helena1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Helena1.Location = new System.Drawing.Point(28, 10);
            this.Helena1.Name = "Helena1";
            this.Helena1.Size = new System.Drawing.Size(136, 133);
            this.Helena1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Helena1.TabIndex = 4;
            this.Helena1.TabStop = false;
            // 
            // CardProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.Morphea1);
            this.Controls.Add(this.Rafina2);
            this.Controls.Add(this.Rafina1);
            this.Controls.Add(this.Helena1);
            this.Name = "CardProduct";
            this.Size = new System.Drawing.Size(190, 250);
            this.Load += new System.EventHandler(this.CardProduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Morphea1;
        private System.Windows.Forms.Label Rafina2;
        private System.Windows.Forms.Label Rafina1;
        private System.Windows.Forms.PictureBox Helena1;
    }
}
