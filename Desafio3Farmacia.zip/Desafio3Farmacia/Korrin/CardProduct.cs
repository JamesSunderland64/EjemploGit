﻿using Desafio3Farmacia.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafio3Farmacia.Korrin
{
    public partial class CardProduct : UserControl
    {
        private readonly Medicamento _medicamento;
        private readonly Panel _panelDestino;


        public CardProduct(Medicamento med, Panel panelDestino)
        {
            InitializeComponent();
            _medicamento = med;
            _panelDestino = panelDestino;
            MostrarDatos();
        }
        private void MostrarDatos()
        {
            Rafina1.Text = _medicamento.Nombre;
            Rafina2.Text = "$" + _medicamento.Precio_Venta.ToString("0.00");

            if (_medicamento.Imagen != null)
            {
                using (var ms = new MemoryStream(_medicamento.Imagen))
                {
                    Helena1.Image = Image.FromStream(ms);
                }
            }
        }

        private void CardProduct_Load(object sender, EventArgs e)
        {

        }

        private void Morphea1_Click_1(object sender, EventArgs e)
        {
            _panelDestino.Controls.Clear();
            var detalle = new DetalleProducto(_medicamento, _panelDestino, _medicamento.ID_Categoria)
            {
                Dock = DockStyle.Fill
            };

            _panelDestino.Controls.Add(detalle);

        }
    }
}
