﻿namespace Desafio3Farmacia.Korrin
{
    partial class DetalleProducto
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Morphea2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Morphea1 = new System.Windows.Forms.Button();
            this.Helena1 = new System.Windows.Forms.PictureBox();
            this.Refithea3 = new System.Windows.Forms.Label();
            this.Refithea2 = new System.Windows.Forms.Label();
            this.Refithea1 = new System.Windows.Forms.Label();
            this.Liberta1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).BeginInit();
            this.SuspendLayout();
            // 
            // Morphea2
            // 
            this.Morphea2.Location = new System.Drawing.Point(803, 380);
            this.Morphea2.Name = "Morphea2";
            this.Morphea2.Size = new System.Drawing.Size(75, 23);
            this.Morphea2.TabIndex = 15;
            this.Morphea2.Text = "Volver";
            this.Morphea2.UseVisualStyleBackColor = true;
            this.Morphea2.Click += new System.EventHandler(this.Morphea2_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(526, 288);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 16);
            this.label1.TabIndex = 14;
            this.label1.Text = "Cantidad";
            // 
            // Morphea1
            // 
            this.Morphea1.Location = new System.Drawing.Point(529, 337);
            this.Morphea1.Name = "Morphea1";
            this.Morphea1.Size = new System.Drawing.Size(199, 43);
            this.Morphea1.TabIndex = 12;
            this.Morphea1.Text = "Añadir al Carrito";
            this.Morphea1.UseVisualStyleBackColor = true;
            this.Morphea1.Click += new System.EventHandler(this.Morphea1_Click_1);
            // 
            // Helena1
            // 
            this.Helena1.Location = new System.Drawing.Point(68, 61);
            this.Helena1.Name = "Helena1";
            this.Helena1.Size = new System.Drawing.Size(412, 319);
            this.Helena1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Helena1.TabIndex = 11;
            this.Helena1.TabStop = false;
            // 
            // Refithea3
            // 
            this.Refithea3.AutoSize = true;
            this.Refithea3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Refithea3.Location = new System.Drawing.Point(525, 246);
            this.Refithea3.Name = "Refithea3";
            this.Refithea3.Size = new System.Drawing.Size(59, 20);
            this.Refithea3.TabIndex = 10;
            this.Refithea3.Text = "label3";
            // 
            // Refithea2
            // 
            this.Refithea2.AutoSize = true;
            this.Refithea2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Refithea2.Location = new System.Drawing.Point(526, 103);
            this.Refithea2.Name = "Refithea2";
            this.Refithea2.Size = new System.Drawing.Size(50, 16);
            this.Refithea2.TabIndex = 9;
            this.Refithea2.Text = "label2";
            // 
            // Refithea1
            // 
            this.Refithea1.AutoSize = true;
            this.Refithea1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Refithea1.Location = new System.Drawing.Point(525, 61);
            this.Refithea1.Name = "Refithea1";
            this.Refithea1.Size = new System.Drawing.Size(59, 20);
            this.Refithea1.TabIndex = 8;
            this.Refithea1.Text = "label1";
            // 
            // Liberta1
            // 
            this.Liberta1.Location = new System.Drawing.Point(615, 282);
            this.Liberta1.Name = "Liberta1";
            this.Liberta1.Size = new System.Drawing.Size(113, 22);
            this.Liberta1.TabIndex = 16;
            this.Liberta1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Liberta1_KeyPress);
            // 
            // DetalleProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.Liberta1);
            this.Controls.Add(this.Morphea1);
            this.Controls.Add(this.Morphea2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Helena1);
            this.Controls.Add(this.Refithea3);
            this.Controls.Add(this.Refithea2);
            this.Controls.Add(this.Refithea1);
            this.Name = "DetalleProducto";
            this.Size = new System.Drawing.Size(965, 462);
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Morphea2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Morphea1;
        private System.Windows.Forms.PictureBox Helena1;
        private System.Windows.Forms.Label Refithea3;
        private System.Windows.Forms.Label Refithea2;
        private System.Windows.Forms.Label Refithea1;
        private System.Windows.Forms.TextBox Liberta1;
    }
}
