﻿using Desafio3Farmacia.Models;
using Desafio3Farmacia.Vistas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafio3Farmacia.Korrin
{
    public partial class DetalleProducto : UserControl
    {
        private readonly Medicamento _med;
        private readonly Panel _panelDestino;
        private readonly int _idCategoria;
        public DetalleProducto(Medicamento med, Panel panelDestino, int idCategoria)
        {
            InitializeComponent();
            _med = med;
            _panelDestino = panelDestino;
            _idCategoria = idCategoria;

            Morphea1.Click += Morphea1_Click_1; 
            Morphea2.Click += Morphea2_Click_1; 
            Liberta1.KeyPress += Liberta1_KeyPress; 

            CargarDatos();
        }

        private void CargarDatos()
        {
            Refithea1.Text = _med.Nombre;
            Refithea2.Text = _med.Descripcion;
            Refithea3.Text = "$" + _med.Precio_Venta.ToString("0.00");

            if (_med.Imagen != null)
            {
                using (var ms = new MemoryStream(_med.Imagen))
                {
                    Helena1.Image = Image.FromStream(ms);
                }
            }

         
            Liberta1.Text = "1"; 
            Liberta1.Enabled = _med.Stock > 0;
            Liberta1.BringToFront();

            Morphea1.Enabled = _med.Stock > 0;
            Morphea1.BringToFront();

            if (_med.Stock == 0)
            {
                Refithea2.Text += "\n\n⚠ Producto agotado.";
            }

        }     

        private void Morphea1_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(Liberta1.Text))
                {
                    MessageBox.Show("Por favor, ingresa una cantidad.", "Cantidad requerida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(Liberta1.Text.Trim(), out int cantidad))
                {
                    MessageBox.Show("Ingresa un número válido.", "Cantidad inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cantidad <= 0)
                {
                    MessageBox.Show("La cantidad debe ser mayor que cero.", "Cantidad inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int cantidadMaxima = Math.Min(20, _med.Stock);
                if (cantidad > cantidadMaxima)
                {
                    MessageBox.Show($"Solo puedes agregar hasta {cantidadMaxima} unidades disponibles.", "Stock limitado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var existente = PaginaPrincipal.Carrito.FirstOrDefault(d => d.ID_Medicamento == _med.ID_Medicamento);

                if (existente != null)
                {
                    int nuevaCantidad = existente.Cantidad + cantidad;

                    if (nuevaCantidad > cantidadMaxima)
                    {
                        MessageBox.Show($"No puedes agregar más unidades.\nDisponibles: {cantidadMaxima - existente.Cantidad}", "Stock insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    existente.Cantidad = nuevaCantidad;
                }
                else
                {
                    var detalle = new DetalleVenta
                    {
                        ID_Medicamento = _med.ID_Medicamento,
                        Cantidad = cantidad,
                        PrecioUnitario = _med.Precio_Venta
                    };

                    PaginaPrincipal.Carrito.Add(detalle);
                }

                MessageBox.Show($"✅ '{_med.Nombre}' agregado al carrito.", "Carrito actualizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error al agregar el producto: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Morphea2_Click_1(object sender, EventArgs e)
        {
            _panelDestino.Controls.Clear();


            if (Application.OpenForms.OfType<PaginaPrincipal>().FirstOrDefault() is PaginaPrincipal main)
            {
                if (main.CategoriaActual != null)
                {
                    _panelDestino.Controls.Add(main.CategoriaActual);
                }
                else
                {

                    var inicio = new VistaGeneral(_panelDestino);
                    inicio.Dock = DockStyle.Fill;
                    _panelDestino.Controls.Add(inicio);
                }
            }
        }

        private void Liberta1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true; 
        }
    }
}
