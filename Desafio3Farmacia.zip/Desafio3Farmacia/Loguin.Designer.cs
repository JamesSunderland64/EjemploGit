﻿namespace Desafio3Farmacia
{
    partial class Loguin
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.Morphea2 = new System.Windows.Forms.Button();
            this.Helena3 = new System.Windows.Forms.PictureBox();
            this.Celia3 = new System.Windows.Forms.TextBox();
            this.Morphea1 = new System.Windows.Forms.Button();
            this.Helena2 = new System.Windows.Forms.PictureBox();
            this.Helena1 = new System.Windows.Forms.PictureBox();
            this.Celia2 = new System.Windows.Forms.TextBox();
            this.Celia1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Olstenin1 = new System.Windows.Forms.LinkLabel();
            this.Morphea3 = new System.Windows.Forms.Button();
            this.Sylvia2 = new System.Windows.Forms.RadioButton();
            this.Sylvia1 = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Helena3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.GreenYellow;
            this.splitContainer1.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.splitContainer1.Panel1.Controls.Add(this.Morphea2);
            this.splitContainer1.Panel1.Controls.Add(this.Helena3);
            this.splitContainer1.Panel1.Controls.Add(this.Celia3);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea1);
            this.splitContainer1.Panel1.Controls.Add(this.Helena2);
            this.splitContainer1.Panel1.Controls.Add(this.Helena1);
            this.splitContainer1.Panel1.Controls.Add(this.Celia2);
            this.splitContainer1.Panel1.Controls.Add(this.Celia1);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.Olstenin1);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.BlueViolet;
            this.splitContainer1.Panel2.Controls.Add(this.Sylvia2);
            this.splitContainer1.Panel2.Controls.Add(this.Sylvia1);
            this.splitContainer1.Panel2.Controls.Add(this.label10);
            this.splitContainer1.Panel2.Controls.Add(this.label9);
            this.splitContainer1.Panel2.Controls.Add(this.label8);
            this.splitContainer1.Panel2.Controls.Add(this.label7);
            this.splitContainer1.Panel2.Controls.Add(this.label6);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Size = new System.Drawing.Size(942, 483);
            this.splitContainer1.SplitterDistance = 525;
            this.splitContainer1.TabIndex = 0;
            // 
            // Morphea2
            // 
            this.Morphea2.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._81986e543fc3fe544c764fd4d0012289;
            this.Morphea2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea2.Location = new System.Drawing.Point(412, 284);
            this.Morphea2.Name = "Morphea2";
            this.Morphea2.Size = new System.Drawing.Size(44, 35);
            this.Morphea2.TabIndex = 12;
            this.Morphea2.UseVisualStyleBackColor = true;
            this.Morphea2.Click += new System.EventHandler(this.Morphea2_Click);
            // 
            // Helena3
            // 
            this.Helena3.Location = new System.Drawing.Point(79, 285);
            this.Helena3.Name = "Helena3";
            this.Helena3.Size = new System.Drawing.Size(43, 34);
            this.Helena3.TabIndex = 11;
            this.Helena3.TabStop = false;
            // 
            // Celia3
            // 
            this.Celia3.Location = new System.Drawing.Point(128, 297);
            this.Celia3.Name = "Celia3";
            this.Celia3.PasswordChar = '*';
            this.Celia3.Size = new System.Drawing.Size(262, 22);
            this.Celia3.TabIndex = 10;
            this.Celia3.Enter += new System.EventHandler(this.Celia3_Enter);
            this.Celia3.Leave += new System.EventHandler(this.Celia3_Leave);
            // 
            // Morphea1
            // 
            this.Morphea1.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._81986e543fc3fe544c764fd4d0012289;
            this.Morphea1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea1.Location = new System.Drawing.Point(412, 211);
            this.Morphea1.Name = "Morphea1";
            this.Morphea1.Size = new System.Drawing.Size(44, 35);
            this.Morphea1.TabIndex = 9;
            this.Morphea1.UseVisualStyleBackColor = true;
            this.Morphea1.Click += new System.EventHandler(this.Morphea1_Click);
            // 
            // Helena2
            // 
            this.Helena2.Location = new System.Drawing.Point(79, 212);
            this.Helena2.Name = "Helena2";
            this.Helena2.Size = new System.Drawing.Size(43, 34);
            this.Helena2.TabIndex = 8;
            this.Helena2.TabStop = false;
            // 
            // Helena1
            // 
            this.Helena1.Location = new System.Drawing.Point(79, 141);
            this.Helena1.Name = "Helena1";
            this.Helena1.Size = new System.Drawing.Size(43, 34);
            this.Helena1.TabIndex = 7;
            this.Helena1.TabStop = false;
            // 
            // Celia2
            // 
            this.Celia2.Location = new System.Drawing.Point(128, 224);
            this.Celia2.Name = "Celia2";
            this.Celia2.PasswordChar = '*';
            this.Celia2.Size = new System.Drawing.Size(262, 22);
            this.Celia2.TabIndex = 6;
            this.Celia2.Enter += new System.EventHandler(this.Celia2_Enter);
            this.Celia2.Leave += new System.EventHandler(this.Celia2_Leave);
            // 
            // Celia1
            // 
            this.Celia1.Location = new System.Drawing.Point(128, 153);
            this.Celia1.Name = "Celia1";
            this.Celia1.Size = new System.Drawing.Size(262, 22);
            this.Celia1.TabIndex = 5;
            this.Celia1.Enter += new System.EventHandler(this.Celia1_Enter);
            this.Celia1.Leave += new System.EventHandler(this.Celia1_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(106, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(284, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "Por favor inicia sesion con tu cuenta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(231, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 29);
            this.label2.TabIndex = 3;
            this.label2.Text = "Hola";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(125, 419);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "No tienes cuenta? dale a ";
            // 
            // Olstenin1
            // 
            this.Olstenin1.AutoSize = true;
            this.Olstenin1.Location = new System.Drawing.Point(305, 419);
            this.Olstenin1.Name = "Olstenin1";
            this.Olstenin1.Size = new System.Drawing.Size(85, 16);
            this.Olstenin1.TabIndex = 1;
            this.Olstenin1.TabStop = true;
            this.Olstenin1.Text = "Crear Cuenta";
            this.Olstenin1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Olstenin1_LinkClicked);
            // 
            // Morphea3
            // 
            this.Morphea3.Location = new System.Drawing.Point(179, 352);
            this.Morphea3.Name = "Morphea3";
            this.Morphea3.Size = new System.Drawing.Size(156, 35);
            this.Morphea3.TabIndex = 0;
            this.Morphea3.Text = "Iniciar Sesion";
            this.Morphea3.UseVisualStyleBackColor = true;
            this.Morphea3.Click += new System.EventHandler(this.Morphea3_Click);
            // 
            // Sylvia2
            // 
            this.Sylvia2.AutoSize = true;
            this.Sylvia2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sylvia2.Location = new System.Drawing.Point(184, 356);
            this.Sylvia2.Name = "Sylvia2";
            this.Sylvia2.Size = new System.Drawing.Size(147, 24);
            this.Sylvia2.TabIndex = 8;
            this.Sylvia2.TabStop = true;
            this.Sylvia2.Text = "Administrador";
            this.Sylvia2.UseVisualStyleBackColor = true;
            this.Sylvia2.CheckedChanged += new System.EventHandler(this.Sylvia2_CheckedChanged);
            // 
            // Sylvia1
            // 
            this.Sylvia1.AutoSize = true;
            this.Sylvia1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sylvia1.Location = new System.Drawing.Point(58, 356);
            this.Sylvia1.Name = "Sylvia1";
            this.Sylvia1.Size = new System.Drawing.Size(89, 24);
            this.Sylvia1.TabIndex = 7;
            this.Sylvia1.TabStop = true;
            this.Sylvia1.Text = "Cliente";
            this.Sylvia1.UseVisualStyleBackColor = true;
            this.Sylvia1.CheckedChanged += new System.EventHandler(this.Sylvia1_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 270);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 25);
            this.label10.TabIndex = 6;
            this.label10.Text = "tipo de usuario";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(28, 245);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(326, 25);
            this.label9.TabIndex = 5;
            this.label9.Text = "ingresa tus datos y selecciona el";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(28, 220);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(267, 25);
            this.label8.TabIndex = 4;
            this.label8.Text = "Cliente o un Administrador";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(333, 25);
            this.label7.TabIndex = 3;
            this.label7.Text = "Para asegurarnos de que eres un";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(47, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(311, 25);
            this.label6.TabIndex = 2;
            this.label6.Text = "La Farmacia el Reino Cientifico";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(179, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 25);
            this.label5.TabIndex = 1;
            this.label5.Text = "A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(108, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Hola Bienvenido";
            // 
            // Loguin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 483);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Loguin";
            this.Text = "Inicio de Sesion";
            this.Load += new System.EventHandler(this.Loguin_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Helena3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox Celia2;
        private System.Windows.Forms.TextBox Celia1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel Olstenin1;
        private System.Windows.Forms.Button Morphea3;
        private System.Windows.Forms.PictureBox Helena2;
        private System.Windows.Forms.PictureBox Helena1;
        private System.Windows.Forms.Button Morphea1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton Sylvia2;
        private System.Windows.Forms.RadioButton Sylvia1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox Helena3;
        private System.Windows.Forms.TextBox Celia3;
        private System.Windows.Forms.Button Morphea2;
    }
}

