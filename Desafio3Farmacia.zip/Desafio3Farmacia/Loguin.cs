﻿using Desafio3Farmacia.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Desafio3Farmacia
{
    public partial class Loguin : Form
    {
        
        private LoguinService loginService = new LoguinService();

        public Loguin()
        {
            InitializeComponent();
            SetPlaceholder(Celia1, "Usuario");
            SetPlaceholder(Celia2, "Contraseña");
            SetPlaceholder(Celia3, "Codigo de Administrador");
        }
        private void SetPlaceholder(TextBox textBox, string placeholderText)
        {
            textBox.Text = placeholderText;
            textBox.ForeColor = Color.Gray;


            if (textBox == Celia2)
            {
                textBox.PasswordChar = '\0';
            }
            if (textBox == Celia3)
            {
                textBox.PasswordChar = '\0';
            }
        }
        private void Sylvia1_CheckedChanged(object sender, EventArgs e)
        {
            if (Sylvia1.Checked)
            {
                Celia3.Enabled = false;
                Celia3.Clear();
            }
        }

        private void Sylvia2_CheckedChanged(object sender, EventArgs e)
        {
            if (Sylvia2.Checked)
            {
                Celia3.Enabled = true;
            }

        }

        private void Morphea3_Click(object sender, EventArgs e)
        {

            string usuario = Celia1.Text.Trim();
            string contraseña = Celia2.Text.Trim();
            string codigoAdmin = Celia3.Text.Trim();


            if (string.IsNullOrEmpty(usuario) || usuario == "Usuario")
            {
                MessageBox.Show("Debe ingresar su nombre de usuario.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Celia1.Focus();
                return;
            }

            if (string.IsNullOrEmpty(contraseña) || contraseña == "Contraseña")
            {
                MessageBox.Show("Debe ingresar su contraseña.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Celia2.Focus();
                return;
            }

     
            if (!Sylvia1.Checked && !Sylvia2.Checked)
            {
                MessageBox.Show("Debe seleccionar si es Cliente o Administrador.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            bool esAdmin = Sylvia2.Checked;

            string resultado = loginService.ValidarUsuario(usuario, contraseña, codigoAdmin, esAdmin);

            switch (resultado)
            {
                case "Administrador":
                    MessageBox.Show($"Bienvenido, {Sesion.NombreUsuario}.", "Acceso correcto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    VistaADM vista = new VistaADM(Sesion.ID_Usuario);
                    vista.Show();
                    this.Hide();
                    break;

                case "Cliente":
                    MessageBox.Show($"Bienvenido, {Sesion.NombreUsuario}.", "Acceso correcto", MessageBoxButtons.OK, MessageBoxIcon.Information);

             
                    PaginaPrincipal cliente = new PaginaPrincipal(Sesion.ID_Usuario);
                    cliente.Show();
                    this.Hide();
                    break;

                case "ErrorRol":
                    MessageBox.Show("El tipo de usuario seleccionado no coincide con las credenciales.", "Error de rol", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;

                case "CodigoIncorrecto":
                    MessageBox.Show("Código de administrador incorrecto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;

                case null:
                    MessageBox.Show("Usuario o contraseña incorrectos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;

                default:
                    MessageBox.Show("Error desconocido al iniciar sesión.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void Morphea2_Click(object sender, EventArgs e)
        {
           
            if (Celia3.PasswordChar == '*')
            {
               
                Celia3.PasswordChar = '\0'; 
       
                Morphea2.BackgroundImage = Properties.Resources.c8d9fdb13ae708e23e2ba8be3c9bc135;
            }
            else
            {
                Celia3.PasswordChar = '*';
                Morphea2.BackgroundImage = Properties.Resources._81986e543fc3fe544c764fd4d0012289;
            }
        }

        private void Morphea1_Click(object sender, EventArgs e)
        {
          
            if (Celia2.PasswordChar == '*')
            {
              
                Celia2.PasswordChar = '\0';
            
                Morphea1.BackgroundImage = Properties.Resources.c8d9fdb13ae708e23e2ba8be3c9bc135;
            }
            else
            {
    
                Celia2.PasswordChar = '*';
                Morphea1.BackgroundImage = Properties.Resources._81986e543fc3fe544c764fd4d0012289;
            }
        }

        private void Celia1_Enter(object sender, EventArgs e)
        {
            if (Celia1.Text == "Usuario" && Celia1.ForeColor == Color.Gray)
            {
                Celia1.Text = "";
                Celia1.ForeColor = Color.Black;
            }
        }

        private void Celia2_Enter(object sender, EventArgs e)
        {
            if (Celia2.Text == "Contraseña" && Celia2.ForeColor == Color.Gray)
            {
                Celia2.Text = "";
                Celia2.ForeColor = Color.Black;
             
                Celia2.PasswordChar = '*';
            }
        }
        private void Celia3_Enter(object sender, EventArgs e)
        {
            if (Celia3.Text == "Codigo de Administrador" && Celia3.ForeColor == Color.Gray)
            {
                Celia3.Text = "";
                Celia3.ForeColor = Color.Black;
 
                Celia3.PasswordChar = '*';
            }
        }

        private void Celia1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Celia1.Text))
            {
                Celia1.Text = "Usuario";
                Celia1.ForeColor = Color.Gray;
            }
        }

        private void Celia2_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Celia2.Text))
            {
                Celia2.Text = "Contraseña";
                Celia2.ForeColor = Color.Gray;
        
                Celia2.PasswordChar = '\0';
            }
        }

        private void Celia3_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Celia3.Text))
            {
                Celia3.Text = "Codigo de Administrador";
                Celia3.ForeColor = Color.Gray;
                Celia3.PasswordChar = '\0';
            }
        }

        private void Loguin_Load(object sender, EventArgs e)
        {
            Celia3.Enabled = false;
        }

        private void Olstenin1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegistroDeCuenta BB = new RegistroDeCuenta();
            BB.ShowDialog();

        }
    }
}
