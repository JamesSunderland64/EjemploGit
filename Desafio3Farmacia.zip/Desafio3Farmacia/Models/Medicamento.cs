﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.Models
{
    public class Medicamento
    {
        public int ID_Medicamento { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public int ID_Categoria { get; set; }
        public decimal Precio_Compra { get; set; }
        public decimal Precio_Venta { get; set; }
        public int Stock { get; set; }
        public DateTime Fecha_Registro { get; set; }
        public byte[] Imagen { get; set; }
        public int? ID_Proveedor { get; set; }
    }
}
