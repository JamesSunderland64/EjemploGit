﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio3Farmacia.Models
{
    public class Usuario
    {
        public int ID_Usuario { get; set; }
        public string Nombre_Usuario { get; set; }
        public string Usuario_Login { get; set; }
        public string Contraseña { get; set; }
        public string Rol { get; set; }
        public string CodigoAdmin { get; set; }
    }
}
