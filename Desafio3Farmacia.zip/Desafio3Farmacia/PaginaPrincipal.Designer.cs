﻿namespace Desafio3Farmacia
{
    partial class PaginaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.Morphea13 = new System.Windows.Forms.Button();
            this.Morphea12 = new System.Windows.Forms.Button();
            this.Morphea8 = new System.Windows.Forms.Button();
            this.Morphea11 = new System.Windows.Forms.Button();
            this.Morphea7 = new System.Windows.Forms.Button();
            this.Morphea6 = new System.Windows.Forms.Button();
            this.Morphea5 = new System.Windows.Forms.Button();
            this.Morphea4 = new System.Windows.Forms.Button();
            this.Morphea10 = new System.Windows.Forms.Button();
            this.Morphea3 = new System.Windows.Forms.Button();
            this.Morphea2 = new System.Windows.Forms.Button();
            this.Morphea1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Sherazade1 = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.Lime;
            this.splitContainer1.Panel1.Controls.Add(this.Morphea13);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea12);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea8);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea11);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox5);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea7);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea6);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea5);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea4);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea10);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea3);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea2);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea1);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.AutoScroll = true;
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Size = new System.Drawing.Size(1062, 653);
            this.splitContainer1.SplitterDistance = 188;
            this.splitContainer1.TabIndex = 0;
            // 
            // Morphea13
            // 
            this.Morphea13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Morphea13.Location = new System.Drawing.Point(26, 115);
            this.Morphea13.Name = "Morphea13";
            this.Morphea13.Size = new System.Drawing.Size(129, 32);
            this.Morphea13.TabIndex = 18;
            this.Morphea13.Text = "Finalizar Compra";
            this.Morphea13.UseVisualStyleBackColor = false;
            this.Morphea13.Click += new System.EventHandler(this.Morphea13_Click);
            // 
            // Morphea12
            // 
            this.Morphea12.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._8;
            this.Morphea12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea12.Location = new System.Drawing.Point(847, 107);
            this.Morphea12.Name = "Morphea12";
            this.Morphea12.Size = new System.Drawing.Size(65, 50);
            this.Morphea12.TabIndex = 17;
            this.Morphea12.UseVisualStyleBackColor = true;
            this.Morphea12.Click += new System.EventHandler(this.Morphea12_Click);
            // 
            // Morphea8
            // 
            this.Morphea8.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._7;
            this.Morphea8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea8.Location = new System.Drawing.Point(766, 106);
            this.Morphea8.Name = "Morphea8";
            this.Morphea8.Size = new System.Drawing.Size(65, 50);
            this.Morphea8.TabIndex = 16;
            this.Morphea8.UseVisualStyleBackColor = true;
            this.Morphea8.Click += new System.EventHandler(this.Morphea8_Click);
            // 
            // Morphea11
            // 
            this.Morphea11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Morphea11.Location = new System.Drawing.Point(29, 26);
            this.Morphea11.Name = "Morphea11";
            this.Morphea11.Size = new System.Drawing.Size(126, 37);
            this.Morphea11.TabIndex = 15;
            this.Morphea11.Text = "SALIR";
            this.Morphea11.UseVisualStyleBackColor = false;
            this.Morphea11.Click += new System.EventHandler(this.Morphea11_Click);
            // 
            // Morphea7
            // 
            this.Morphea7.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._6;
            this.Morphea7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea7.Location = new System.Drawing.Point(685, 106);
            this.Morphea7.Name = "Morphea7";
            this.Morphea7.Size = new System.Drawing.Size(65, 50);
            this.Morphea7.TabIndex = 13;
            this.Morphea7.UseVisualStyleBackColor = true;
            this.Morphea7.Click += new System.EventHandler(this.Morphea7_Click);
            // 
            // Morphea6
            // 
            this.Morphea6.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._5;
            this.Morphea6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea6.Location = new System.Drawing.Point(603, 106);
            this.Morphea6.Name = "Morphea6";
            this.Morphea6.Size = new System.Drawing.Size(65, 50);
            this.Morphea6.TabIndex = 12;
            this.Morphea6.UseVisualStyleBackColor = true;
            this.Morphea6.Click += new System.EventHandler(this.Morphea6_Click);
            // 
            // Morphea5
            // 
            this.Morphea5.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._4;
            this.Morphea5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea5.Location = new System.Drawing.Point(522, 106);
            this.Morphea5.Name = "Morphea5";
            this.Morphea5.Size = new System.Drawing.Size(65, 50);
            this.Morphea5.TabIndex = 11;
            this.Morphea5.UseVisualStyleBackColor = true;
            this.Morphea5.Click += new System.EventHandler(this.Morphea5_Click);
            // 
            // Morphea4
            // 
            this.Morphea4.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._2;
            this.Morphea4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea4.Location = new System.Drawing.Point(440, 106);
            this.Morphea4.Name = "Morphea4";
            this.Morphea4.Size = new System.Drawing.Size(65, 50);
            this.Morphea4.TabIndex = 10;
            this.Morphea4.UseVisualStyleBackColor = true;
            this.Morphea4.Click += new System.EventHandler(this.Morphea4_Click);
            // 
            // Morphea10
            // 
            this.Morphea10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Morphea10.Location = new System.Drawing.Point(930, 94);
            this.Morphea10.Name = "Morphea10";
            this.Morphea10.Size = new System.Drawing.Size(89, 28);
            this.Morphea10.TabIndex = 9;
            this.Morphea10.Text = "Perfil";
            this.Morphea10.UseVisualStyleBackColor = false;
            this.Morphea10.Click += new System.EventHandler(this.Morphea10_Click);
            // 
            // Morphea3
            // 
            this.Morphea3.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._1;
            this.Morphea3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Morphea3.Location = new System.Drawing.Point(360, 106);
            this.Morphea3.Name = "Morphea3";
            this.Morphea3.Size = new System.Drawing.Size(65, 50);
            this.Morphea3.TabIndex = 8;
            this.Sherazade1.SetToolTip(this.Morphea3, "Seccion de Funcionamiento Gastroitestinal");
            this.Morphea3.UseVisualStyleBackColor = true;
            this.Morphea3.Click += new System.EventHandler(this.Morphea3_Click);
            // 
            // Morphea2
            // 
            this.Morphea2.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._3;
            this.Morphea2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Morphea2.Location = new System.Drawing.Point(279, 106);
            this.Morphea2.Name = "Morphea2";
            this.Morphea2.Size = new System.Drawing.Size(65, 50);
            this.Morphea2.TabIndex = 7;
            this.Sherazade1.SetToolTip(this.Morphea2, "Seccion de Funcionamiento Respiratorio");
            this.Morphea2.UseVisualStyleBackColor = true;
            this.Morphea2.Click += new System.EventHandler(this.Morphea2_Click);
            // 
            // Morphea1
            // 
            this.Morphea1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Morphea1.Location = new System.Drawing.Point(191, 106);
            this.Morphea1.Name = "Morphea1";
            this.Morphea1.Size = new System.Drawing.Size(71, 50);
            this.Morphea1.TabIndex = 6;
            this.Morphea1.Text = "General";
            this.Sherazade1.SetToolTip(this.Morphea1, "Pagina Principal");
            this.Morphea1.UseVisualStyleBackColor = false;
            this.Morphea1.Click += new System.EventHandler(this.Morphea1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(416, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(317, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "\"Tu Salud: La Misión Principal.\"";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(403, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(352, 36);
            this.label1.TabIndex = 2;
            this.label1.Text = "El Reino de la Medicina";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Desafio3Farmacia.Properties.Resources.unnamed;
            this.pictureBox1.Location = new System.Drawing.Point(308, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(79, 58);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1062, 461);
            this.panel2.TabIndex = 0;
            // 
            // Sherazade1
            // 
            this.Sherazade1.Tag = "General";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Desafio3Farmacia.Properties.Resources.usuario_default;
            this.pictureBox5.Location = new System.Drawing.Point(930, 21);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(89, 67);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            // 
            // PaginaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 653);
            this.Controls.Add(this.splitContainer1);
            this.Name = "PaginaPrincipal";
            this.Text = "PaginaPrincipal";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Morphea7;
        private System.Windows.Forms.Button Morphea6;
        private System.Windows.Forms.Button Morphea5;
        private System.Windows.Forms.Button Morphea4;
        private System.Windows.Forms.Button Morphea10;
        private System.Windows.Forms.Button Morphea3;
        private System.Windows.Forms.Button Morphea2;
        private System.Windows.Forms.Button Morphea1;
        private System.Windows.Forms.Button Morphea11;
        private System.Windows.Forms.Button Morphea8;
        private System.Windows.Forms.Button Morphea12;
        private System.Windows.Forms.ToolTip Sherazade1;
        private System.Windows.Forms.Button Morphea13;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}