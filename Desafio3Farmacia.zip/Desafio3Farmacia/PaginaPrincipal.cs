﻿using Desafio3Farmacia.Data;
using Desafio3Farmacia.Models;
using Desafio3Farmacia.Vistas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Desafio3Farmacia
{
    public partial class PaginaPrincipal : Form
    {
        private Panel _panelDestino;
        public static List<DetalleVenta> Carrito = new List<DetalleVenta>();
        public CUCategoria CategoriaActual { get; private set; }

        private int idUsuario;
        public PaginaPrincipal(int id, Panel panelDestino)
        {
            InitializeComponent();
            idUsuario = id;
            _panelDestino = panel2; 

            CargarInicio(); 

        }
        public PaginaPrincipal(int id) : this(id, null) { }

        private void CargarInicio()
        {
            _panelDestino.Controls.Clear();
            var inicio = new VistaGeneral(_panelDestino);
            inicio.Dock = DockStyle.Fill;
            _panelDestino.Controls.Add(inicio);
        }
        private void CargarCategoria(int idCategoria)
        {
            _panelDestino.Controls.Clear();

            CategoriaActual = new CUCategoria(idCategoria, _panelDestino)
            {
                Dock = DockStyle.Fill
            };

            _panelDestino.Controls.Add(CategoriaActual);
        }
     
        private void Morphea1_Click(object sender, EventArgs e)
        {
            CargarInicio();
        }

        private void Morphea10_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            var perfilControl = new PerfilGeneral(Sesion.ID_Usuario);
            perfilControl.Dock = DockStyle.Fill;
            panel2.Controls.Add(perfilControl);
        }

        private void Morphea2_Click(object sender, EventArgs e) => CargarCategoria(1);
        private void Morphea3_Click(object sender, EventArgs e) => CargarCategoria(2);
        private void Morphea4_Click(object sender, EventArgs e) => CargarCategoria(3);
        private void Morphea5_Click(object sender, EventArgs e) => CargarCategoria(4);
        private void Morphea6_Click(object sender, EventArgs e) => CargarCategoria(5);
        private void Morphea7_Click(object sender, EventArgs e) => CargarCategoria(6);
        private void Morphea8_Click(object sender, EventArgs e) => CargarCategoria(7);
        private void Morphea12_Click(object sender, EventArgs e) => CargarCategoria(8);

        private void Morphea13_Click(object sender, EventArgs e)
        {
            if (Carrito.Count == 0)
            {
                MessageBox.Show("No hay productos en el carrito.");
                return;
            }

            try
            {
                var venta = new Venta
                {
                    ID_Usuario = idUsuario,
                    Fecha_Venta = DateTime.Now,
                    Total = 0m
                };

                foreach (var d in Carrito) venta.Total += d.Subtotal;

                int idVenta = FarmaciaDAO.InsertarVenta(venta, Carrito);
                MessageBox.Show($"Compra realizada exitosamente. ID de venta: {idVenta}", "Venta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Carrito.Clear();

                CargarInicio();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar la venta: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Morphea11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
