﻿# Desafio3Farmacia

Desafio3Farmacia es un sistema de gestión de farmacia desarrollado en **Windows Forms (.NET Framework)**.
Permite gestionar medicamentos, proveedores, clientes, administradores, compras, ventas e inventario de manera sencilla 
y organizada.

---

## 📋 Descripción

La aplicación tiene las siguientes funcionalidades:

- **Gestión de medicamentos**: Registrar, actualizar, eliminar y buscar medicamentos.
- **Gestión de proveedores**: Registrar, actualizar, eliminar y buscar proveedores.
- **Gestión de usuarios y administradores**: Registrar cuentas, editar perfiles y asignar roles.
- **Gestión de inventario**: Control de stock, precios de compra/venta y categorías.
- **Carrito de compras**: Agregar medicamentos al carrito con validaciones de stock y cantidad máxima.
- **Búsqueda y filtrado**: Buscar información en cualquier pestaña utilizando columnas específicas.
- **Validaciones**: Todos los formularios incluyen validaciones de datos para prevenir errores.

---

## 💻 Requisitos

- **Visual Studio 2022** o superior
- **.NET Framework 4.8**
- **SQL Server Express** 

---

## ⚙️ Instalación

1. Abrir la solución `.sln` en Visual Studio.
2. Restaurar paquetes NuGet si es necesario.
3. Configurar la base de datos:
   - SQL Server Express: Crear la base de datos y tablas según los scripts incluidos.
   - SQLite: Asegurarse de que la base de datos `.db` esté en la carpeta del proyecto.
4. Ejecutar la aplicación.

---

## 🗂 Estructura de la aplicación

### Pestaña 1: Visualización general
- Muestra todos los registros de:
  - Medicamentos
  - Usuarios
  - Administradores
  - Clientes
- Permite **buscar y filtrar** por columnas específicas.

### Pestaña 2: Detalles y compras
- Permite ver proveedores, detalles de venta, detalles de compra y categorías.
- Funcionalidades de búsqueda avanzada.

### Pestaña 3: Gestión de compras y categorías
- Registrar compras de medicamentos.
- Modificar y registrar categorías.
- Seleccionar medicamentos y asignar cantidades.

### Pestaña 4: Perfil de usuario/administrador
- Editar información de administrador (nombre, apellido, correo, cargo, teléfono, foto).
- Editar información de usuario (nombre de usuario, login, contraseña, código de administrador).
- Subir imágenes para perfiles.

### Pestaña 5: Gestión de inventario
- Registrar, actualizar y eliminar medicamentos.
- Registrar, actualizar y eliminar proveedores.
- Subir imágenes de medicamentos.
- Validaciones de datos y control de stock.

- ### Página Principal (`PaginaPrincipal`)

La página principal es la interfaz principal de la aplicación para **clientes**:

- **Visualización de categorías y productos**:
  - Se muestran todas las categorías disponibles.
  - Al seleccionar una categoría, se muestran los productos correspondientes.
  - Cada producto tiene detalles como nombre, descripción, precio y stock.
  - Imagen del producto si está disponible.

- **Detalle de producto (`DetalleProducto`)**:
  - Al hacer clic en un producto se abre su detalle en el mismo panel.
  - Permite seleccionar cantidad (con validación de stock y cantidad máxima de 20 unidades).
  - Botón para agregar al **carrito de compras**.
  - Botón para volver a la vista de la categoría o página de inicio.

- **Carrito de compras**:
  - Lista de productos seleccionados con cantidad y precio unitario.
  - Validación de cantidad máxima según stock.
  - Permite sumar unidades si un producto ya está en el carrito.
  - Notificación al usuario cuando un producto se agrega correctamente.

- **Navegación dinámica**:
  - Los controles de usuario (`UserControl`) permiten cargar vistas sin abrir nuevos formularios.
  - El panel principal se actualiza según la categoría o producto seleccionado.
  - La navegación siempre respeta la categoría actual y permite volver al inicio.

---

## 📌 Uso

## 📌 Uso

1. Iniciar sesión como administrador o usuario.
2. Navegar entre las pestañas según la funcionalidad requerida.
3. En la página principal, seleccionar categoría y productos, ajustar cantidades y agregar al carrito.
4. Completar formularios con los datos requeridos en cada pestaña.
5. Guardar cambios, que se reflejan inmediatamente en los DataGridViews.
6. Las acciones cuentan con **mensajes de confirmación y advertencias** para prevenir errores.

------

## 📝 Notas importantes

- Se incluyen validaciones para campos obligatorios, tipos de datos y límites de stock.
- La aplicación maneja imágenes en memoria para medicamentos y perfiles.
- Los cambios en los formularios se guardan automáticamente en la base de datos.
- El proyecto está preparado para ampliaciones futuras (nuevas pestañas, reportes, exportación de datos).
----

## 👤 Autor

- Nombre: Andy Alexander Cortez Elias
- Carnet: Ce251930

---

## 📷 Capturas de pantalla 

Estan en la carpeta de recursos
