﻿namespace Desafio3Farmacia
{
    partial class RegistroDeCuenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.Morphea3 = new System.Windows.Forms.Button();
            this.Helena4 = new System.Windows.Forms.PictureBox();
            this.Celia4 = new System.Windows.Forms.TextBox();
            this.Helena3 = new System.Windows.Forms.PictureBox();
            this.Celia3 = new System.Windows.Forms.TextBox();
            this.Morphea2 = new System.Windows.Forms.Button();
            this.Helena2 = new System.Windows.Forms.PictureBox();
            this.Helena1 = new System.Windows.Forms.PictureBox();
            this.Celia2 = new System.Windows.Forms.TextBox();
            this.Celia1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Olstein1 = new System.Windows.Forms.LinkLabel();
            this.Morphea1 = new System.Windows.Forms.Button();
            this.Sylvia2 = new System.Windows.Forms.RadioButton();
            this.Sylvia1 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Helena4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.GreenYellow;
            this.splitContainer1.Panel1.Controls.Add(this.Morphea3);
            this.splitContainer1.Panel1.Controls.Add(this.Helena4);
            this.splitContainer1.Panel1.Controls.Add(this.Celia4);
            this.splitContainer1.Panel1.Controls.Add(this.Helena3);
            this.splitContainer1.Panel1.Controls.Add(this.Celia3);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea2);
            this.splitContainer1.Panel1.Controls.Add(this.Helena2);
            this.splitContainer1.Panel1.Controls.Add(this.Helena1);
            this.splitContainer1.Panel1.Controls.Add(this.Celia2);
            this.splitContainer1.Panel1.Controls.Add(this.Celia1);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.Olstein1);
            this.splitContainer1.Panel1.Controls.Add(this.Morphea1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.BlueViolet;
            this.splitContainer1.Panel2.Controls.Add(this.Sylvia2);
            this.splitContainer1.Panel2.Controls.Add(this.Sylvia1);
            this.splitContainer1.Panel2.Controls.Add(this.label7);
            this.splitContainer1.Panel2.Controls.Add(this.label6);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Size = new System.Drawing.Size(942, 483);
            this.splitContainer1.SplitterDistance = 521;
            this.splitContainer1.TabIndex = 0;
            // 
            // Morphea3
            // 
            this.Morphea3.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._81986e543fc3fe544c764fd4d0012289;
            this.Morphea3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea3.Location = new System.Drawing.Point(404, 313);
            this.Morphea3.Name = "Morphea3";
            this.Morphea3.Size = new System.Drawing.Size(44, 35);
            this.Morphea3.TabIndex = 34;
            this.Morphea3.UseVisualStyleBackColor = true;
            this.Morphea3.Click += new System.EventHandler(this.Morphea3_Click);
            // 
            // Helena4
            // 
            this.Helena4.Location = new System.Drawing.Point(67, 313);
            this.Helena4.Name = "Helena4";
            this.Helena4.Size = new System.Drawing.Size(43, 34);
            this.Helena4.TabIndex = 33;
            this.Helena4.TabStop = false;
            // 
            // Celia4
            // 
            this.Celia4.Location = new System.Drawing.Point(116, 325);
            this.Celia4.Name = "Celia4";
            this.Celia4.Size = new System.Drawing.Size(262, 22);
            this.Celia4.TabIndex = 32;
            this.Celia4.Enter += new System.EventHandler(this.Celia4_Enter);
            this.Celia4.Leave += new System.EventHandler(this.Celia4_Leave);
            // 
            // Helena3
            // 
            this.Helena3.Location = new System.Drawing.Point(67, 254);
            this.Helena3.Name = "Helena3";
            this.Helena3.Size = new System.Drawing.Size(43, 34);
            this.Helena3.TabIndex = 31;
            this.Helena3.TabStop = false;
            // 
            // Celia3
            // 
            this.Celia3.Location = new System.Drawing.Point(116, 266);
            this.Celia3.Name = "Celia3";
            this.Celia3.Size = new System.Drawing.Size(262, 22);
            this.Celia3.TabIndex = 30;
            this.Celia3.Enter += new System.EventHandler(this.Celia3_Enter);
            this.Celia3.Leave += new System.EventHandler(this.Celia3_Leave);
            // 
            // Morphea2
            // 
            this.Morphea2.BackgroundImage = global::Desafio3Farmacia.Properties.Resources._81986e543fc3fe544c764fd4d0012289;
            this.Morphea2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Morphea2.Location = new System.Drawing.Point(404, 253);
            this.Morphea2.Name = "Morphea2";
            this.Morphea2.Size = new System.Drawing.Size(44, 35);
            this.Morphea2.TabIndex = 29;
            this.Morphea2.UseVisualStyleBackColor = true;
            this.Morphea2.Click += new System.EventHandler(this.Morphea2_Click);
            // 
            // Helena2
            // 
            this.Helena2.Location = new System.Drawing.Point(67, 189);
            this.Helena2.Name = "Helena2";
            this.Helena2.Size = new System.Drawing.Size(43, 34);
            this.Helena2.TabIndex = 28;
            this.Helena2.TabStop = false;
            // 
            // Helena1
            // 
            this.Helena1.Location = new System.Drawing.Point(67, 122);
            this.Helena1.Name = "Helena1";
            this.Helena1.Size = new System.Drawing.Size(43, 34);
            this.Helena1.TabIndex = 27;
            this.Helena1.TabStop = false;
            // 
            // Celia2
            // 
            this.Celia2.Location = new System.Drawing.Point(116, 201);
            this.Celia2.Name = "Celia2";
            this.Celia2.Size = new System.Drawing.Size(262, 22);
            this.Celia2.TabIndex = 26;
            this.Celia2.Enter += new System.EventHandler(this.Celia2_Enter);
            this.Celia2.Leave += new System.EventHandler(this.Celia2_Leave);
            // 
            // Celia1
            // 
            this.Celia1.Location = new System.Drawing.Point(116, 134);
            this.Celia1.Name = "Celia1";
            this.Celia1.Size = new System.Drawing.Size(262, 22);
            this.Celia1.TabIndex = 25;
            this.Celia1.Enter += new System.EventHandler(this.Celia1_Enter);
            this.Celia1.Leave += new System.EventHandler(this.Celia1_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(99, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(279, 18);
            this.label3.TabIndex = 24;
            this.label3.Text = "Por favor rellena todos los campos ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(161, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 29);
            this.label2.TabIndex = 23;
            this.label2.Text = "Hola Amigo/a";
            // 
            // Olstein1
            // 
            this.Olstein1.AutoSize = true;
            this.Olstein1.Location = new System.Drawing.Point(139, 423);
            this.Olstein1.Name = "Olstein1";
            this.Olstein1.Size = new System.Drawing.Size(207, 16);
            this.Olstein1.TabIndex = 21;
            this.Olstein1.TabStop = true;
            this.Olstein1.Text = "Ya tienes cuenta? vuelve Al Login";
            this.Olstein1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Olstein1_LinkClicked);
            // 
            // Morphea1
            // 
            this.Morphea1.Location = new System.Drawing.Point(166, 368);
            this.Morphea1.Name = "Morphea1";
            this.Morphea1.Size = new System.Drawing.Size(156, 35);
            this.Morphea1.TabIndex = 20;
            this.Morphea1.Text = "Crear Cuenta";
            this.Morphea1.UseVisualStyleBackColor = true;
            this.Morphea1.Click += new System.EventHandler(this.Morphea1_Click);
            // 
            // Sylvia2
            // 
            this.Sylvia2.AutoSize = true;
            this.Sylvia2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sylvia2.Location = new System.Drawing.Point(190, 402);
            this.Sylvia2.Name = "Sylvia2";
            this.Sylvia2.Size = new System.Drawing.Size(147, 24);
            this.Sylvia2.TabIndex = 12;
            this.Sylvia2.TabStop = true;
            this.Sylvia2.Text = "Administrador";
            this.Sylvia2.UseVisualStyleBackColor = true;
            this.Sylvia2.CheckedChanged += new System.EventHandler(this.Sylvia2_CheckedChanged);
            // 
            // Sylvia1
            // 
            this.Sylvia1.AutoSize = true;
            this.Sylvia1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sylvia1.Location = new System.Drawing.Point(64, 402);
            this.Sylvia1.Name = "Sylvia1";
            this.Sylvia1.Size = new System.Drawing.Size(89, 24);
            this.Sylvia1.TabIndex = 11;
            this.Sylvia1.TabStop = true;
            this.Sylvia1.Text = "Cliente";
            this.Sylvia1.UseVisualStyleBackColor = true;
            this.Sylvia1.CheckedChanged += new System.EventHandler(this.Sylvia1_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(41, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(334, 125);
            this.label7.TabIndex = 10;
            this.label7.Text = "Asegurate de que los datos \r\ningresados sean los correctos\r\nmas adelante podras m" +
    "odificarlos\r\npero debes recordarlos para\r\npoder ingresar";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(48, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(311, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "La Farmacia el Reino Cientifico";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(185, 91);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(117, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Hola Bienvenido";
            // 
            // RegistroDeCuenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 483);
            this.Controls.Add(this.splitContainer1);
            this.Name = "RegistroDeCuenta";
            this.Text = "RegistroDeCuenta";
            this.Load += new System.EventHandler(this.RegistroDeCuenta_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Helena4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button Morphea2;
        private System.Windows.Forms.PictureBox Helena2;
        private System.Windows.Forms.PictureBox Helena1;
        private System.Windows.Forms.TextBox Celia2;
        private System.Windows.Forms.TextBox Celia1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel Olstein1;
        private System.Windows.Forms.Button Morphea1;
        private System.Windows.Forms.PictureBox Helena3;
        private System.Windows.Forms.TextBox Celia3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton Sylvia2;
        private System.Windows.Forms.RadioButton Sylvia1;
        private System.Windows.Forms.Button Morphea3;
        private System.Windows.Forms.PictureBox Helena4;
        private System.Windows.Forms.TextBox Celia4;
    }
}