﻿using Desafio3Farmacia.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafio3Farmacia
{
    public partial class RegistroDeCuenta : Form
    {
        private RegistroService registroService = new RegistroService();
        public RegistroDeCuenta()
        {
            InitializeComponent();
            Asuka(Celia1, "Nombre De Usuario");
            Asuka(Celia2, "Usuario");
            Asuka(Celia3, "Contraseña");
            Asuka(Celia4, "Codigo De Administrador");
        }
        private bool ValidarCampos(string nombre, string login, string contrasena, bool esAdmin, string codigoAdmin)
        {
            
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(login) || string.IsNullOrEmpty(contrasena))
            {
                MessageBox.Show("⚠️ Debe completar todos los campos obligatorios.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

         
            if (nombre == "Nombre De Usuario" || login == "Usuario" || contrasena == "Contraseña")
            {
                MessageBox.Show("⚠️ Debe ingresar valores válidos, no los textos predeterminados.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

         
            if (login.Length < 4)
            {
                MessageBox.Show("⚠️ El nombre de usuario debe tener al menos 4 caracteres.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (contrasena.Length < 6)
            {
                MessageBox.Show("⚠️ La contraseña debe tener al menos 6 caracteres.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

           
            if (!Regex.IsMatch(login, @"^[a-zA-Z0-9_]+$"))
            {
                MessageBox.Show("⚠️ El usuario solo puede contener letras, números y guiones bajos.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

           
            if (!Regex.IsMatch(contrasena, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$"))
            {
                MessageBox.Show("⚠️ La contraseña debe tener al menos una mayúscula, una minúscula y un número.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

           
            if (esAdmin)
            {
                if (string.IsNullOrEmpty(codigoAdmin) || codigoAdmin == "Codigo De Administrador")
                {
                    MessageBox.Show("⚠️ Debe ingresar el código de administrador.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

               
                if (!Regex.IsMatch(codigoAdmin, @"^[A-Za-z0-9]{4,}$"))
                {
                    MessageBox.Show("⚠️ El código de administrador debe tener al menos 4 caracteres alfanuméricos.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }
        private void Asuka(TextBox textBox, string placeholderText)
        {
            textBox.Text = placeholderText;
            textBox.ForeColor = Color.Gray;

          
            if (textBox == Celia3)
            {
                textBox.PasswordChar = '\0';
            }
            if (textBox == Celia4)
            {
                textBox.PasswordChar = '\0';
            }
        }
        private void RegistroDeCuenta_Load(object sender, EventArgs e)
        {
            Celia4.Enabled = false;
        } 

        private void Sylvia1_CheckedChanged(object sender, EventArgs e)
        {
            if (Sylvia1.Checked)
            {
                Celia4.Enabled = false;
                Celia4.Clear();
            }
        }

        private void Sylvia2_CheckedChanged(object sender, EventArgs e)
        {
            if (Sylvia2.Checked)
            {
                Celia4.Enabled = true;
            }
        }

        private void Morphea1_Click(object sender, EventArgs e)
        {
            string nombre = Celia1.Text.Trim();
            string login = Celia2.Text.Trim();
            string contrasena = Celia3.Text.Trim();
            string codigoAdmin = Celia4.Text.Trim();
            bool esAdmin = Sylvia2.Checked;

            if (!ValidarCampos(nombre, login, contrasena, esAdmin, codigoAdmin))
                return;


            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(login) || string.IsNullOrEmpty(contrasena))
            {
                MessageBox.Show("Debe completar todos los campos obligatorios.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (esAdmin && string.IsNullOrEmpty(codigoAdmin))
            {
                MessageBox.Show("Debe ingresar el código de administrador.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                bool exito = registroService.CrearUsuario(nombre, login, contrasena, esAdmin, codigoAdmin);
                if (exito)
                {
                    MessageBox.Show("Usuario registrado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al registrar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Celia1_Enter(object sender, EventArgs e)
        {
            if (Celia1.Text == "Nombre De Usuario" && Celia1.ForeColor == Color.Gray)
            {
                Celia1.Text = "";
                Celia1.ForeColor = Color.Black;
            }
        }

        private void Celia2_Enter(object sender, EventArgs e)
        {
            if (Celia2.Text == "Usuario" && Celia2.ForeColor == Color.Gray)
            {
                Celia2.Text = "";
                Celia2.ForeColor = Color.Black;
            }
        }

        private void Celia3_Enter(object sender, EventArgs e)
        {
            if (Celia3.Text == "Contraseña" && Celia3.ForeColor == Color.Gray)
            {
                Celia3.Text = "";
                Celia3.ForeColor = Color.Black;
            
                Celia3.PasswordChar = '*';
            }
        }

        private void Celia4_Enter(object sender, EventArgs e)
        {
            if (Celia4.Text == "Codigo De Administrador" && Celia4.ForeColor == Color.Gray)
            {
                Celia4.Text = "";
                Celia4.ForeColor = Color.Black;
                
                Celia4.PasswordChar = '*';
            }
        }
        private void Celia1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Celia1.Text))
            {
                Celia1.Text = "Nombre De Usuario";
                Celia1.ForeColor = Color.Gray;
            }
        }

        private void Celia2_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Celia2.Text))
            {
                Celia2.Text = "Usuario";
                Celia2.ForeColor = Color.Gray;
            }
        }

        private void Celia3_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Celia3.Text))
            {
                Celia3.Text = "Contraseña";
                Celia3.ForeColor = Color.Gray;
               
                Celia3.PasswordChar = '\0';
            }
        }
        private void Celia4_Leave(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(Celia4.Text))
            {
                Celia4.Text = "Codigo De Administrador";
                Celia4.ForeColor = Color.Gray;

                Celia4.PasswordChar = '\0';
            }
        }

        private void Morphea2_Click(object sender, EventArgs e)
        {

            if (Celia3.PasswordChar == '*')
            {
                Celia3.PasswordChar = '\0'; 
                Morphea2.BackgroundImage = Properties.Resources.c8d9fdb13ae708e23e2ba8be3c9bc135;
            }
            else
            {
                Celia3.PasswordChar = '*'; 
                Morphea2.BackgroundImage = Properties.Resources._81986e543fc3fe544c764fd4d0012289;
            }
        }

        private void Morphea3_Click(object sender, EventArgs e)
        {
     
            if (Celia4.PasswordChar == '*')
            {
                Celia4.PasswordChar = '\0'; 
                Morphea3.BackgroundImage = Properties.Resources.c8d9fdb13ae708e23e2ba8be3c9bc135;
            }
            else
            {               
                Celia4.PasswordChar = '*'; 
                Morphea3.BackgroundImage = Properties.Resources._81986e543fc3fe544c764fd4d0012289;
            }
        }

        private void Olstein1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }
    }
}
