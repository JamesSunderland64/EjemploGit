﻿namespace Desafio3Farmacia
{
    partial class VistaADM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.Blade3 = new System.Windows.Forms.ComboBox();
            this.Liberta3 = new System.Windows.Forms.TextBox();
            this.Diana3 = new System.Windows.Forms.DataGridView();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.Blade2 = new System.Windows.Forms.ComboBox();
            this.Liberta2 = new System.Windows.Forms.TextBox();
            this.Diana2 = new System.Windows.Forms.DataGridView();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.Blade4 = new System.Windows.Forms.ComboBox();
            this.Liberta4 = new System.Windows.Forms.TextBox();
            this.Diana4 = new System.Windows.Forms.DataGridView();
            this.Kasumi1 = new System.Windows.Forms.GroupBox();
            this.Blade1 = new System.Windows.Forms.ComboBox();
            this.Liberta1 = new System.Windows.Forms.TextBox();
            this.Diana1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Blade8 = new System.Windows.Forms.ComboBox();
            this.Liberta8 = new System.Windows.Forms.TextBox();
            this.Diana8 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Blade7 = new System.Windows.Forms.ComboBox();
            this.Liberta7 = new System.Windows.Forms.TextBox();
            this.Diana7 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Blade6 = new System.Windows.Forms.ComboBox();
            this.Diana6 = new System.Windows.Forms.DataGridView();
            this.Liberta6 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Blade5 = new System.Windows.Forms.ComboBox();
            this.Diana5 = new System.Windows.Forms.DataGridView();
            this.Liberta5 = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Morphea4 = new System.Windows.Forms.Button();
            this.Liberta16 = new System.Windows.Forms.TextBox();
            this.Liberta15 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Morphea3 = new System.Windows.Forms.Button();
            this.Liberta14 = new System.Windows.Forms.TextBox();
            this.Liberta11 = new System.Windows.Forms.TextBox();
            this.Blade10 = new System.Windows.Forms.ComboBox();
            this.Liberta10 = new System.Windows.Forms.TextBox();
            this.Diana10 = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Yoru1 = new System.Windows.Forms.Label();
            this.Nebris1 = new System.Windows.Forms.NumericUpDown();
            this.Morphea2 = new System.Windows.Forms.Button();
            this.Morphea1 = new System.Windows.Forms.Button();
            this.Blade9 = new System.Windows.Forms.ComboBox();
            this.Liberta9 = new System.Windows.Forms.TextBox();
            this.Diana9 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.Kasumi8 = new System.Windows.Forms.GroupBox();
            this.Celia8 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Michaela2 = new System.Windows.Forms.RadioButton();
            this.Celia6 = new System.Windows.Forms.TextBox();
            this.Celia7 = new System.Windows.Forms.TextBox();
            this.Celia9 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Michaela1 = new System.Windows.Forms.RadioButton();
            this.Morphea5 = new System.Windows.Forms.Button();
            this.Morphea6 = new System.Windows.Forms.Button();
            this.Helena1 = new System.Windows.Forms.PictureBox();
            this.Celia5 = new System.Windows.Forms.TextBox();
            this.Celia4 = new System.Windows.Forms.TextBox();
            this.Celia3 = new System.Windows.Forms.TextBox();
            this.Celia1 = new System.Windows.Forms.TextBox();
            this.Celia2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.Morphea16 = new System.Windows.Forms.Button();
            this.Liberta28 = new System.Windows.Forms.TextBox();
            this.Morphea14 = new System.Windows.Forms.Button();
            this.Morphea13 = new System.Windows.Forms.Button();
            this.Morphea12 = new System.Windows.Forms.Button();
            this.Liberta32 = new System.Windows.Forms.TextBox();
            this.Liberta31 = new System.Windows.Forms.TextBox();
            this.Liberta30 = new System.Windows.Forms.TextBox();
            this.Liberta29 = new System.Windows.Forms.TextBox();
            this.Blade13 = new System.Windows.Forms.ComboBox();
            this.Liberta27 = new System.Windows.Forms.TextBox();
            this.Diana12 = new System.Windows.Forms.DataGridView();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.Morphea15 = new System.Windows.Forms.Button();
            this.Morphea11 = new System.Windows.Forms.Button();
            this.Morphea10 = new System.Windows.Forms.Button();
            this.Morphea9 = new System.Windows.Forms.Button();
            this.Morphea8 = new System.Windows.Forms.Button();
            this.Helena2 = new System.Windows.Forms.PictureBox();
            this.Liberta26 = new System.Windows.Forms.TextBox();
            this.Liberta25 = new System.Windows.Forms.TextBox();
            this.Liberta24 = new System.Windows.Forms.TextBox();
            this.Liberta23 = new System.Windows.Forms.TextBox();
            this.Liberta22 = new System.Windows.Forms.TextBox();
            this.Liberta21 = new System.Windows.Forms.TextBox();
            this.Liberta20 = new System.Windows.Forms.TextBox();
            this.Liberta19 = new System.Windows.Forms.TextBox();
            this.Liberta18 = new System.Windows.Forms.TextBox();
            this.Blade12 = new System.Windows.Forms.ComboBox();
            this.Liberta17 = new System.Windows.Forms.TextBox();
            this.Diana11 = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.Morphea20 = new System.Windows.Forms.Button();
            this.Mophea21 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana3)).BeginInit();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana2)).BeginInit();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana4)).BeginInit();
            this.Kasumi1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana8)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana7)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana6)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana5)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana10)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Nebris1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Diana9)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.Kasumi8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana12)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Helena2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Diana11)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(1, -6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(973, 464);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.groupBox13);
            this.tabPage1.Controls.Add(this.groupBox12);
            this.tabPage1.Controls.Add(this.groupBox11);
            this.tabPage1.Controls.Add(this.Kasumi1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(965, 435);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Control De Farmacia";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.Blade3);
            this.groupBox13.Controls.Add(this.Liberta3);
            this.groupBox13.Controls.Add(this.Diana3);
            this.groupBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox13.Location = new System.Drawing.Point(15, 564);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(899, 265);
            this.groupBox13.TabIndex = 7;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Adminstradores";
            // 
            // Blade3
            // 
            this.Blade3.FormattingEnabled = true;
            this.Blade3.Location = new System.Drawing.Point(761, 30);
            this.Blade3.Name = "Blade3";
            this.Blade3.Size = new System.Drawing.Size(121, 26);
            this.Blade3.TabIndex = 5;
            // 
            // Liberta3
            // 
            this.Liberta3.Location = new System.Drawing.Point(383, 32);
            this.Liberta3.Name = "Liberta3";
            this.Liberta3.Size = new System.Drawing.Size(356, 24);
            this.Liberta3.TabIndex = 4;
            this.Liberta3.TextChanged += new System.EventHandler(this.Liberta3_TextChanged);
            // 
            // Diana3
            // 
            this.Diana3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana3.Location = new System.Drawing.Point(23, 72);
            this.Diana3.Name = "Diana3";
            this.Diana3.RowHeadersWidth = 51;
            this.Diana3.RowTemplate.Height = 24;
            this.Diana3.Size = new System.Drawing.Size(859, 166);
            this.Diana3.TabIndex = 3;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.Blade2);
            this.groupBox12.Controls.Add(this.Liberta2);
            this.groupBox12.Controls.Add(this.Diana2);
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(15, 288);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(899, 265);
            this.groupBox12.TabIndex = 7;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Usuarios";
            // 
            // Blade2
            // 
            this.Blade2.FormattingEnabled = true;
            this.Blade2.Location = new System.Drawing.Point(761, 30);
            this.Blade2.Name = "Blade2";
            this.Blade2.Size = new System.Drawing.Size(121, 26);
            this.Blade2.TabIndex = 5;
            // 
            // Liberta2
            // 
            this.Liberta2.Location = new System.Drawing.Point(383, 32);
            this.Liberta2.Name = "Liberta2";
            this.Liberta2.Size = new System.Drawing.Size(356, 24);
            this.Liberta2.TabIndex = 4;
            this.Liberta2.TextChanged += new System.EventHandler(this.Liberta2_TextChanged);
            // 
            // Diana2
            // 
            this.Diana2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana2.Location = new System.Drawing.Point(23, 72);
            this.Diana2.Name = "Diana2";
            this.Diana2.RowHeadersWidth = 51;
            this.Diana2.RowTemplate.Height = 24;
            this.Diana2.Size = new System.Drawing.Size(859, 166);
            this.Diana2.TabIndex = 3;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.Blade4);
            this.groupBox11.Controls.Add(this.Liberta4);
            this.groupBox11.Controls.Add(this.Diana4);
            this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(15, 835);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(899, 265);
            this.groupBox11.TabIndex = 6;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Clientes";
            // 
            // Blade4
            // 
            this.Blade4.FormattingEnabled = true;
            this.Blade4.Location = new System.Drawing.Point(761, 30);
            this.Blade4.Name = "Blade4";
            this.Blade4.Size = new System.Drawing.Size(121, 26);
            this.Blade4.TabIndex = 5;
            // 
            // Liberta4
            // 
            this.Liberta4.Location = new System.Drawing.Point(383, 32);
            this.Liberta4.Name = "Liberta4";
            this.Liberta4.Size = new System.Drawing.Size(356, 24);
            this.Liberta4.TabIndex = 4;
            this.Liberta4.TextChanged += new System.EventHandler(this.Liberta4_TextChanged);
            // 
            // Diana4
            // 
            this.Diana4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana4.Location = new System.Drawing.Point(23, 72);
            this.Diana4.Name = "Diana4";
            this.Diana4.RowHeadersWidth = 51;
            this.Diana4.RowTemplate.Height = 24;
            this.Diana4.Size = new System.Drawing.Size(859, 166);
            this.Diana4.TabIndex = 3;
            // 
            // Kasumi1
            // 
            this.Kasumi1.Controls.Add(this.Blade1);
            this.Kasumi1.Controls.Add(this.Liberta1);
            this.Kasumi1.Controls.Add(this.Diana1);
            this.Kasumi1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kasumi1.Location = new System.Drawing.Point(15, 17);
            this.Kasumi1.Name = "Kasumi1";
            this.Kasumi1.Size = new System.Drawing.Size(899, 265);
            this.Kasumi1.TabIndex = 0;
            this.Kasumi1.TabStop = false;
            this.Kasumi1.Text = "Productos";
            // 
            // Blade1
            // 
            this.Blade1.FormattingEnabled = true;
            this.Blade1.Location = new System.Drawing.Point(761, 30);
            this.Blade1.Name = "Blade1";
            this.Blade1.Size = new System.Drawing.Size(121, 26);
            this.Blade1.TabIndex = 5;
            // 
            // Liberta1
            // 
            this.Liberta1.Location = new System.Drawing.Point(383, 32);
            this.Liberta1.Name = "Liberta1";
            this.Liberta1.Size = new System.Drawing.Size(356, 24);
            this.Liberta1.TabIndex = 4;
            this.Liberta1.TextChanged += new System.EventHandler(this.Liberta1_TextChanged);
            // 
            // Diana1
            // 
            this.Diana1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana1.Location = new System.Drawing.Point(23, 72);
            this.Diana1.Name = "Diana1";
            this.Diana1.RowHeadersWidth = 51;
            this.Diana1.RowTemplate.Height = 24;
            this.Diana1.Size = new System.Drawing.Size(859, 166);
            this.Diana1.TabIndex = 3;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(965, 435);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Revision de Servicios";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Blade8);
            this.groupBox4.Controls.Add(this.Liberta8);
            this.groupBox4.Controls.Add(this.Diana8);
            this.groupBox4.Location = new System.Drawing.Point(491, 307);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(450, 284);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Categorias";
            // 
            // Blade8
            // 
            this.Blade8.FormattingEnabled = true;
            this.Blade8.Location = new System.Drawing.Point(296, 31);
            this.Blade8.Name = "Blade8";
            this.Blade8.Size = new System.Drawing.Size(129, 24);
            this.Blade8.TabIndex = 9;
            // 
            // Liberta8
            // 
            this.Liberta8.Location = new System.Drawing.Point(24, 31);
            this.Liberta8.Name = "Liberta8";
            this.Liberta8.Size = new System.Drawing.Size(251, 22);
            this.Liberta8.TabIndex = 8;
            this.Liberta8.TextChanged += new System.EventHandler(this.Liberta8_TextChanged);
            // 
            // Diana8
            // 
            this.Diana8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana8.Location = new System.Drawing.Point(26, 68);
            this.Diana8.Name = "Diana8";
            this.Diana8.RowHeadersWidth = 51;
            this.Diana8.RowTemplate.Height = 24;
            this.Diana8.Size = new System.Drawing.Size(401, 192);
            this.Diana8.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Blade7);
            this.groupBox3.Controls.Add(this.Liberta7);
            this.groupBox3.Controls.Add(this.Diana7);
            this.groupBox3.Location = new System.Drawing.Point(17, 307);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(450, 284);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Compras";
            // 
            // Blade7
            // 
            this.Blade7.FormattingEnabled = true;
            this.Blade7.Location = new System.Drawing.Point(298, 31);
            this.Blade7.Name = "Blade7";
            this.Blade7.Size = new System.Drawing.Size(129, 24);
            this.Blade7.TabIndex = 7;
            // 
            // Liberta7
            // 
            this.Liberta7.Location = new System.Drawing.Point(26, 31);
            this.Liberta7.Name = "Liberta7";
            this.Liberta7.Size = new System.Drawing.Size(251, 22);
            this.Liberta7.TabIndex = 6;
            this.Liberta7.TextChanged += new System.EventHandler(this.Liberta7_TextChanged);
            // 
            // Diana7
            // 
            this.Diana7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana7.Location = new System.Drawing.Point(26, 68);
            this.Diana7.Name = "Diana7";
            this.Diana7.RowHeadersWidth = 51;
            this.Diana7.RowTemplate.Height = 24;
            this.Diana7.Size = new System.Drawing.Size(401, 192);
            this.Diana7.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Blade6);
            this.groupBox2.Controls.Add(this.Diana6);
            this.groupBox2.Controls.Add(this.Liberta6);
            this.groupBox2.Location = new System.Drawing.Point(491, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(450, 284);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ventas";
            // 
            // Blade6
            // 
            this.Blade6.FormattingEnabled = true;
            this.Blade6.Location = new System.Drawing.Point(296, 21);
            this.Blade6.Name = "Blade6";
            this.Blade6.Size = new System.Drawing.Size(129, 24);
            this.Blade6.TabIndex = 11;
            // 
            // Diana6
            // 
            this.Diana6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana6.Location = new System.Drawing.Point(24, 68);
            this.Diana6.Name = "Diana6";
            this.Diana6.RowHeadersWidth = 51;
            this.Diana6.RowTemplate.Height = 24;
            this.Diana6.Size = new System.Drawing.Size(411, 192);
            this.Diana6.TabIndex = 0;
            // 
            // Liberta6
            // 
            this.Liberta6.Location = new System.Drawing.Point(24, 23);
            this.Liberta6.Name = "Liberta6";
            this.Liberta6.Size = new System.Drawing.Size(251, 22);
            this.Liberta6.TabIndex = 10;
            this.Liberta6.TextChanged += new System.EventHandler(this.Liberta6_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Blade5);
            this.groupBox1.Controls.Add(this.Diana5);
            this.groupBox1.Controls.Add(this.Liberta5);
            this.groupBox1.Location = new System.Drawing.Point(17, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 284);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Provedores";
            // 
            // Blade5
            // 
            this.Blade5.FormattingEnabled = true;
            this.Blade5.Location = new System.Drawing.Point(298, 21);
            this.Blade5.Name = "Blade5";
            this.Blade5.Size = new System.Drawing.Size(129, 24);
            this.Blade5.TabIndex = 13;
            // 
            // Diana5
            // 
            this.Diana5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana5.Location = new System.Drawing.Point(26, 68);
            this.Diana5.Name = "Diana5";
            this.Diana5.RowHeadersWidth = 51;
            this.Diana5.RowTemplate.Height = 24;
            this.Diana5.Size = new System.Drawing.Size(401, 192);
            this.Diana5.TabIndex = 0;
            // 
            // Liberta5
            // 
            this.Liberta5.Location = new System.Drawing.Point(26, 23);
            this.Liberta5.Name = "Liberta5";
            this.Liberta5.Size = new System.Drawing.Size(251, 22);
            this.Liberta5.TabIndex = 12;
            this.Liberta5.TextChanged += new System.EventHandler(this.Liberta5_TextChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(965, 435);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Compra y Administracion";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.Morphea4);
            this.groupBox7.Controls.Add(this.Liberta16);
            this.groupBox7.Controls.Add(this.Liberta15);
            this.groupBox7.Location = new System.Drawing.Point(644, 346);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(271, 350);
            this.groupBox7.TabIndex = 9;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Nueva Categoria";
            // 
            // Morphea4
            // 
            this.Morphea4.Location = new System.Drawing.Point(153, 309);
            this.Morphea4.Name = "Morphea4";
            this.Morphea4.Size = new System.Drawing.Size(96, 29);
            this.Morphea4.TabIndex = 14;
            this.Morphea4.Text = "Guardar";
            this.Morphea4.UseVisualStyleBackColor = true;
            this.Morphea4.Click += new System.EventHandler(this.Morphea4_Click);
            // 
            // Liberta16
            // 
            this.Liberta16.Location = new System.Drawing.Point(26, 127);
            this.Liberta16.Multiline = true;
            this.Liberta16.Name = "Liberta16";
            this.Liberta16.Size = new System.Drawing.Size(223, 166);
            this.Liberta16.TabIndex = 14;
            // 
            // Liberta15
            // 
            this.Liberta15.Location = new System.Drawing.Point(26, 65);
            this.Liberta15.Name = "Liberta15";
            this.Liberta15.Size = new System.Drawing.Size(163, 22);
            this.Liberta15.TabIndex = 13;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.Morphea3);
            this.groupBox6.Controls.Add(this.Liberta14);
            this.groupBox6.Controls.Add(this.Liberta11);
            this.groupBox6.Controls.Add(this.Blade10);
            this.groupBox6.Controls.Add(this.Liberta10);
            this.groupBox6.Controls.Add(this.Diana10);
            this.groupBox6.Location = new System.Drawing.Point(7, 346);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(612, 353);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Cambiar Catergoria";
            // 
            // Morphea3
            // 
            this.Morphea3.Location = new System.Drawing.Point(497, 309);
            this.Morphea3.Name = "Morphea3";
            this.Morphea3.Size = new System.Drawing.Size(96, 29);
            this.Morphea3.TabIndex = 13;
            this.Morphea3.Text = "Guardar";
            this.Morphea3.UseVisualStyleBackColor = true;
            this.Morphea3.Click += new System.EventHandler(this.Morphea3_Click);
            // 
            // Liberta14
            // 
            this.Liberta14.Location = new System.Drawing.Point(430, 127);
            this.Liberta14.Multiline = true;
            this.Liberta14.Name = "Liberta14";
            this.Liberta14.Size = new System.Drawing.Size(163, 166);
            this.Liberta14.TabIndex = 9;
            // 
            // Liberta11
            // 
            this.Liberta11.Location = new System.Drawing.Point(430, 77);
            this.Liberta11.Name = "Liberta11";
            this.Liberta11.Size = new System.Drawing.Size(163, 22);
            this.Liberta11.TabIndex = 8;
            // 
            // Blade10
            // 
            this.Blade10.FormattingEnabled = true;
            this.Blade10.Location = new System.Drawing.Point(430, 23);
            this.Blade10.Name = "Blade10";
            this.Blade10.Size = new System.Drawing.Size(163, 24);
            this.Blade10.TabIndex = 7;
            // 
            // Liberta10
            // 
            this.Liberta10.Location = new System.Drawing.Point(31, 23);
            this.Liberta10.Name = "Liberta10";
            this.Liberta10.Size = new System.Drawing.Size(356, 22);
            this.Liberta10.TabIndex = 6;
            this.Liberta10.TextChanged += new System.EventHandler(this.Liberta10_TextChanged);
            // 
            // Diana10
            // 
            this.Diana10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana10.Location = new System.Drawing.Point(25, 65);
            this.Diana10.Name = "Diana10";
            this.Diana10.RowHeadersWidth = 51;
            this.Diana10.RowTemplate.Height = 24;
            this.Diana10.Size = new System.Drawing.Size(362, 237);
            this.Diana10.TabIndex = 0;
            this.Diana10.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Diana10_CellContentClick);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Yoru1);
            this.groupBox5.Controls.Add(this.Nebris1);
            this.groupBox5.Controls.Add(this.Morphea2);
            this.groupBox5.Controls.Add(this.Morphea1);
            this.groupBox5.Controls.Add(this.Blade9);
            this.groupBox5.Controls.Add(this.Liberta9);
            this.groupBox5.Controls.Add(this.Diana9);
            this.groupBox5.Location = new System.Drawing.Point(7, 16);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(926, 315);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Comprar Medicamentos ";
            // 
            // Yoru1
            // 
            this.Yoru1.AutoSize = true;
            this.Yoru1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Yoru1.Location = new System.Drawing.Point(765, 58);
            this.Yoru1.Name = "Yoru1";
            this.Yoru1.Size = new System.Drawing.Size(61, 18);
            this.Yoru1.TabIndex = 11;
            this.Yoru1.Text = "label11";
            // 
            // Nebris1
            // 
            this.Nebris1.Location = new System.Drawing.Point(768, 93);
            this.Nebris1.Name = "Nebris1";
            this.Nebris1.Size = new System.Drawing.Size(136, 22);
            this.Nebris1.TabIndex = 10;
            // 
            // Morphea2
            // 
            this.Morphea2.Location = new System.Drawing.Point(768, 192);
            this.Morphea2.Name = "Morphea2";
            this.Morphea2.Size = new System.Drawing.Size(136, 44);
            this.Morphea2.TabIndex = 9;
            this.Morphea2.Text = "Cancelar Compra";
            this.Morphea2.UseVisualStyleBackColor = true;
            this.Morphea2.Click += new System.EventHandler(this.Morphea2_Click);
            // 
            // Morphea1
            // 
            this.Morphea1.Location = new System.Drawing.Point(768, 134);
            this.Morphea1.Name = "Morphea1";
            this.Morphea1.Size = new System.Drawing.Size(136, 39);
            this.Morphea1.TabIndex = 8;
            this.Morphea1.Text = "Comprar";
            this.Morphea1.UseVisualStyleBackColor = true;
            this.Morphea1.Click += new System.EventHandler(this.Morphea1_Click);
            // 
            // Blade9
            // 
            this.Blade9.FormattingEnabled = true;
            this.Blade9.Location = new System.Drawing.Point(612, 23);
            this.Blade9.Name = "Blade9";
            this.Blade9.Size = new System.Drawing.Size(121, 24);
            this.Blade9.TabIndex = 7;
            // 
            // Liberta9
            // 
            this.Liberta9.Location = new System.Drawing.Point(237, 23);
            this.Liberta9.Name = "Liberta9";
            this.Liberta9.Size = new System.Drawing.Size(356, 22);
            this.Liberta9.TabIndex = 6;
            this.Liberta9.TextChanged += new System.EventHandler(this.Liberta9_TextChanged);
            // 
            // Diana9
            // 
            this.Diana9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana9.Location = new System.Drawing.Point(25, 58);
            this.Diana9.Name = "Diana9";
            this.Diana9.RowHeadersWidth = 51;
            this.Diana9.RowTemplate.Height = 24;
            this.Diana9.Size = new System.Drawing.Size(720, 237);
            this.Diana9.TabIndex = 0;
            this.Diana9.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Diana9_CellClick);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPage4.Controls.Add(this.Kasumi8);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(965, 435);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Perfil";
            // 
            // Kasumi8
            // 
            this.Kasumi8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Kasumi8.Controls.Add(this.Mophea21);
            this.Kasumi8.Controls.Add(this.Morphea20);
            this.Kasumi8.Controls.Add(this.Celia8);
            this.Kasumi8.Controls.Add(this.label10);
            this.Kasumi8.Controls.Add(this.label9);
            this.Kasumi8.Controls.Add(this.Michaela2);
            this.Kasumi8.Controls.Add(this.Celia6);
            this.Kasumi8.Controls.Add(this.Celia7);
            this.Kasumi8.Controls.Add(this.Celia9);
            this.Kasumi8.Controls.Add(this.label6);
            this.Kasumi8.Controls.Add(this.label7);
            this.Kasumi8.Controls.Add(this.label8);
            this.Kasumi8.Controls.Add(this.Michaela1);
            this.Kasumi8.Controls.Add(this.Morphea5);
            this.Kasumi8.Controls.Add(this.Morphea6);
            this.Kasumi8.Controls.Add(this.Helena1);
            this.Kasumi8.Controls.Add(this.Celia5);
            this.Kasumi8.Controls.Add(this.Celia4);
            this.Kasumi8.Controls.Add(this.Celia3);
            this.Kasumi8.Controls.Add(this.Celia1);
            this.Kasumi8.Controls.Add(this.Celia2);
            this.Kasumi8.Controls.Add(this.label5);
            this.Kasumi8.Controls.Add(this.label4);
            this.Kasumi8.Controls.Add(this.label3);
            this.Kasumi8.Controls.Add(this.label2);
            this.Kasumi8.Controls.Add(this.label1);
            this.Kasumi8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kasumi8.Location = new System.Drawing.Point(17, 15);
            this.Kasumi8.Name = "Kasumi8";
            this.Kasumi8.Size = new System.Drawing.Size(917, 397);
            this.Kasumi8.TabIndex = 7;
            this.Kasumi8.TabStop = false;
            this.Kasumi8.Text = "Mi Perfil";
            // 
            // Celia8
            // 
            this.Celia8.Location = new System.Drawing.Point(303, 187);
            this.Celia8.Name = "Celia8";
            this.Celia8.ReadOnly = true;
            this.Celia8.Size = new System.Drawing.Size(210, 27);
            this.Celia8.TabIndex = 30;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(301, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 20);
            this.label10.TabIndex = 29;
            this.label10.Text = "Usuario:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(588, 236);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 20);
            this.label9.TabIndex = 28;
            this.label9.Text = "Modificar:";
            // 
            // Michaela2
            // 
            this.Michaela2.AutoSize = true;
            this.Michaela2.Location = new System.Drawing.Point(794, 232);
            this.Michaela2.Name = "Michaela2";
            this.Michaela2.Size = new System.Drawing.Size(95, 24);
            this.Michaela2.TabIndex = 27;
            this.Michaela2.TabStop = true;
            this.Michaela2.Text = "Usuario";
            this.Michaela2.UseVisualStyleBackColor = true;
            this.Michaela2.CheckedChanged += new System.EventHandler(this.Michaela2_CheckedChanged);
            // 
            // Celia6
            // 
            this.Celia6.Location = new System.Drawing.Point(303, 57);
            this.Celia6.Name = "Celia6";
            this.Celia6.ReadOnly = true;
            this.Celia6.Size = new System.Drawing.Size(210, 27);
            this.Celia6.TabIndex = 26;
            // 
            // Celia7
            // 
            this.Celia7.Location = new System.Drawing.Point(303, 130);
            this.Celia7.Name = "Celia7";
            this.Celia7.ReadOnly = true;
            this.Celia7.Size = new System.Drawing.Size(210, 27);
            this.Celia7.TabIndex = 25;
            // 
            // Celia9
            // 
            this.Celia9.Location = new System.Drawing.Point(303, 243);
            this.Celia9.Name = "Celia9";
            this.Celia9.ReadOnly = true;
            this.Celia9.Size = new System.Drawing.Size(210, 27);
            this.Celia9.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(301, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 20);
            this.label6.TabIndex = 23;
            this.label6.Text = "Nombre De Usuario:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(301, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 20);
            this.label7.TabIndex = 22;
            this.label7.Text = "Contraseña:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(301, 220);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(190, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "Codigo Adminsitrador";
            // 
            // Michaela1
            // 
            this.Michaela1.AutoSize = true;
            this.Michaela1.Location = new System.Drawing.Point(693, 232);
            this.Michaela1.Name = "Michaela1";
            this.Michaela1.Size = new System.Drawing.Size(75, 24);
            this.Michaela1.TabIndex = 20;
            this.Michaela1.TabStop = true;
            this.Michaela1.Text = "Perfil";
            this.Michaela1.UseVisualStyleBackColor = true;
            this.Michaela1.CheckedChanged += new System.EventHandler(this.Michaela1_CheckedChanged);
            // 
            // Morphea5
            // 
            this.Morphea5.BackColor = System.Drawing.Color.Lime;
            this.Morphea5.Location = new System.Drawing.Point(516, 328);
            this.Morphea5.Name = "Morphea5";
            this.Morphea5.Size = new System.Drawing.Size(109, 34);
            this.Morphea5.TabIndex = 18;
            this.Morphea5.Text = "Guardar";
            this.Morphea5.UseVisualStyleBackColor = false;
            this.Morphea5.Click += new System.EventHandler(this.Morphea5_Click);
            // 
            // Morphea6
            // 
            this.Morphea6.BackColor = System.Drawing.Color.Lime;
            this.Morphea6.Location = new System.Drawing.Point(651, 179);
            this.Morphea6.Name = "Morphea6";
            this.Morphea6.Size = new System.Drawing.Size(131, 40);
            this.Morphea6.TabIndex = 17;
            this.Morphea6.Text = "Agregar Foto";
            this.Morphea6.UseVisualStyleBackColor = false;
            this.Morphea6.Click += new System.EventHandler(this.Morphea6_Click);
            // 
            // Helena1
            // 
            this.Helena1.Location = new System.Drawing.Point(661, 19);
            this.Helena1.Name = "Helena1";
            this.Helena1.Size = new System.Drawing.Size(110, 138);
            this.Helena1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Helena1.TabIndex = 16;
            this.Helena1.TabStop = false;
            // 
            // Celia5
            // 
            this.Celia5.Location = new System.Drawing.Point(21, 316);
            this.Celia5.Name = "Celia5";
            this.Celia5.ReadOnly = true;
            this.Celia5.Size = new System.Drawing.Size(210, 27);
            this.Celia5.TabIndex = 15;
            // 
            // Celia4
            // 
            this.Celia4.Location = new System.Drawing.Point(22, 249);
            this.Celia4.Name = "Celia4";
            this.Celia4.ReadOnly = true;
            this.Celia4.Size = new System.Drawing.Size(210, 27);
            this.Celia4.TabIndex = 14;
            // 
            // Celia3
            // 
            this.Celia3.Location = new System.Drawing.Point(20, 187);
            this.Celia3.Name = "Celia3";
            this.Celia3.ReadOnly = true;
            this.Celia3.Size = new System.Drawing.Size(210, 27);
            this.Celia3.TabIndex = 13;
            // 
            // Celia1
            // 
            this.Celia1.Location = new System.Drawing.Point(22, 63);
            this.Celia1.Name = "Celia1";
            this.Celia1.ReadOnly = true;
            this.Celia1.Size = new System.Drawing.Size(210, 27);
            this.Celia1.TabIndex = 12;
            // 
            // Celia2
            // 
            this.Celia2.Location = new System.Drawing.Point(22, 130);
            this.Celia2.Name = "Celia2";
            this.Celia2.ReadOnly = true;
            this.Celia2.Size = new System.Drawing.Size(210, 27);
            this.Celia2.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Cargo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Telefono:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Correo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Apellido:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nombre:";
            // 
            // tabPage5
            // 
            this.tabPage5.AutoScroll = true;
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPage5.Controls.Add(this.groupBox10);
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(965, 435);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Control De Medicamentos";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label28);
            this.groupBox10.Controls.Add(this.label27);
            this.groupBox10.Controls.Add(this.label26);
            this.groupBox10.Controls.Add(this.label25);
            this.groupBox10.Controls.Add(this.label24);
            this.groupBox10.Controls.Add(this.Morphea16);
            this.groupBox10.Controls.Add(this.Liberta28);
            this.groupBox10.Controls.Add(this.Morphea14);
            this.groupBox10.Controls.Add(this.Morphea13);
            this.groupBox10.Controls.Add(this.Morphea12);
            this.groupBox10.Controls.Add(this.Liberta32);
            this.groupBox10.Controls.Add(this.Liberta31);
            this.groupBox10.Controls.Add(this.Liberta30);
            this.groupBox10.Controls.Add(this.Liberta29);
            this.groupBox10.Controls.Add(this.Blade13);
            this.groupBox10.Controls.Add(this.Liberta27);
            this.groupBox10.Controls.Add(this.Diana12);
            this.groupBox10.Location = new System.Drawing.Point(12, 326);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(953, 270);
            this.groupBox10.TabIndex = 24;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Provedores";
            // 
            // Morphea16
            // 
            this.Morphea16.Location = new System.Drawing.Point(745, 113);
            this.Morphea16.Name = "Morphea16";
            this.Morphea16.Size = new System.Drawing.Size(82, 24);
            this.Morphea16.TabIndex = 25;
            this.Morphea16.Text = "Limpiar";
            this.Morphea16.UseVisualStyleBackColor = true;
            this.Morphea16.Click += new System.EventHandler(this.Morphea16_Click);
            // 
            // Liberta28
            // 
            this.Liberta28.Location = new System.Drawing.Point(528, 42);
            this.Liberta28.Name = "Liberta28";
            this.Liberta28.Size = new System.Drawing.Size(168, 22);
            this.Liberta28.TabIndex = 24;
            // 
            // Morphea14
            // 
            this.Morphea14.Location = new System.Drawing.Point(745, 158);
            this.Morphea14.Name = "Morphea14";
            this.Morphea14.Size = new System.Drawing.Size(75, 23);
            this.Morphea14.TabIndex = 22;
            this.Morphea14.Text = "Eliminar";
            this.Morphea14.UseVisualStyleBackColor = true;
            this.Morphea14.Click += new System.EventHandler(this.Morphea14_Click);
            // 
            // Morphea13
            // 
            this.Morphea13.Location = new System.Drawing.Point(745, 69);
            this.Morphea13.Name = "Morphea13";
            this.Morphea13.Size = new System.Drawing.Size(75, 23);
            this.Morphea13.TabIndex = 21;
            this.Morphea13.Text = "Modificar";
            this.Morphea13.UseVisualStyleBackColor = true;
            this.Morphea13.Click += new System.EventHandler(this.Morphea13_Click);
            // 
            // Morphea12
            // 
            this.Morphea12.Location = new System.Drawing.Point(745, 23);
            this.Morphea12.Name = "Morphea12";
            this.Morphea12.Size = new System.Drawing.Size(75, 23);
            this.Morphea12.TabIndex = 20;
            this.Morphea12.Text = "Guardar";
            this.Morphea12.UseVisualStyleBackColor = true;
            this.Morphea12.Click += new System.EventHandler(this.Morphea12_Click);
            // 
            // Liberta32
            // 
            this.Liberta32.Location = new System.Drawing.Point(528, 218);
            this.Liberta32.Name = "Liberta32";
            this.Liberta32.Size = new System.Drawing.Size(168, 22);
            this.Liberta32.TabIndex = 15;
            // 
            // Liberta31
            // 
            this.Liberta31.Location = new System.Drawing.Point(528, 174);
            this.Liberta31.Name = "Liberta31";
            this.Liberta31.Size = new System.Drawing.Size(168, 22);
            this.Liberta31.TabIndex = 14;
            // 
            // Liberta30
            // 
            this.Liberta30.Location = new System.Drawing.Point(528, 132);
            this.Liberta30.Name = "Liberta30";
            this.Liberta30.Size = new System.Drawing.Size(168, 22);
            this.Liberta30.TabIndex = 13;
            // 
            // Liberta29
            // 
            this.Liberta29.Location = new System.Drawing.Point(528, 86);
            this.Liberta29.Name = "Liberta29";
            this.Liberta29.Size = new System.Drawing.Size(168, 22);
            this.Liberta29.TabIndex = 12;
            // 
            // Blade13
            // 
            this.Blade13.FormattingEnabled = true;
            this.Blade13.Location = new System.Drawing.Point(357, 21);
            this.Blade13.Name = "Blade13";
            this.Blade13.Size = new System.Drawing.Size(121, 24);
            this.Blade13.TabIndex = 2;
            // 
            // Liberta27
            // 
            this.Liberta27.Location = new System.Drawing.Point(97, 23);
            this.Liberta27.Name = "Liberta27";
            this.Liberta27.Size = new System.Drawing.Size(242, 22);
            this.Liberta27.TabIndex = 1;
            this.Liberta27.TextChanged += new System.EventHandler(this.Liberta27_TextChanged);
            // 
            // Diana12
            // 
            this.Diana12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana12.Location = new System.Drawing.Point(19, 60);
            this.Diana12.Name = "Diana12";
            this.Diana12.RowHeadersWidth = 51;
            this.Diana12.RowTemplate.Height = 24;
            this.Diana12.Size = new System.Drawing.Size(459, 180);
            this.Diana12.TabIndex = 0;
            this.Diana12.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Diana12_CellClick);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label23);
            this.groupBox9.Controls.Add(this.label22);
            this.groupBox9.Controls.Add(this.label21);
            this.groupBox9.Controls.Add(this.label20);
            this.groupBox9.Controls.Add(this.label19);
            this.groupBox9.Controls.Add(this.label18);
            this.groupBox9.Controls.Add(this.label17);
            this.groupBox9.Controls.Add(this.label16);
            this.groupBox9.Controls.Add(this.label15);
            this.groupBox9.Controls.Add(this.Morphea15);
            this.groupBox9.Controls.Add(this.Morphea11);
            this.groupBox9.Controls.Add(this.Morphea10);
            this.groupBox9.Controls.Add(this.Morphea9);
            this.groupBox9.Controls.Add(this.Morphea8);
            this.groupBox9.Controls.Add(this.Helena2);
            this.groupBox9.Controls.Add(this.Liberta26);
            this.groupBox9.Controls.Add(this.Liberta25);
            this.groupBox9.Controls.Add(this.Liberta24);
            this.groupBox9.Controls.Add(this.Liberta23);
            this.groupBox9.Controls.Add(this.Liberta22);
            this.groupBox9.Controls.Add(this.Liberta21);
            this.groupBox9.Controls.Add(this.Liberta20);
            this.groupBox9.Controls.Add(this.Liberta19);
            this.groupBox9.Controls.Add(this.Liberta18);
            this.groupBox9.Controls.Add(this.Blade12);
            this.groupBox9.Controls.Add(this.Liberta17);
            this.groupBox9.Controls.Add(this.Diana11);
            this.groupBox9.Location = new System.Drawing.Point(6, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(946, 300);
            this.groupBox9.TabIndex = 2;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Medicamenos";
            // 
            // Morphea15
            // 
            this.Morphea15.Location = new System.Drawing.Point(290, 208);
            this.Morphea15.Name = "Morphea15";
            this.Morphea15.Size = new System.Drawing.Size(82, 29);
            this.Morphea15.TabIndex = 24;
            this.Morphea15.Text = "Limpiar";
            this.Morphea15.UseVisualStyleBackColor = true;
            this.Morphea15.Click += new System.EventHandler(this.Morphea15_Click);
            // 
            // Morphea11
            // 
            this.Morphea11.Location = new System.Drawing.Point(394, 208);
            this.Morphea11.Name = "Morphea11";
            this.Morphea11.Size = new System.Drawing.Size(127, 29);
            this.Morphea11.TabIndex = 23;
            this.Morphea11.Text = "Cambiar Imagen";
            this.Morphea11.UseVisualStyleBackColor = true;
            this.Morphea11.Click += new System.EventHandler(this.Morphea11_Click);
            // 
            // Morphea10
            // 
            this.Morphea10.Location = new System.Drawing.Point(200, 208);
            this.Morphea10.Name = "Morphea10";
            this.Morphea10.Size = new System.Drawing.Size(75, 29);
            this.Morphea10.TabIndex = 22;
            this.Morphea10.Text = "Eliminar";
            this.Morphea10.UseVisualStyleBackColor = true;
            this.Morphea10.Click += new System.EventHandler(this.Morphea10_Click);
            // 
            // Morphea9
            // 
            this.Morphea9.Location = new System.Drawing.Point(110, 208);
            this.Morphea9.Name = "Morphea9";
            this.Morphea9.Size = new System.Drawing.Size(75, 29);
            this.Morphea9.TabIndex = 21;
            this.Morphea9.Text = "Modificar";
            this.Morphea9.UseVisualStyleBackColor = true;
            this.Morphea9.Click += new System.EventHandler(this.Morphea9_Click);
            // 
            // Morphea8
            // 
            this.Morphea8.Location = new System.Drawing.Point(19, 208);
            this.Morphea8.Name = "Morphea8";
            this.Morphea8.Size = new System.Drawing.Size(75, 29);
            this.Morphea8.TabIndex = 20;
            this.Morphea8.Text = "Guardar";
            this.Morphea8.UseVisualStyleBackColor = true;
            this.Morphea8.Click += new System.EventHandler(this.Morphea8_Click);
            // 
            // Helena2
            // 
            this.Helena2.Location = new System.Drawing.Point(762, 21);
            this.Helena2.Name = "Helena2";
            this.Helena2.Size = new System.Drawing.Size(141, 116);
            this.Helena2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Helena2.TabIndex = 19;
            this.Helena2.TabStop = false;
            // 
            // Liberta26
            // 
            this.Liberta26.Location = new System.Drawing.Point(746, 265);
            this.Liberta26.Name = "Liberta26";
            this.Liberta26.Size = new System.Drawing.Size(168, 22);
            this.Liberta26.TabIndex = 18;
            // 
            // Liberta25
            // 
            this.Liberta25.Location = new System.Drawing.Point(746, 215);
            this.Liberta25.Name = "Liberta25";
            this.Liberta25.Size = new System.Drawing.Size(168, 22);
            this.Liberta25.TabIndex = 17;
            // 
            // Liberta24
            // 
            this.Liberta24.Location = new System.Drawing.Point(746, 171);
            this.Liberta24.Name = "Liberta24";
            this.Liberta24.Size = new System.Drawing.Size(168, 22);
            this.Liberta24.TabIndex = 16;
            // 
            // Liberta23
            // 
            this.Liberta23.Location = new System.Drawing.Point(563, 265);
            this.Liberta23.Name = "Liberta23";
            this.Liberta23.Size = new System.Drawing.Size(168, 22);
            this.Liberta23.TabIndex = 15;
            // 
            // Liberta22
            // 
            this.Liberta22.Location = new System.Drawing.Point(563, 215);
            this.Liberta22.Name = "Liberta22";
            this.Liberta22.Size = new System.Drawing.Size(168, 22);
            this.Liberta22.TabIndex = 14;
            // 
            // Liberta21
            // 
            this.Liberta21.Location = new System.Drawing.Point(563, 171);
            this.Liberta21.Name = "Liberta21";
            this.Liberta21.Size = new System.Drawing.Size(168, 22);
            this.Liberta21.TabIndex = 13;
            // 
            // Liberta20
            // 
            this.Liberta20.Location = new System.Drawing.Point(563, 127);
            this.Liberta20.Name = "Liberta20";
            this.Liberta20.Size = new System.Drawing.Size(168, 22);
            this.Liberta20.TabIndex = 12;
            // 
            // Liberta19
            // 
            this.Liberta19.Location = new System.Drawing.Point(563, 81);
            this.Liberta19.Name = "Liberta19";
            this.Liberta19.Size = new System.Drawing.Size(168, 22);
            this.Liberta19.TabIndex = 11;
            // 
            // Liberta18
            // 
            this.Liberta18.Location = new System.Drawing.Point(563, 37);
            this.Liberta18.Name = "Liberta18";
            this.Liberta18.ReadOnly = true;
            this.Liberta18.Size = new System.Drawing.Size(168, 22);
            this.Liberta18.TabIndex = 10;
            // 
            // Blade12
            // 
            this.Blade12.FormattingEnabled = true;
            this.Blade12.Location = new System.Drawing.Point(357, 21);
            this.Blade12.Name = "Blade12";
            this.Blade12.Size = new System.Drawing.Size(121, 24);
            this.Blade12.TabIndex = 2;
            // 
            // Liberta17
            // 
            this.Liberta17.Location = new System.Drawing.Point(97, 23);
            this.Liberta17.Name = "Liberta17";
            this.Liberta17.Size = new System.Drawing.Size(242, 22);
            this.Liberta17.TabIndex = 1;
            this.Liberta17.TextChanged += new System.EventHandler(this.Liberta17_TextChanged);
            // 
            // Diana11
            // 
            this.Diana11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Diana11.Location = new System.Drawing.Point(19, 60);
            this.Diana11.Name = "Diana11";
            this.Diana11.RowHeadersWidth = 51;
            this.Diana11.RowTemplate.Height = 24;
            this.Diana11.Size = new System.Drawing.Size(459, 123);
            this.Diana11.TabIndex = 0;
            this.Diana11.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Diana11_CellClick);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(430, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 16);
            this.label11.TabIndex = 14;
            this.label11.Text = "Nombre:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(430, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 16);
            this.label12.TabIndex = 15;
            this.label12.Text = "Descripcion:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(23, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 16);
            this.label13.TabIndex = 15;
            this.label13.Text = "Nombre:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(36, 108);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 16);
            this.label14.TabIndex = 16;
            this.label14.Text = "Descripcion:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(560, 18);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(23, 16);
            this.label15.TabIndex = 25;
            this.label15.Text = "ID:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(560, 62);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 16);
            this.label16.TabIndex = 26;
            this.label16.Text = "Nombre:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(560, 108);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(82, 16);
            this.label17.TabIndex = 27;
            this.label17.Text = "Descripcion:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(564, 152);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(85, 16);
            this.label18.TabIndex = 28;
            this.label18.Text = "ID Categoria:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(560, 196);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 16);
            this.label19.TabIndex = 29;
            this.label19.Text = "Precio Compra:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(564, 246);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(87, 16);
            this.label20.TabIndex = 30;
            this.label20.Text = "Precio Venta:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(748, 152);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 16);
            this.label21.TabIndex = 31;
            this.label21.Text = "Stock:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(748, 196);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(121, 16);
            this.label22.TabIndex = 32;
            this.label22.Text = "Fecha de Registro:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(748, 246);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(82, 16);
            this.label23.TabIndex = 33;
            this.label23.Text = "ID Provedor:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(525, 21);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(23, 16);
            this.label24.TabIndex = 34;
            this.label24.Text = "ID:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(525, 67);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 16);
            this.label25.TabIndex = 34;
            this.label25.Text = "Nombre:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(525, 113);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(64, 16);
            this.label26.TabIndex = 35;
            this.label26.Text = "Telefono:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(525, 155);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(67, 16);
            this.label27.TabIndex = 36;
            this.label27.Text = "Direccion:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(533, 199);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(51, 16);
            this.label28.TabIndex = 37;
            this.label28.Text = "Correo:";
            // 
            // Morphea20
            // 
            this.Morphea20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Morphea20.Location = new System.Drawing.Point(651, 328);
            this.Morphea20.Name = "Morphea20";
            this.Morphea20.Size = new System.Drawing.Size(97, 34);
            this.Morphea20.TabIndex = 31;
            this.Morphea20.Text = "Volver";
            this.Morphea20.UseVisualStyleBackColor = false;
            this.Morphea20.Click += new System.EventHandler(this.Morphea20_Click);
            // 
            // Mophea21
            // 
            this.Mophea21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Mophea21.Location = new System.Drawing.Point(777, 328);
            this.Mophea21.Name = "Mophea21";
            this.Mophea21.Size = new System.Drawing.Size(91, 34);
            this.Mophea21.TabIndex = 32;
            this.Mophea21.Text = "SALIR";
            this.Mophea21.UseVisualStyleBackColor = false;
            this.Mophea21.Click += new System.EventHandler(this.Mophea21_Click);
            // 
            // VistaADM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 470);
            this.Controls.Add(this.tabControl1);
            this.Name = "VistaADM";
            this.Text = "VistaAdministrativa";
            this.Load += new System.EventHandler(this.VistaADM_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana3)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana2)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana4)).EndInit();
            this.Kasumi1.ResumeLayout(false);
            this.Kasumi1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana8)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana7)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana5)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana10)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Nebris1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Diana9)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.Kasumi8.ResumeLayout(false);
            this.Kasumi8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Diana12)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Helena2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Diana11)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox Kasumi1;
        private System.Windows.Forms.ComboBox Blade1;
        private System.Windows.Forms.TextBox Liberta1;
        private System.Windows.Forms.DataGridView Diana1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView Diana8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView Diana7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView Diana6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox Blade9;
        private System.Windows.Forms.TextBox Liberta9;
        private System.Windows.Forms.DataGridView Diana9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox Blade10;
        private System.Windows.Forms.TextBox Liberta10;
        private System.Windows.Forms.DataGridView Diana10;
        private System.Windows.Forms.TextBox Liberta14;
        private System.Windows.Forms.TextBox Liberta11;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button Morphea4;
        private System.Windows.Forms.TextBox Liberta16;
        private System.Windows.Forms.TextBox Liberta15;
        private System.Windows.Forms.Button Morphea3;
        private System.Windows.Forms.GroupBox Kasumi8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton Michaela2;
        private System.Windows.Forms.TextBox Celia6;
        private System.Windows.Forms.TextBox Celia7;
        private System.Windows.Forms.TextBox Celia9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton Michaela1;
        private System.Windows.Forms.Button Morphea5;
        private System.Windows.Forms.Button Morphea6;
        private System.Windows.Forms.PictureBox Helena1;
        private System.Windows.Forms.TextBox Celia5;
        private System.Windows.Forms.TextBox Celia4;
        private System.Windows.Forms.TextBox Celia3;
        private System.Windows.Forms.TextBox Celia1;
        private System.Windows.Forms.TextBox Celia2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Blade7;
        private System.Windows.Forms.TextBox Liberta7;
        private System.Windows.Forms.TextBox Celia8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox Blade8;
        private System.Windows.Forms.TextBox Liberta8;
        private System.Windows.Forms.ComboBox Blade6;
        private System.Windows.Forms.TextBox Liberta6;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox Liberta26;
        private System.Windows.Forms.TextBox Liberta25;
        private System.Windows.Forms.TextBox Liberta24;
        private System.Windows.Forms.TextBox Liberta23;
        private System.Windows.Forms.TextBox Liberta22;
        private System.Windows.Forms.TextBox Liberta21;
        private System.Windows.Forms.TextBox Liberta20;
        private System.Windows.Forms.TextBox Liberta19;
        private System.Windows.Forms.TextBox Liberta18;
        private System.Windows.Forms.ComboBox Blade12;
        private System.Windows.Forms.TextBox Liberta17;
        private System.Windows.Forms.DataGridView Diana11;
        private System.Windows.Forms.Button Morphea11;
        private System.Windows.Forms.Button Morphea10;
        private System.Windows.Forms.Button Morphea9;
        private System.Windows.Forms.Button Morphea8;
        private System.Windows.Forms.PictureBox Helena2;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox Liberta28;
        private System.Windows.Forms.Button Morphea14;
        private System.Windows.Forms.Button Morphea13;
        private System.Windows.Forms.Button Morphea12;
        private System.Windows.Forms.TextBox Liberta32;
        private System.Windows.Forms.TextBox Liberta31;
        private System.Windows.Forms.TextBox Liberta30;
        private System.Windows.Forms.TextBox Liberta29;
        private System.Windows.Forms.ComboBox Blade13;
        private System.Windows.Forms.TextBox Liberta27;
        private System.Windows.Forms.DataGridView Diana12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox Blade3;
        private System.Windows.Forms.TextBox Liberta3;
        private System.Windows.Forms.DataGridView Diana3;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.ComboBox Blade2;
        private System.Windows.Forms.TextBox Liberta2;
        private System.Windows.Forms.DataGridView Diana2;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ComboBox Blade4;
        private System.Windows.Forms.TextBox Liberta4;
        private System.Windows.Forms.DataGridView Diana4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox Blade5;
        private System.Windows.Forms.DataGridView Diana5;
        private System.Windows.Forms.TextBox Liberta5;
        private System.Windows.Forms.Button Morphea2;
        private System.Windows.Forms.Button Morphea1;
        private System.Windows.Forms.Label Yoru1;
        private System.Windows.Forms.NumericUpDown Nebris1;
        private System.Windows.Forms.Button Morphea16;
        private System.Windows.Forms.Button Morphea15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button Mophea21;
        private System.Windows.Forms.Button Morphea20;
    }
}