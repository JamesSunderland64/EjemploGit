﻿using Desafio3Farmacia.Data;
using Desafio3Farmacia.DataAdmin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafio3Farmacia
{
    public partial class VistaADM : Form
    {
        private Repositorio repo;
        private FarmaciaManager manager = new FarmaciaManager();
        private readonly PerfilAdministradorService _perfilService = new PerfilAdministradorService();
        private byte[] _fotoActual;
        private int idUsuario;
        public VistaADM(int id)
        {
            InitializeComponent();
            idUsuario = id;
            repo = new Repositorio();
            CargarTodos();
            CargarPerfil();
        }

        private void VistaADM_Load(object sender, EventArgs e)
        {
            #region====Pestaña1
            Blade1.Items.AddRange(new string[] { "ID_Medicamento", "Nombre", "ID_Categoria", "Precio_Compra", "Precio_Venta", "Stock" });
            Blade2.Items.AddRange(new string[] { "ID_Usuario", "Nombre_Usuario", "Rol" });
            Blade3.Items.AddRange(new string[] { "ID_Admin", "Nombre_Admin", "Cargo" });
            Blade4.Items.AddRange(new string[] { "ID_Cliente", "Nombre", "DUI" });

            Blade1.SelectedIndex = 0;
            Blade2.SelectedIndex = 0;
            Blade3.SelectedIndex = 0;
            Blade4.SelectedIndex = 0;
            #endregion
            #region=====segunda pestaña

            Blade5.Items.AddRange(new string[] { "ID_Proveedor", "Nombre", "Telefono", "Correo" });
            Blade6.Items.AddRange(new string[] { "ID_Detalle", "Cantidad", "Precio_Unitario", "Subtotal" });
            Blade7.Items.AddRange(new string[] { "ID_Detalle_Compra", "Cantidad", "Precio_Compra", "Subtotal" });
            Blade8.Items.AddRange(new string[] { "ID_Categoria", "Nombre_Categoria", "Descripcion" });

            Blade5.SelectedIndex = 0;
            Blade6.SelectedIndex = 0;
            Blade7.SelectedIndex = 0;
            Blade8.SelectedIndex = 0;
            #endregion
            #region====Pestaña3
            Blade9.Items.AddRange(new string[] { "ID_Medicamento", "Nombre", "ID_Categoria", "Precio_Venta" });
            Blade10.Items.AddRange(new string[] { "ID_Categoria", "Nombre_Categoria" });

            Blade9.SelectedIndex = 0;
            Blade10.SelectedIndex = 0;

            #endregion
            #region ======Pestaña5
            Blade12.Items.AddRange(new string[]{"ID_Medicamento", "Nombre","ID_Categoria","Precio_Compra","Precio_Venta","ID_Proveedor","Stock",
             "Fecha_Registro" });
            Blade13.Items.AddRange(new string[]{"ID_Proveedor","Nombre","Direccion","Correo" });

            Blade13.SelectedIndex = 0;
            Blade12.SelectedIndex = 0;
            #endregion

        }
        #region=========Pestaña1
        private void CargarTodos()
        {
            //primera pestaña :)
            Diana1.DataSource = repo.ObtenerTodos("Medicamento");
            Diana2.DataSource = repo.ObtenerTodos("Usuario");
            Diana3.DataSource = repo.ObtenerTodos("Administrador");
            Diana4.DataSource = repo.ObtenerTodos("Cliente");
            //Segunda Pestaña :)
            Diana5.DataSource = repo.ObtenerTodos("Proveedor");
            Diana6.DataSource = repo.ObtenerTodos("Detalle_Venta");
            Diana7.DataSource = repo.ObtenerTodos("Detalle_Compra");
            Diana8.DataSource = repo.ObtenerTodos("Categoria");
            //Tercera pestaña :]
            Diana9.DataSource = manager.ObtenerMedicamentos();
            Diana10.DataSource = manager.ObtenerCategorias();
            //Quinta pestaña
            Diana11.DataSource = invService.ObtenerMedicamentos();
            Diana12.DataSource = invService.ObtenerProveedores();

        }
        private void Buscar(TextBox txt, ComboBox cmb, DataGridView dgv, string tabla)
        {
            if (string.IsNullOrEmpty(txt.Text) || cmb.SelectedItem == null)
            {
                dgv.DataSource = repo.ObtenerTodos(tabla);
            }
            else
            {
                string columna = cmb.SelectedItem.ToString();
                dgv.DataSource = repo.Buscar(tabla, columna, txt.Text);
            }
        }
      
        private void Liberta1_TextChanged(object sender, EventArgs e) => Buscar(Liberta1, Blade1, Diana1, "Medicamento");
        private void Liberta2_TextChanged(object sender, EventArgs e) => Buscar(Liberta2, Blade2, Diana2, "Usuario");
        private void Liberta3_TextChanged(object sender, EventArgs e) => Buscar(Liberta3, Blade3, Diana3, "Administrador");
        private void Liberta4_TextChanged(object sender, EventArgs e) => Buscar(Liberta4, Blade4, Diana4, "Cliente");

        private void Liberta5_TextChanged(object sender, EventArgs e) => Buscar(Liberta5, Blade5, Diana5, "Proveedor");
        private void Liberta6_TextChanged(object sender, EventArgs e) => Buscar(Liberta6, Blade6, Diana6, "Detalle_Venta");
        private void Liberta7_TextChanged(object sender, EventArgs e) => Buscar(Liberta7, Blade7, Diana7, "Detalle_Compra");
        private void Liberta8_TextChanged(object sender, EventArgs e) => Buscar(Liberta8, Blade8, Diana8, "Categoria");


        #endregion

        #region=======pestaña3

        private void Liberta9_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Liberta9.Text))
                Diana9.DataSource = manager.ObtenerMedicamentos();
            else
                Diana9.DataSource = manager.BuscarMedicamentos(Blade9.SelectedItem.ToString(), Liberta9.Text);
        }

        private void Liberta10_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Liberta10.Text))
                Diana10.DataSource = manager.ObtenerCategorias();
            else
                Diana10.DataSource = manager.BuscarCategorias(Blade10.SelectedItem.ToString(), Liberta10.Text);
        }

        private void Diana9_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = Diana9.Rows[e.RowIndex];
                Yoru1.Text = fila.Cells["ID_Medicamento"].Value.ToString();
            }
        }

        private void Morphea1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Yoru1.Text))
            {
                MessageBox.Show("Seleccione un medicamento antes de confirmar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int id = int.Parse(Yoru1.Text);
            int cantidad = (int)Nebris1.Value;

            if (cantidad <= 0)
            {
                MessageBox.Show("Cantidad inválida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            manager.RegistrarCompra(id, cantidad);
            CargarTodos();
        }

        private void Morphea2_Click(object sender, EventArgs e)
        {
            Yoru1.Text = "";
            Nebris1.Value = 1;
            MessageBox.Show("Compra cancelada.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Diana10_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = Diana10.Rows[e.RowIndex];
                Liberta11.Text = fila.Cells["Nombre_Categoria"].Value.ToString();
                Liberta14.Text = fila.Cells["Descripcion"].Value.ToString();
                Liberta11.Tag = fila.Cells["ID_Categoria"].Value; // Guardamos el ID en Tag
            }
        }

        private void Morphea3_Click(object sender, EventArgs e)
        {
            if (Liberta11.Tag == null)
            {
                MessageBox.Show("Seleccione una categoría para modificar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int id = Convert.ToInt32(Liberta11.Tag);
            string nombre = Liberta11.Text.Trim();
            string descripcion = Liberta14.Text.Trim();

            if (string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("Nombre de categoría no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (manager.ActualizarCategoria(id, nombre, descripcion))
            {
                MessageBox.Show("✅ Categoría actualizada correctamente.");
                CargarTodos();
            }
        }

        private void Morphea4_Click(object sender, EventArgs e)
        {
            string nombre = Liberta15.Text.Trim();
            string descripcion = Liberta16.Text.Trim();

            if (string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("El nombre de la categoría no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (manager.RegistrarCategoria(nombre, descripcion))
            {
                MessageBox.Show("✅ Categoría registrada correctamente.");
                Liberta15.Clear();
                Liberta16.Clear();
                CargarTodos();
            }
        }

        #endregion
        #region =====Pestaña4
        private void CargarPerfil()
        {
            var (admin, user) = _perfilService.CargarPerfil(idUsuario);

            if (admin != null)
            {
                Celia1.Text = admin["Nombre_Admin"].ToString();
                Celia2.Text = admin["Apellido_Admin"].ToString();
                Celia3.Text = admin["Correo"].ToString();
                Celia4.Text = admin["Cargo"].ToString();
                Celia5.Text = admin["Telefono"].ToString();
                _fotoActual = admin["Foto"] as byte[];

                Helena1.Image = _perfilService.ConvertirImagen(_fotoActual);
            }

            if (user != null)
            {
                Celia6.Text = user["Nombre_Usuario"].ToString();
                Celia7.Text = user["Usuario_Login"].ToString();
                Celia8.Text = user["Contraseña"].ToString();
                Celia9.Text = user["CodigoAdmin"]?.ToString();
            }


            BloquearCamposAdmin(true);
            BloquearCamposUsuario(true);
        }
        private void BloquearCamposAdmin(bool bloquear)
        {
            for (int i = 1; i <= 5; i++)
            {
                var ctrl = Kasumi8.Controls["Celia" + i];
                if (ctrl != null)
                    ctrl.Enabled = !bloquear;
            }

            Morphea6.Enabled = !bloquear;
        }
        private void BloquearCamposUsuario(bool bloquear)
        {
            for (int i = 6; i <= 9; i++)
            {
                var ctrl = Kasumi8.Controls["Celia" + i];
                if (ctrl != null)
                    ctrl.Enabled = !bloquear;
            }
        }


        private void Michaela1_CheckedChanged(object sender, EventArgs e)
        {
            if (Michaela1.Checked)
            {
                BloquearCamposAdmin(false);
                BloquearCamposUsuario(true);
            }
        }

        private void Michaela2_CheckedChanged(object sender, EventArgs e)
        {
            if (Michaela2.Checked)
            {
                BloquearCamposAdmin(true);
                BloquearCamposUsuario(false);
            }
        }

        private void Morphea6_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Imágenes|*.jpg;*.jpeg;*.png";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    Helena1.Image = Image.FromFile(ofd.FileName);
                }
            }
        }

        private void Morphea5_Click(object sender, EventArgs e)
        {
            try
            {
                _fotoActual = _perfilService.ImagenABytes(Helena1.Image);

                if (Michaela1.Checked)
                {
                    var (admin, _) = _perfilService.CargarPerfil(idUsuario);
                    if (admin == null)
                        _perfilService.CrearAdministrador(Celia1.Text, Celia2.Text, Celia3.Text, Celia4.Text, Celia5.Text, _fotoActual, idUsuario);
                    else
                        _perfilService.ActualizarAdministrador(Celia1.Text, Celia2.Text, Celia3.Text, Celia4.Text, Celia5.Text, _fotoActual, idUsuario);

                    MessageBox.Show("Perfil de administrador guardado correctamente.");
                }
                else if (Michaela2.Checked)
                {
                    _perfilService.ActualizarUsuario(idUsuario, Celia6.Text, Celia7.Text, Celia8.Text, Celia9.Text);
                    MessageBox.Show("Datos de usuario actualizados correctamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
        #region =========================Pestaña5
        private InventarioService invService = new InventarioService();
        private int _medSeleccionadoId = 0;
        private int _provSeleccionadoId = 0;
        private Image _imagenMedicamentoSeleccionada = null;

        private void LimpiarMedicamentoCampos()
        {
            Liberta18.Clear();
            Liberta19.Clear();
            Liberta20.Clear();
            Liberta21.Clear();
            Liberta22.Clear();
            Liberta23.Clear();
            Liberta24.Clear();
            Liberta25.Clear();
            Liberta26.Clear();
            Helena2.Image = null;
            _imagenMedicamentoSeleccionada = null;
            _medSeleccionadoId = 0;
        }
        private void LimpiarProveedorCampos()
        {
            Liberta28.Clear();
            Liberta29.Clear();
            Liberta30.Clear();
            Liberta31.Clear();
            Liberta32.Clear();
            _provSeleccionadoId = 0;
        }
        #endregion

        private void Diana11_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var fila = Diana11.Rows[e.RowIndex];
            _medSeleccionadoId = Convert.ToInt32(fila.Cells["ID_Medicamento"].Value);

            Liberta18.Text = fila.Cells["ID_Medicamento"].Value.ToString();
            Liberta19.Text = fila.Cells["Nombre"].Value?.ToString();
            Liberta20.Text = fila.Cells["Descripcion"].Value?.ToString();
            Liberta21.Text = fila.Cells["ID_Categoria"].Value?.ToString();
            Liberta22.Text = fila.Cells["Precio_Compra"].Value?.ToString();
            Liberta23.Text = fila.Cells["Precio_Venta"].Value?.ToString();
            Liberta24.Text = fila.Cells["Stock"].Value?.ToString();
            Liberta25.Text = fila.Cells["Fecha_Registro"].Value?.ToString();
            Liberta26.Text = fila.Cells["ID_Proveedor"].Value?.ToString();

            var imgObj = fila.Cells["Imagen"].Value;
            if (imgObj != DBNull.Value && imgObj != null)
            {
                byte[] b = (byte[])imgObj;
                Helena2.Image = invService.BytesAImagen(b);
                _imagenMedicamentoSeleccionada = Helena2.Image;
            }
            else
            {
                Helena2.Image = null;
                _imagenMedicamentoSeleccionada = null;
            }
        }

        private void Morphea8_Click(object sender, EventArgs e)
        {

            string nombre = Liberta19.Text.Trim();
            if (string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("Ingrese nombre del medicamento.");
                return;
            }

            if (!int.TryParse(Liberta21.Text, out int idCat)) { MessageBox.Show("ID categoría inválido."); return; }
            if (!decimal.TryParse(Liberta22.Text, out decimal pCompra)) { MessageBox.Show("Precio compra inválido."); return; }
            if (!decimal.TryParse(Liberta23.Text, out decimal pVenta)) { MessageBox.Show("Precio venta inválido."); return; }
            if (!int.TryParse(Liberta24.Text, out int stock)) { MessageBox.Show("Stock inválido."); return; }
            if (!int.TryParse(Liberta26.Text, out int idProv)) { MessageBox.Show("ID proveedor inválido."); return; }

            DateTime fecha = DateTime.Now;
            if (!string.IsNullOrEmpty(Liberta25.Text))
            {
                DateTime.TryParse(Liberta25.Text, out fecha);
            }

            byte[] imgBytes = invService.ImagenABytes(_imagenMedicamentoSeleccionada);

            bool ok = invService.GuardarMedicamento(nombre, Liberta20.Text.Trim(), idCat, pCompra, pVenta, stock, fecha, idProv, imgBytes);
            if (!ok)
            {
                MessageBox.Show("No se pudo guardar: ya existe un medicamento con ese nombre para el mismo proveedor.");
                return;
            }

            MessageBox.Show("Medicamento registrado.");
            CargarTodos(); 
            LimpiarMedicamentoCampos();
        }

        private void Morphea9_Click(object sender, EventArgs e)
        {
            if (_medSeleccionadoId == 0) { MessageBox.Show("Seleccione un medicamento."); return; }


            string nombre = Liberta19.Text.Trim();
            if (!int.TryParse(Liberta21.Text, out int idCat)) { MessageBox.Show("ID categoría inválido."); return; }
            if (!decimal.TryParse(Liberta22.Text, out decimal pCompra)) { MessageBox.Show("Precio compra inválido."); return; }
            if (!decimal.TryParse(Liberta23.Text, out decimal pVenta)) { MessageBox.Show("Precio venta inválido."); return; }
            if (!int.TryParse(Liberta24.Text, out int stock)) { MessageBox.Show("Stock inválido."); return; }
            if (!int.TryParse(Liberta26.Text, out int idProv)) { MessageBox.Show("ID proveedor inválido."); return; }
            DateTime fecha = DateTime.Now;
            if (!string.IsNullOrEmpty(Liberta25.Text)) DateTime.TryParse(Liberta25.Text, out fecha);

            byte[] imgBytes = invService.ImagenABytes(_imagenMedicamentoSeleccionada);

            bool ok = invService.ActualizarMedicamento(_medSeleccionadoId, nombre, Liberta20.Text.Trim(), idCat, pCompra, pVenta, stock, fecha, idProv, imgBytes);
            if (!ok)
            {
                MessageBox.Show("No se pudo actualizar: probablemente ya exista otro medicamento con ese nombre y proveedor.");
                return;
            }

            MessageBox.Show("Medicamento actualizado.");
            CargarTodos();
        }

        private void Morphea10_Click(object sender, EventArgs e)
        {
            if (_medSeleccionadoId == 0) { MessageBox.Show("Seleccione un medicamento."); return; }

            var confirm = MessageBox.Show("¿Eliminar medicamento y todas sus relaciones (detalles)?:", "Confirmar", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;

            try
            {
                bool ok = invService.EliminarMedicamentoCascade(_medSeleccionadoId);
                if (ok)
                {
                    MessageBox.Show("Medicamento y relaciones eliminadas.");
                    CargarTodos();
                    LimpiarMedicamentoCampos();
                    _medSeleccionadoId = 0;
                }
                else MessageBox.Show("No se eliminó el medicamento.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void Morphea11_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Imágenes|*.jpg;*.jpeg;*.png";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    Helena2.Image = Image.FromFile(ofd.FileName);
                    _imagenMedicamentoSeleccionada = Helena2.Image;
                   
                }
            }
        }

        private void Morphea15_Click(object sender, EventArgs e)
        {
            LimpiarMedicamentoCampos();
        }

        private void Liberta17_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Liberta17.Text))
                Diana11.DataSource = invService.ObtenerMedicamentos();
            else
                Diana11.DataSource = invService.BuscarMedicamentos(Blade12.SelectedItem.ToString(), Liberta17.Text);
        }

        private void Diana12_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var fila = Diana12.Rows[e.RowIndex];
            _provSeleccionadoId = Convert.ToInt32(fila.Cells["ID_Proveedor"].Value);
            Liberta28.Text = fila.Cells["ID_Proveedor"].Value.ToString();
            Liberta29.Text = fila.Cells["Nombre"].Value?.ToString();
            Liberta30.Text = fila.Cells["Telefono"].Value?.ToString();
            Liberta31.Text = fila.Cells["Direccion"].Value?.ToString();
            Liberta32.Text = fila.Cells["Correo"].Value?.ToString();
        }

        private void Morphea12_Click(object sender, EventArgs e)
        {
            string nombre = Liberta29.Text.Trim();
            if (string.IsNullOrEmpty(nombre)) { MessageBox.Show("Ingrese nombre"); return; }
            if (invService.ExisteProveedorPorNombre(nombre)) { MessageBox.Show("Proveedor ya existe"); return; }
            bool ok = invService.GuardarProveedorCorrecto(nombre, Liberta30.Text.Trim(), Liberta31.Text.Trim(), Liberta32.Text.Trim());
            if (ok) { MessageBox.Show("Proveedor guardado"); CargarTodos(); LimpiarProveedorCampos(); }
            else MessageBox.Show("No se pudo guardar proveedor");
        }

        private void Morphea13_Click(object sender, EventArgs e)
        {
            if (_provSeleccionadoId == 0) { MessageBox.Show("Seleccione proveedor"); return; }
            bool ok = invService.ActualizarProveedor(_provSeleccionadoId, Liberta29.Text.Trim(), Liberta30.Text.Trim(), Liberta31.Text.Trim(), Liberta32.Text.Trim());
            if (ok) { MessageBox.Show("Proveedor actualizado"); CargarTodos(); }
            else MessageBox.Show("No se pudo actualizar");
        }

        private void Morphea14_Click(object sender, EventArgs e)
        {
            if (_provSeleccionadoId == 0) { MessageBox.Show("Seleccione proveedor"); return; }
            var confirm = MessageBox.Show("Eliminar proveedor y todos los medicamentos relacionados?", "Confirmar", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;
            try
            {
                bool ok = invService.EliminarProveedorCascade(_provSeleccionadoId);
                if (ok) { MessageBox.Show("Proveedor y sus medicamentos eliminados"); CargarTodos(); LimpiarProveedorCampos(); }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void Morphea16_Click(object sender, EventArgs e)
        {
            LimpiarProveedorCampos();
        }

        private void Liberta27_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Liberta27.Text))
                Diana12.DataSource = invService.ObtenerProveedores();
            else
                Diana12.DataSource = invService.BuscarProveedores(Blade13.SelectedItem.ToString(), Liberta27.Text);
        }

        private void Mophea21_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Morphea20_Click(object sender, EventArgs e)
        {
            Loguin login = new Loguin();
            login.Show();
            this.Close();
        }
    }
}
