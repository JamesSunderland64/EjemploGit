﻿using Desafio3Farmacia.Data;
using Desafio3Farmacia.Korrin;
using Desafio3Farmacia.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafio3Farmacia.Vistas
{
    public partial class CUCategoria : UserControl
    {
        private Panel _panelDestino;
        private FlowLayoutPanel contenedorTarjetas;
        private int idCategoria;
        public CUCategoria(int idCategoria, Panel panelDestino)
        {
            InitializeComponent();
            this.idCategoria = idCategoria;
            _panelDestino = panelDestino;
            CargarProductosPorCategoria(idCategoria);

        }
        private void CargarProductosPorCategoria(int id)
        {
            List<Medicamento> productos = FarmaciaDAO.ObtenerMedicamentosPorCategoria(id);

        
            tableLayoutPanel1.Controls.Clear(); 
            tableLayoutPanel1.RowStyles.Clear(); 
            tableLayoutPanel1.RowCount = 0; 

            int columna = 0;
            int fila = 0;

            foreach (var med in productos)
            {
                var card = new CardProduct(med, _panelDestino)
                {
                    
                    Margin = new Padding(8),
                    Width = 190,
                    Height = 250
                };

                card.Anchor = AnchorStyles.None;
                tableLayoutPanel1.Controls.Add(card, columna, fila);
                columna++;

                if (columna >= tableLayoutPanel1.ColumnCount) 
                {
                    columna = 0; 
                    fila++;     
                    tableLayoutPanel1.RowCount++; 
                }
            }
        }
       
        private void CUCategoria_Load(object sender, EventArgs e)
        {
         
           
        }
    }
}
