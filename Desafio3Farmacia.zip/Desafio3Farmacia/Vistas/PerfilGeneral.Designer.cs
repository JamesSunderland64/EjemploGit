﻿namespace Desafio3Farmacia.Vistas
{
    partial class PerfilGeneral
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Kasumi1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Celia1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Morphea2 = new System.Windows.Forms.Button();
            this.Morphea1 = new System.Windows.Forms.Button();
            this.Helena1 = new System.Windows.Forms.PictureBox();
            this.Celia5 = new System.Windows.Forms.TextBox();
            this.Celia6 = new System.Windows.Forms.TextBox();
            this.Celia4 = new System.Windows.Forms.TextBox();
            this.Celia2 = new System.Windows.Forms.TextBox();
            this.Celia3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Kasumi2 = new System.Windows.Forms.GroupBox();
            this.Celia7 = new System.Windows.Forms.TextBox();
            this.Celia8 = new System.Windows.Forms.TextBox();
            this.Celia9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.Morphea3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Kasumi1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).BeginInit();
            this.Kasumi2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Kasumi1
            // 
            this.Kasumi1.BackColor = System.Drawing.Color.SpringGreen;
            this.Kasumi1.Controls.Add(this.label7);
            this.Kasumi1.Controls.Add(this.Celia1);
            this.Kasumi1.Controls.Add(this.label6);
            this.Kasumi1.Controls.Add(this.Morphea2);
            this.Kasumi1.Controls.Add(this.Morphea1);
            this.Kasumi1.Controls.Add(this.Helena1);
            this.Kasumi1.Controls.Add(this.Celia5);
            this.Kasumi1.Controls.Add(this.Celia6);
            this.Kasumi1.Controls.Add(this.Celia4);
            this.Kasumi1.Controls.Add(this.Celia2);
            this.Kasumi1.Controls.Add(this.Celia3);
            this.Kasumi1.Controls.Add(this.label5);
            this.Kasumi1.Controls.Add(this.label4);
            this.Kasumi1.Controls.Add(this.label3);
            this.Kasumi1.Controls.Add(this.label2);
            this.Kasumi1.Controls.Add(this.label1);
            this.Kasumi1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kasumi1.Location = new System.Drawing.Point(12, 15);
            this.Kasumi1.Name = "Kasumi1";
            this.Kasumi1.Size = new System.Drawing.Size(580, 432);
            this.Kasumi1.TabIndex = 7;
            this.Kasumi1.TabStop = false;
            this.Kasumi1.Text = "Mi Perfil";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(429, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 20);
            this.label7.TabIndex = 22;
            this.label7.Text = "Mi Foto:";
            // 
            // Celia1
            // 
            this.Celia1.Location = new System.Drawing.Point(42, 63);
            this.Celia1.Name = "Celia1";
            this.Celia1.Size = new System.Drawing.Size(210, 27);
            this.Celia1.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 20);
            this.label6.TabIndex = 20;
            this.label6.Text = "ID Cliente:";
            // 
            // Morphea2
            // 
            this.Morphea2.BackColor = System.Drawing.Color.Lime;
            this.Morphea2.Location = new System.Drawing.Point(413, 375);
            this.Morphea2.Name = "Morphea2";
            this.Morphea2.Size = new System.Drawing.Size(118, 39);
            this.Morphea2.TabIndex = 18;
            this.Morphea2.Text = "Guardar";
            this.Morphea2.UseVisualStyleBackColor = false;
            this.Morphea2.Click += new System.EventHandler(this.Morphea2_Click);
            // 
            // Morphea1
            // 
            this.Morphea1.BackColor = System.Drawing.Color.Lime;
            this.Morphea1.Location = new System.Drawing.Point(401, 224);
            this.Morphea1.Name = "Morphea1";
            this.Morphea1.Size = new System.Drawing.Size(131, 40);
            this.Morphea1.TabIndex = 17;
            this.Morphea1.Text = "Agregar Foto";
            this.Morphea1.UseVisualStyleBackColor = false;
            this.Morphea1.Click += new System.EventHandler(this.Morphea1_Click);
            // 
            // Helena1
            // 
            this.Helena1.Location = new System.Drawing.Point(413, 63);
            this.Helena1.Name = "Helena1";
            this.Helena1.Size = new System.Drawing.Size(110, 138);
            this.Helena1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Helena1.TabIndex = 16;
            this.Helena1.TabStop = false;
            // 
            // Celia5
            // 
            this.Celia5.Location = new System.Drawing.Point(42, 387);
            this.Celia5.Name = "Celia5";
            this.Celia5.Size = new System.Drawing.Size(210, 27);
            this.Celia5.TabIndex = 15;
            // 
            // Celia6
            // 
            this.Celia6.Location = new System.Drawing.Point(43, 316);
            this.Celia6.Name = "Celia6";
            this.Celia6.Size = new System.Drawing.Size(210, 27);
            this.Celia6.TabIndex = 14;
            // 
            // Celia4
            // 
            this.Celia4.Location = new System.Drawing.Point(41, 257);
            this.Celia4.Name = "Celia4";
            this.Celia4.Size = new System.Drawing.Size(210, 27);
            this.Celia4.TabIndex = 13;
            // 
            // Celia2
            // 
            this.Celia2.Location = new System.Drawing.Point(41, 123);
            this.Celia2.Name = "Celia2";
            this.Celia2.Size = new System.Drawing.Size(210, 27);
            this.Celia2.TabIndex = 12;
            // 
            // Celia3
            // 
            this.Celia3.Location = new System.Drawing.Point(41, 194);
            this.Celia3.Name = "Celia3";
            this.Celia3.Size = new System.Drawing.Size(210, 27);
            this.Celia3.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Dirreccion:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 359);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Telefono:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 234);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "DUI:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Apellido:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nombre:";
            // 
            // Kasumi2
            // 
            this.Kasumi2.BackColor = System.Drawing.Color.SpringGreen;
            this.Kasumi2.Controls.Add(this.Celia7);
            this.Kasumi2.Controls.Add(this.Celia8);
            this.Kasumi2.Controls.Add(this.Celia9);
            this.Kasumi2.Controls.Add(this.label9);
            this.Kasumi2.Controls.Add(this.label10);
            this.Kasumi2.Controls.Add(this.label11);
            this.Kasumi2.Controls.Add(this.button4);
            this.Kasumi2.Controls.Add(this.Morphea3);
            this.Kasumi2.Controls.Add(this.button6);
            this.Kasumi2.Controls.Add(this.pictureBox2);
            this.Kasumi2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kasumi2.Location = new System.Drawing.Point(624, 15);
            this.Kasumi2.Name = "Kasumi2";
            this.Kasumi2.Size = new System.Drawing.Size(364, 432);
            this.Kasumi2.TabIndex = 27;
            this.Kasumi2.TabStop = false;
            this.Kasumi2.Text = "Mi Perfil";
            // 
            // Celia7
            // 
            this.Celia7.Location = new System.Drawing.Point(41, 69);
            this.Celia7.Name = "Celia7";
            this.Celia7.Size = new System.Drawing.Size(210, 27);
            this.Celia7.TabIndex = 26;
            // 
            // Celia8
            // 
            this.Celia8.Location = new System.Drawing.Point(41, 134);
            this.Celia8.Name = "Celia8";
            this.Celia8.Size = new System.Drawing.Size(210, 27);
            this.Celia8.TabIndex = 25;
            // 
            // Celia9
            // 
            this.Celia9.Location = new System.Drawing.Point(40, 213);
            this.Celia9.Name = "Celia9";
            this.Celia9.Size = new System.Drawing.Size(210, 27);
            this.Celia9.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(39, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(181, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "Nombre De Usuario:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(39, 111);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 20);
            this.label10.TabIndex = 22;
            this.label10.Text = "Contraseña:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(39, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 20);
            this.label11.TabIndex = 21;
            this.label11.Text = "Usuario:";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Yellow;
            this.button4.Location = new System.Drawing.Point(393, 361);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(109, 34);
            this.button4.TabIndex = 19;
            this.button4.Text = "Volver";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // Morphea3
            // 
            this.Morphea3.BackColor = System.Drawing.Color.Lime;
            this.Morphea3.Location = new System.Drawing.Point(220, 375);
            this.Morphea3.Name = "Morphea3";
            this.Morphea3.Size = new System.Drawing.Size(118, 42);
            this.Morphea3.TabIndex = 18;
            this.Morphea3.Text = "Guardar";
            this.Morphea3.UseVisualStyleBackColor = false;
            this.Morphea3.Click += new System.EventHandler(this.Morphea3_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Lime;
            this.button6.Location = new System.Drawing.Point(591, 206);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(131, 40);
            this.button6.TabIndex = 17;
            this.button6.Text = "Agregar Foto";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(601, 46);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(110, 138);
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // PerfilGeneral
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Kasumi2);
            this.Controls.Add(this.Kasumi1);
            this.Name = "PerfilGeneral";
            this.Size = new System.Drawing.Size(1017, 494);
            this.Load += new System.EventHandler(this.PerfilGeneral_Load);
            this.Kasumi1.ResumeLayout(false);
            this.Kasumi1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Helena1)).EndInit();
            this.Kasumi2.ResumeLayout(false);
            this.Kasumi2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Kasumi1;
        private System.Windows.Forms.Button Morphea2;
        private System.Windows.Forms.Button Morphea1;
        private System.Windows.Forms.PictureBox Helena1;
        private System.Windows.Forms.TextBox Celia5;
        private System.Windows.Forms.TextBox Celia6;
        private System.Windows.Forms.TextBox Celia4;
        private System.Windows.Forms.TextBox Celia2;
        private System.Windows.Forms.TextBox Celia3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox Kasumi2;
        private System.Windows.Forms.TextBox Celia7;
        private System.Windows.Forms.TextBox Celia8;
        private System.Windows.Forms.TextBox Celia9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Morphea3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox Celia1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}
