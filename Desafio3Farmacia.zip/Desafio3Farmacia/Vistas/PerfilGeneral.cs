﻿using Desafio3Farmacia.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafio3Farmacia.Vistas
{
    public partial class PerfilGeneral : UserControl
    {
        private int idUsuario;
        private int idCliente = 0;
        private ClienteService clienteService = new ClienteService();
        private Image fotoSeleccionada = null;
        public PerfilGeneral(int idUsuarioLogueado)
        {
            InitializeComponent();
            idUsuario = idUsuarioLogueado;
            CargarDatos();
        }
        private void CargarDatos()
        {
            DataTable dt = clienteService.ObtenerClientePorUsuario(idUsuario);

            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                idCliente = Convert.ToInt32(row["ID_Cliente"]);

                // Kasumi1
                Celia1.Text = row["ID_Cliente"].ToString();
                Celia2.Text = row["Nombre"].ToString();
                Celia3.Text = row["Apellido"].ToString();
                Celia4.Text = row["DUI"].ToString();
                Celia6.Text = row["Telefono"].ToString();
                Celia5.Text = row["Direccion"].ToString();

                Helena1.Image = clienteService.ConvertirBytesAImagen(row["Foto"] as byte[]);

     
                Celia7.Text = row["Nombre_Usuario"].ToString();
                Celia8.Text = row["Usuario_Login"].ToString();
                Celia9.Text = row["Contraseña"].ToString();
            }
            else
            {
            
                idCliente = 0;
                Helena1.Image = Properties.Resources.usuario_default;
            }
        }

        private void PerfilGeneral_Load(object sender, EventArgs e)
        {
            
        }

        private void Morphea1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Imagenes|*.jpg;*.jpeg;*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                fotoSeleccionada = Image.FromFile(ofd.FileName);
                Helena1.Image = fotoSeleccionada;
            }
        }

        private void Morphea2_Click(object sender, EventArgs e)
        {
         
            if (string.IsNullOrWhiteSpace(Celia2.Text))
            {
                MessageBox.Show("El nombre no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Celia2.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Celia3.Text))
            {
                MessageBox.Show("El apellido no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Celia3.Focus();
                return;
            }

            if (!string.IsNullOrWhiteSpace(Celia4.Text) && Celia4.Text.Length != 10)
            {
                MessageBox.Show("El DUI debe tener 10 caracteres (incluyendo el guion).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Celia4.Focus();
                return;
            }

            if (!string.IsNullOrWhiteSpace(Celia6.Text) && Celia6.Text.Length > 15)
            {
                MessageBox.Show("El teléfono no debe tener más de 15 caracteres.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Celia6.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Celia5.Text))
            {
                MessageBox.Show("La dirección no puede estar vacía.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Celia5.Focus();
                return;
            }

            if (idCliente == 0)
            {
               
                idCliente = clienteService.CrearCliente(idUsuario,
                    Celia2.Text,
                    Celia3.Text,
                    Celia4.Text,
                    Celia6.Text,
                    Celia5.Text,                
                    fotoSeleccionada);
                MessageBox.Show("Cliente creado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
              
                clienteService.ActualizarCliente(idCliente,
                    Celia2.Text,
                    Celia3.Text,
                    Celia4.Text,
                    Celia6.Text,  
                    Celia5.Text,  
                    fotoSeleccionada);
                MessageBox.Show("Cliente actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Morphea3_Click(object sender, EventArgs e)
        {
            clienteService.ActualizarUsuario(idUsuario,
                Celia7.Text,
                Celia8.Text,
                Celia9.Text);
            MessageBox.Show("Usuario actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
