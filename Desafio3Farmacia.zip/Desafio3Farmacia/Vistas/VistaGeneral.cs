﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Desafio3Farmacia.Models;
using Desafio3Farmacia.Data;
using Desafio3Farmacia.Korrin;

namespace Desafio3Farmacia.Vistas
{
    public partial class VistaGeneral : UserControl
    {
        private Panel _panelDestino;
        public VistaGeneral(Panel panelDestino)
        {
            InitializeComponent();
            _panelDestino = panelDestino;  
            CargarCarrusel();
        }

        private void VistaGeneral_Load(object sender, EventArgs e)
        {

        }
        private void CargarCarrusel()
        {
            flowLayoutPanel1.Controls.Clear();
            var medicamentos = MedicamentoDAL.ObtenerMedicamentos();

            foreach (var med in medicamentos)
            {
                var tarjeta = new CardProduct(med, _panelDestino);
                flowLayoutPanel1.Controls.Add(tarjeta);
            }
        }
    }
}
